"""
apply_height_patch.py
Usage:  python3 apply_height_patch.py sentro_ginhawa.py

Works on EITHER version of your file:
  - the original file (random mock sensors), or
  - a file that already has the temperature patch (apply_arduino_patch.py).
It installs ArduinoSensors, which reads temperature AND height from the same
Arduino (one USB cable, one serial port). A .bak2 backup is made first.
"""
import sys, shutil

IMPORTS = '''import time
from collections import deque
try:
    import serial
    import serial.tools.list_ports
except ImportError as _e:
    serial = None
    print(f"[WARNING] pyserial import failed: {_e}")
'''

NEW_BLOCK = '''# ── ARDUINO SENSORS (temperature + height on ONE serial link) ──────────────────
# The Arduino prints one line per reading at 9600 baud:
#     TEMP:36.5        body temperature in °C
#     DIST:48.3        raw distance (cm) from the overhead VL53L1X sensor to the head
# Optional overrides in .env:
#   SENTRO_TEMP_PORT=/dev/ttyUSB0       (blank = auto-detect ttyUSB*/ttyACM*)
#   SENTRO_TEMP_BAUD=9600
#   SENTRO_HEIGHT_MOUNT_CM=200          distance from the sensor down to the FLOOR (measure it!)
#   SENTRO_HEIGHT_OFFSET_CM=0           fine-tune after testing with a person of known height
SENSOR_PORT       = os.environ.get("SENTRO_TEMP_PORT", "")
SENSOR_BAUD       = int(os.environ.get("SENTRO_TEMP_BAUD", "9600"))

TEMP_MIN_OK       = 30.0     # readings outside this range are treated as glitches
TEMP_MAX_OK       = 45.0
TEMP_SAMPLES      = 3        # fresh readings averaged per "Read Sensor" press
TEMP_TIMEOUT      = 8.0

HEIGHT_MOUNT_CM   = float(os.environ.get("SENTRO_HEIGHT_MOUNT_CM", "200"))
HEIGHT_OFFSET_CM  = float(os.environ.get("SENTRO_HEIGHT_OFFSET_CM", "0"))
HEIGHT_MIN_OK     = 50.0     # computed heights outside this range are ignored
HEIGHT_MAX_OK     = 220.0
HEIGHT_SAMPLES    = 7        # valid readings needed; the MEDIAN is used (ignores spikes)
HEIGHT_TIMEOUT    = 8.0

class ArduinoSensors:
    """One serial connection; keeps recent valid samples for each sensor."""
    def __init__(self, port, baud):
        self.port, self.baud = port, baud
        self._samples = {"TEMP": deque(maxlen=50), "DIST": deque(maxlen=100)}
        self._lock = threading.Lock()
        self._thread = None
        self.connected = False
        self.last_error = None

    def start(self):
        if serial is None:
            self.last_error = "pyserial not installed"
            return
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _find_port(self):
        if self.port:
            return self.port
        for p in serial.tools.list_ports.comports():
            d = p.device
            if any(k in d for k in ("ttyUSB", "ttyACM", "usbmodem", "usbserial")) \\
               or d.startswith("COM"):
                return d
        return None

    def _run(self):
        while True:
            port = self._find_port()
            if not port:
                self.connected = False
                self.last_error = "Arduino not found"
                time.sleep(2); continue
            try:
                with serial.Serial(port, self.baud, timeout=1) as ser:
                    time.sleep(2)                 # Arduino auto-resets when port opens
                    ser.reset_input_buffer()
                    self.connected, self.last_error = True, None
                    while True:
                        raw = ser.readline()
                        if raw:
                            self._parse(raw.decode("utf-8", "ignore").strip())
            except Exception as e:                # unplugged / busy -> retry
                self.connected = False
                self.last_error = str(e)
                time.sleep(2)

    def _parse(self, line):
        if ":" not in line:
            return
        key, _, val = line.partition(":")
        key = key.strip().upper()
        try:
            v = float(val)
        except ValueError:
            return
        if key == "TEMP" and TEMP_MIN_OK <= v <= TEMP_MAX_OK:
            ok = True
        elif key == "DIST" and 2.0 <= v <= 400.0:   # VL53L1X working range (max ~360 cm)
            ok = True
        else:
            ok = False
        if ok:
            with self._lock:
                self._samples[key].append((time.monotonic(), v))

    def _fresh(self, key, t0):
        """Samples taken AFTER t0, so a previous resident's reading is never reused."""
        with self._lock:
            return [v for ts, v in self._samples[key] if ts >= t0]

    def read_temp(self):
        """Returns (value_str, error_str)."""
        t0 = time.monotonic()
        self.start()
        deadline = t0 + TEMP_TIMEOUT
        while time.monotonic() < deadline:
            fresh = self._fresh("TEMP", t0)
            if len(fresh) >= TEMP_SAMPLES:
                fresh = fresh[-TEMP_SAMPLES:]
                return f"{sum(fresh) / len(fresh):.1f}", None
            time.sleep(0.1)
        return None, (self.last_error or "No valid temperature data from Arduino")

    def read_height(self):
        """Returns (value_str, error_str). height = mount height - distance to head."""
        t0 = time.monotonic()
        self.start()
        deadline = t0 + HEIGHT_TIMEOUT
        saw_dist = False
        while time.monotonic() < deadline:
            dists = self._fresh("DIST", t0)
            if dists:
                saw_dist = True
            heights = [HEIGHT_MOUNT_CM - d + HEIGHT_OFFSET_CM for d in dists]
            heights = [h for h in heights if HEIGHT_MIN_OK <= h <= HEIGHT_MAX_OK]
            if len(heights) >= HEIGHT_SAMPLES:
                recent = sorted(heights[-HEIGHT_SAMPLES:])
                return f"{recent[len(recent) // 2]:.1f}", None     # median
            time.sleep(0.1)
        if saw_dist:
            return None, "No person detected under the height sensor"
        return None, (self.last_error or "No distance data from Arduino")

arduino = ArduinoSensors(SENSOR_PORT, SENSOR_BAUD)
arduino.start()    # connect at startup so the Arduino reset is already done by the wizard

# ── SENSOR STUB (other sensors) ───────────────────────────────────────────────
# Temperature and height are REAL (Arduino). The rest remain simulated until wired up.
def read_sensor(sensor_id: str):
    """Returns (value_str, error_str) — value_str is None on failure."""
    if sensor_id == "temperature":
        return arduino.read_temp()
    if sensor_id == "height":
        return arduino.read_height()
    time.sleep(1.2)   # simulate read delay
    stubs = {
        "bp":      f"{random.randint(110,135)}/{random.randint(70,90)}",
        "glucose": f"{random.randint(80,120)}",
        "weight":  f"{random.randint(50,80)}",
    }
    return stubs.get(sensor_id, None), None

'''

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 apply_height_patch.py sentro_ginhawa.py"); return 1
    path = sys.argv[1]
    with open(path, encoding="utf-8") as f:
        src = f.read()

    if "class ArduinoSensors" in src:
        print("Already patched - nothing to do."); return 0

    # 1) imports (only if the temperature patch hasn't added them already)
    if "from collections import deque" not in src or "import serial" not in src:
        if "import time\n" not in src:
            print("ERROR: couldn't find the 'import time' line."); return 1
        src = src.replace("import time\n", IMPORTS, 1)

    # 2) replace the sensor block (temperature-patched file OR original mock file)
    if "# ── ARDUINO TEMPERATURE SENSOR" in src:
        start_marker = "# ── ARDUINO TEMPERATURE SENSOR"
    elif "# ── SENSOR STUB" in src:
        start_marker = "# ── SENSOR STUB"
    else:
        print("ERROR: couldn't find the sensor section to replace."); return 1
    end_marker = "def dispense_lancet():"
    if end_marker not in src:
        print("ERROR: couldn't find def dispense_lancet()."); return 1
    s0, e0 = src.index(start_marker), src.index(end_marker)
    if e0 < s0:
        print("ERROR: unexpected section order."); return 1

    shutil.copy(path, path + ".bak2")
    with open(path, "w", encoding="utf-8") as f:
        f.write(src[:s0] + NEW_BLOCK + src[e0:])
    print(f"Done. Backup saved as {path}.bak2")
    return 0

if __name__ == "__main__":
    sys.exit(main())
