import 'package:flutter_test/flutter_test.dart';

import 'package:sentro_ginhawa_app/core/health.dart';
import 'package:sentro_ginhawa_app/models/resident.dart';
import 'package:sentro_ginhawa_app/models/vital_record.dart';

VitalRecord rec({
  double? temp,
  int? sys,
  int? dia,
  double? glucose,
  double? height,
  double? weight,
  double? bmi,
  DateTime? time,
}) {
  return VitalRecord(
    id: 'x',
    time: time ?? DateTime(2026, 10, 13, 9, 41),
    temperature: temp,
    systolic: sys,
    diastolic: dia,
    glucose: glucose,
    height: height,
    weight: weight,
    bmi: bmi,
  );
}

void main() {
  group('status thresholds match the kiosk', () {
    test('temperature', () {
      expect(statusFor(Metric.temperature, rec(temp: 34.5))!.labelKey, 'st_dangerously_low');
      expect(statusFor(Metric.temperature, rec(temp: 35.5))!.labelKey, 'st_below_normal');
      expect(statusFor(Metric.temperature, rec(temp: 37.2))!.labelKey, 'st_normal');
      expect(statusFor(Metric.temperature, rec(temp: 37.6))!.labelKey, 'st_low_fever');
      expect(statusFor(Metric.temperature, rec(temp: 38.4))!.labelKey, 'st_fever');
    });

    test('blood pressure (systolic, like the kiosk)', () {
      expect(statusFor(Metric.bp, rec(sys: 85, dia: 55))!.labelKey, 'st_low_bp');
      expect(statusFor(Metric.bp, rec(sys: 118, dia: 76))!.labelKey, 'st_normal');
      expect(statusFor(Metric.bp, rec(sys: 125, dia: 80))!.labelKey, 'st_elevated');
      expect(statusFor(Metric.bp, rec(sys: 135, dia: 85))!.labelKey, 'st_stage1');
      expect(statusFor(Metric.bp, rec(sys: 142, dia: 90))!.labelKey, 'st_stage2');
    });

    test('glucose', () {
      expect(statusFor(Metric.glucose, rec(glucose: 65))!.labelKey, 'st_low_glucose');
      expect(statusFor(Metric.glucose, rec(glucose: 95))!.labelKey, 'st_normal');
      expect(statusFor(Metric.glucose, rec(glucose: 112))!.labelKey, 'st_prediabetes');
      expect(statusFor(Metric.glucose, rec(glucose: 140))!.labelKey, 'st_diabetes');
    });

    test('BMI', () {
      expect(computeBmi(165, 58)!.toStringAsFixed(1), '21.3');
      expect(computeBmi(null, 58), isNull);
      expect(statusFor(Metric.bmi, rec(bmi: 17.0))!.labelKey, 'st_underweight');
      expect(statusFor(Metric.bmi, rec(bmi: 27.0))!.labelKey, 'st_overweight');
      expect(statusFor(Metric.bmi, rec(bmi: 31.0))!.labelKey, 'st_obese');
      expect(bmiLabelEn(21.3), 'Normal');
    });
  });

  group('tips', () {
    test('most important first, same cut-offs as the chips', () {
      final LatestVitals l = latestFrom(<VitalRecord>[
        rec(temp: 38.4, sys: 142, dia: 90, glucose: 112),
      ]);
      final List<String> keys = tipsFor(l).map((Tip t) => t.key).toList();
      expect(keys.first == 'tip_high_bp2' || keys.first == 'tip_fever', isTrue);
      expect(keys.last, 'tip_pre_glucose');
      expect(keys.contains('tip_norm_glucose'), isFalse);
    });

    test('falls back to the default tip', () {
      expect(tipsFor(latestFrom(<VitalRecord>[])).single.key, 'tip_default');
    });
  });

  group('latest value per metric', () {
    test('a home BP reading does not blank the other cards', () {
      final VitalRecord kiosk = rec(
        temp: 36.8,
        sys: 118,
        dia: 76,
        glucose: 90,
        time: DateTime(2026, 10, 1),
      );
      final VitalRecord home = rec(sys: 130, dia: 84, time: DateTime(2026, 10, 12));
      final LatestVitals l = latestFrom(<VitalRecord>[home, kiosk]); // newest first
      expect(l.of(Metric.bp), same(home));
      expect(l.of(Metric.temperature), same(kiosk));
      expect(l.glucose, 90);
    });
  });

  group('resident identity (must equal the kiosk format)', () {
    const Resident r = Resident(
      uid: 'u1',
      lastName: 'dela cruz',
      firstName: 'Juan',
      middleName: 'Santos',
      gender: 'Male',
      birthdate: '2000-01-31',
      email: 'j@x.ph',
    );

    test('kioskName / key', () {
      expect(r.kioskName, 'DELA CRUZ, Juan Santos');
      expect(r.kioskKey, 'DELA CRUZ, JUAN SANTOS');
      expect(Resident.kioskKeyOf('a/b,  c'), 'A-B, C');
    });

    test('display name', () {
      expect(formatDisplayName('LUFFY, monkey d'), 'Luffy, Monkey D');
      expect(r.displayName, 'Dela Cruz, Juan Santos');
    });
  });
}
