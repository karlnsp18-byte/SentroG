import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'core/app_state.dart';
import 'core/theme.dart';
import 'firebase_options.dart';
import 'screens/gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const SentroGinhawaApp());
}

class SentroGinhawaApp extends StatefulWidget {
  const SentroGinhawaApp({super.key});

  @override
  State<SentroGinhawaApp> createState() => _SentroGinhawaAppState();
}

class _SentroGinhawaAppState extends State<SentroGinhawaApp> {
  final AppState _state = AppState();

  @override
  void dispose() {
    _state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: _state,
      child: MaterialApp(
        title: 'Sentro Ginhawa',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const AuthGate(),
      ),
    );
  }
}
