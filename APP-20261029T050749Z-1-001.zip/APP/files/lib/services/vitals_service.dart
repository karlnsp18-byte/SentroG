import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/vital_record.dart';

/// All measurements live in vitals/{uid}/history/{id}. The kiosk (Admin SDK)
/// writes records with source == 'kiosk'; the app writes source == 'app'.
class VitalsService {
  VitalsService._();

  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  static CollectionReference<Map<String, dynamic>> _col(String uid) =>
      _db.collection('vitals').doc(uid).collection('history');

  /// Newest first.
  static Stream<List<VitalRecord>> historyStream(String uid, {int limit = 200}) {
    return _col(uid)
        .orderBy('timestamp', descending: true)
        .limit(limit)
        .snapshots()
        .map((QuerySnapshot<Map<String, dynamic>> s) =>
            s.docs.map(VitalRecord.fromDoc).toList());
  }

  static Future<void> addReading(
    String uid,
    VitalRecord record,
    String bmiStatusEn,
  ) async {
    await _col(uid).add(record.toAppMap(bmiStatusEn));
  }

  static Future<void> delete(String uid, String id) => _col(uid).doc(id).delete();
}
