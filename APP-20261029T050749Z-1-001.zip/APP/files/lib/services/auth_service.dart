import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

import '../models/resident.dart';

/// Thrown when another resident already owns the same "LASTNAME, Firstname" key.
class NameTakenException implements Exception {
  const NameTakenException();
}

class AuthService {
  AuthService._();

  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  /// Cached so StreamBuilders do not resubscribe on every rebuild.
  static final Stream<User?> authChanges = _auth.authStateChanges();

  /// True while register() is running. AuthGate keeps showing the registration
  /// form (instead of racing ahead to the profile screens) until it finishes.
  static final ValueNotifier<bool> busy = ValueNotifier<bool>(false);

  static User? get currentUser => _auth.currentUser;

  static Future<void> login(String email, String password) async {
    await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
  }

  static Future<void> resetPassword(String email) =>
      _auth.sendPasswordResetEmail(email: email.trim());

  static Future<void> signOut() => _auth.signOut();

  /// Creates the Firebase account, then the resident profile. If the profile
  /// cannot be saved (e.g. the name is already registered) the new account is
  /// removed again so nothing half-created is left behind.
  static Future<void> register({
    required String email,
    required String password,
    required Resident draft,
  }) async {
    busy.value = true;
    UserCredential? cred;
    try {
      cred = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final String uid = cred.user!.uid;
      await createProfile(draft.copyWith(uid: uid, email: email.trim()));
    } catch (e) {
      if (cred != null) {
        try {
          await cred.user!.delete();
        } catch (_) {}
      }
      rethrow;
    } finally {
      busy.value = false;
    }
  }

  /// Writes residents/{uid} and claims kioskNames/{KEY} in one batch. The
  /// security rules only allow *creating* a kioskNames doc, so a second
  /// resident with the same name is rejected with permission-denied.
  static Future<void> createProfile(Resident r) async {
    final WriteBatch batch = _db.batch();
    batch.set(_db.collection('kioskNames').doc(r.kioskKey), <String, dynamic>{
      'uid': r.uid,
      'createdAt': FieldValue.serverTimestamp(),
    });
    batch.set(_db.collection('residents').doc(r.uid), r.toCreateMap());
    try {
      await batch.commit();
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') throw const NameTakenException();
      rethrow;
    }
  }

  static Stream<DocumentSnapshot<Map<String, dynamic>>> residentDoc(String uid) =>
      _db.collection('residents').doc(uid).snapshots();

  static Future<void> acceptTerms(String uid) =>
      _db.collection('residents').doc(uid).update(<String, dynamic>{
        'acceptedTerms': true,
        'termsAcceptedAt': FieldValue.serverTimestamp(),
      });

  /// Best effort: remember the language choice on the resident profile.
  static Future<void> saveLang(String lang) async {
    final User? u = _auth.currentUser;
    if (u == null) return;
    try {
      await _db
          .collection('residents')
          .doc(u.uid)
          .update(<String, dynamic>{'lang': lang});
    } catch (_) {}
  }

  /// Right to erasure (Data Privacy Act): removes the resident's cloud data and
  /// the login. The kiosk keeps its own local copy — the barangay health officer
  /// removes that one.
  static Future<void> deleteAccount(String password) async {
    final User user = _auth.currentUser!;
    final String uid = user.uid;
    final AuthCredential cred = EmailAuthProvider.credential(
      email: user.email ?? '',
      password: password,
    );
    await user.reauthenticateWithCredential(cred);

    final DocumentSnapshot<Map<String, dynamic>> doc =
        await _db.collection('residents').doc(uid).get();
    final String? kioskName = doc.data()?['kioskName'] as String?;

    // History, in chunks (a batch holds at most 500 writes).
    final CollectionReference<Map<String, dynamic>> col =
        _db.collection('vitals').doc(uid).collection('history');
    while (true) {
      final QuerySnapshot<Map<String, dynamic>> snap = await col.limit(400).get();
      if (snap.docs.isEmpty) break;
      final WriteBatch b = _db.batch();
      for (final QueryDocumentSnapshot<Map<String, dynamic>> d in snap.docs) {
        b.delete(d.reference);
      }
      await b.commit();
    }

    if (kioskName != null) {
      await _db
          .collection('kioskNames')
          .doc(Resident.kioskKeyOf(kioskName))
          .delete();
    }
    await _db.collection('residents').doc(uid).delete();
    await user.delete();
  }

  /// Translation key for a friendly error message.
  static String errorKey(Object e) {
    if (e is NameTakenException) return 'err_name_taken';
    if (e is FirebaseAuthException) {
      switch (e.code) {
        case 'invalid-credential':
        case 'wrong-password':
        case 'user-not-found':
        case 'invalid-login-credentials':
          return 'err_bad_login';
        case 'email-already-in-use':
          return 'err_email_in_use';
        case 'weak-password':
          return 'err_weak_password';
        case 'invalid-email':
          return 'err_invalid_email';
        case 'network-request-failed':
          return 'err_network';
        case 'too-many-requests':
          return 'err_too_many';
        case 'requires-recent-login':
          return 'err_recent_login';
      }
    }
    if (e is FirebaseException) {
      if (e.code == 'unavailable') return 'err_network';
      if (e.code == 'permission-denied') return 'err_permission';
    }
    return 'err_generic';
  }
}
