// English / Filipino strings. Medical wording follows the kiosk's own strings so
// the app and the kiosk say the same thing.

const Map<String, Map<String, String>> kStrings = <String, Map<String, String>>{
  'EN': _en,
  'FIL': _fil,
};

const Map<String, String> _en = <String, String>{
  // general
  'app_sub': 'Smart Barangay Health Kiosk Companion',
  'back': 'Back',
  'cancel': 'Cancel',
  'close': 'Close',
  'send': 'Send',
  'delete': 'Delete',
  'continue_btn': 'Continue',
  'logout': 'Log Out',
  'req': 'Required',
  'optional': 'optional',
  'name_chars': 'Letters, spaces, . - and apostrophes only',
  'male': 'Male',
  'female': 'Female',
  'gender': 'Gender',
  'birthdate': 'Date of Birth',
  'pick_date': 'Tap to choose a date',
  'email': 'Email Address',
  'password': 'Password',
  'password_again': 'Confirm Password',
  'pass_hint': 'At least 8 characters',
  'pass_mismatch': 'Passwords do not match',
  'last_name': 'Last Name',
  'first_name': 'First Name',
  'middle_name': 'Middle Name',
  'kiosk_name_hint': 'This is how the kiosk will know you:',
  'connecting': 'Connecting…',

  // welcome
  'wsub': 'Smart Barangay Health Kiosk',
  'wtag': 'Free health check — no appointment needed',
  'welcome': 'Welcome!',
  'proceed': 'How would you like to proceed?',
  'b_exist': 'I Already Have an Account',
  'b_new': 'Register as New Resident',
  'perk_pass': 'Fast kiosk check-in',
  'perk_track': 'Track your readings',
  'perk_private': 'Private & secure',

  // login / register
  'ltitle': 'Resident Login',
  'lhint': 'Enter your registered credentials:',
  'forgot': 'Forgot password?',
  'b_login': 'Log In  →',
  'no_account': "Don't have an account? Register",
  'forgot_title': 'Reset password',
  'forgot_body': 'We will email you a link to choose a new password.',
  'forgot_sent': 'Password reset email sent. Please check your inbox.',
  'rtitle': 'New Resident Registration',
  'rhint': 'Fill in your details to create your health profile.',
  'b_register': 'Register & Continue  →',
  'have_account': 'Already registered? Log In',
  'complete_title': 'Complete your profile',
  'complete_hint': 'Your account has no resident profile yet. Please fill in your details.',
  'save_continue': 'Save & Continue  →',

  // errors
  'err_bad_login': 'Wrong email or password.',
  'err_email_in_use': 'That email is already registered. Try logging in.',
  'err_weak_password': 'Password must be at least 8 characters.',
  'err_invalid_email': 'Please enter a valid email address.',
  'err_network': 'No internet connection. Please try again.',
  'err_too_many': 'Too many attempts. Please wait a moment and try again.',
  'err_recent_login': 'Please log in again, then retry.',
  'err_permission': 'You do not have permission to do that.',
  'err_generic': 'Something went wrong. Please try again.',
  'err_name_taken': 'A resident with this name is already registered. If this is you, log in instead, or ask the barangay health officer for help.',
  'err_load_title': 'Could not load your data',
  'err_number': 'Enter a number',
  'err_range': 'Between {lo} and {hi}',
  'err_bp_both': 'Enter both the top (systolic) and bottom (diastolic) numbers.',
  'err_bp_order': 'The top number must be higher than the bottom number.',
  'err_need_one': 'Enter at least one measurement.',

  // terms
  'tnc_title': 'Terms & Conditions',
  'tnc_sub': 'Please read and agree before continuing.',
  'tnc_agree': '✔  I Agree',
  'tnc_decline': '✖  Decline',
  'tnc_body': 'DATA PRIVACY & CONSENT\n'
      '━━━━━━━━━━━━━━━━━━━━━━━\n'
      'By using Sentro Ginhawa, you consent to the collection and secure storage of your '
      'personal information (name, age, gender, date of birth, email address) and health '
      'measurements (body temperature, blood pressure, blood glucose, height, weight, BMI) '
      'in accordance with the Data Privacy Act of 2012 (Republic Act No. 10173).\n\n'
      'Your data is collected solely for the purpose of providing barangay health monitoring '
      'services. It will not be sold, shared with third parties, or used for commercial '
      'purposes without your explicit consent. You may request access to, correction of, or '
      'deletion of your records at any time by contacting the barangay health officer, or '
      'delete your account from the Profile tab.\n\n'
      'LIABILITY DISCLAIMER\n'
      '━━━━━━━━━━━━━━━━━━━━━━━\n'
      'The health readings provided by the kiosk and this app are for general screening and '
      'informational purposes only. They do NOT constitute a medical diagnosis, professional '
      'medical advice, or a substitute for consultation with a licensed healthcare provider.\n\n'
      'The barangay, STI College Caloocan, and the developers of Sentro Ginhawa shall not be '
      'held liable for any health decisions made solely on the basis of these readings. If you '
      'are experiencing a medical emergency or have concerns about your health, please consult '
      'a qualified medical professional immediately.\n\n'
      "By tapping 'I Agree', you confirm that you have read, understood, and accepted these "
      'terms and conditions.',

  // welcome interstitial
  'wi_welcome': 'Welcome, {name}!',
  'wi_reg_success': 'Registration successful! Your health profile has been created.',
  'wi_pass_title': 'Get your health check',
  'wi_pass_desc': 'Show your Kiosk Pass QR code at the Sentro Ginhawa kiosk to start the guided health check.',
  'wi_pass_btn': 'Open my Kiosk Pass  →',
  'wi_dash_title': 'My health records',
  'wi_dash_desc': 'See your latest readings and history. They appear here after every kiosk visit.',
  'wi_dash_btn': 'View my records',

  // navigation
  'nav_vitals': 'Vitals',
  'nav_history': 'History',
  'nav_pass': 'Kiosk Pass',
  'nav_profile': 'Profile',
  'log_reading': 'Log a reading',

  // home
  'age_n': '{n} yrs old',
  'cta_title': 'Ready for your checkup?',
  'cta_body': 'Visit the Sentro Ginhawa kiosk with your Kiosk Pass. Your results will appear here automatically.',
  'howto_title': 'How it works',
  'howto_1': '1. Open the Kiosk Pass tab and show your QR code to the kiosk camera.',
  'howto_2': '2. Follow the guided check: Height → Weight → Temperature → Blood Pressure → Blood Glucose.',
  'howto_3': '3. Save the record (and print the receipt) at the kiosk.',
  'howto_4': '4. Come back here to see your results, tips and history.',
  'show_pass': 'Show my Kiosk Pass',
  'tips_title': '💡 Simple Health Tips & Reminders',
  'disclaimer': 'These are general reminders only, not a medical diagnosis.',
  'latest_readings': 'Latest Health Readings',
  'not_yet': 'Not yet recorded',
  'mod_temp': 'Body Temperature',
  'mod_bp': 'Blood Pressure',
  'mod_glu': 'Blood Glucose',
  'mod_ht': 'Height',
  'mod_wt': 'Weight',
  'mod_bmi': 'BMI',

  // status chips
  'st_dangerously_low': 'Dangerously Low',
  'st_below_normal': 'Below Normal',
  'st_normal': '✓ Normal',
  'st_low_fever': 'Low Fever',
  'st_fever': 'Fever',
  'st_low_bp': 'Low (Hypotension)',
  'st_elevated': 'Elevated',
  'st_stage1': 'High – Stage 1',
  'st_stage2': 'High – Stage 2',
  'st_low_glucose': 'Low (Hypoglycemia)',
  'st_prediabetes': 'Prediabetes Range',
  'st_diabetes': 'Diabetes Range',
  'st_underweight': 'Underweight',
  'st_overweight': 'Overweight',
  'st_obese': 'Obese',
  'st_recorded': '✓ Recorded',

  // tips
  'tip_low_glucose': '🍏 Low Blood Sugar: Consider having a light snack or juice. Rest if feeling dizzy.',
  'tip_high_glucose': '💧 High Blood Sugar: Drink adequate water and consult a Barangay Health Worker if needed.',
  'tip_norm_glucose': '✨ Blood Sugar: Within normal range. Keep up the healthy lifestyle!',
  'tip_pre_glucose': '🥗 Blood Sugar: Slightly above normal. Limit sweet drinks and ask your Barangay Health Worker about a follow-up check.',
  'tip_high_bp': '🫀 Blood Pressure: Slightly elevated. Take a deep breath, rest for 5-10 minutes, and recheck.',
  'tip_high_bp2': '🫀 Blood Pressure: High. Sit and rest, then recheck. Please consult your Barangay Health Worker soon.',
  'tip_low_bp': '🫀 Blood Pressure: Slightly low. Drink water and avoid standing up quickly.',
  'tip_norm_bp': '🫀 Blood Pressure: Normal and healthy.',
  'tip_fever': '🌡️ Temperature: Mild fever detected. Rest in a cool area and stay hydrated.',
  'tip_default': '💡 Reminder: Regular health monitoring helps maintain good wellness. Ask your Barangay Health Officer if you have questions.',

  // metric detail
  'no_data_metric': 'No reading yet',
  'no_data_metric_hint': 'Visit the kiosk or log a reading to see it here.',
  'src_kiosk': 'Measured at the kiosk',
  'src_app': 'Self-reported',
  'where_you_are': 'Where you are',
  'bp_systolic_note': 'The marker shows your top (systolic) number.',
  'trend': 'Trend',
  'trend_need_two': 'Two or more readings are needed to show a trend.',
  'about_reading': 'About this reading',
  'about_temperature': 'Body temperature shows whether your body may be fighting an infection. A normal adult range is about 36.1–37.2 °C.',
  'about_bp': 'Blood pressure is the force of blood against your artery walls. The top number (systolic) is measured when the heart beats; the bottom (diastolic) when it rests. Below 120/80 mmHg is considered normal.',
  'about_glucose': 'Blood glucose is the sugar in your blood. A normal fasting level is about 70–99 mg/dL. Readings after a meal can be higher.',
  'about_height': 'Height is measured in centimeters and is used together with your weight to compute your BMI.',
  'about_weight': 'Weight is measured in kilograms and is used together with your height to compute your BMI.',
  'about_bmi': 'Body Mass Index compares weight with height. 18.5–24.9 is considered a healthy range; it is a screening number, not a diagnosis.',
  'past_readings': 'Past readings',

  // history
  'delete_record': 'Delete this reading?',
  'delete_record_body': 'This removes your self-reported reading from the app.',
  'filter_all': 'All',
  'filter_kiosk': 'Kiosk',
  'filter_mine': 'Self-reported',
  'no_history': 'No records yet',
  'no_history_hint': 'Your kiosk measurements and self-reported readings will be listed here.',
  'latest': 'Latest',

  // add reading
  'self_report_note': 'Readings you enter here are marked as self-reported. They may be less accurate than kiosk measurements.',
  'measured_at': 'Measured on',
  'systolic': 'Systolic (top)',
  'diastolic': 'Diastolic (bottom)',
  'save_reading': 'Save reading',
  'reading_saved': 'Reading saved.',

  // kiosk pass
  'pass_title': 'My Kiosk Pass',
  'pass_hint': 'Hold this QR code up to the kiosk camera.',
  'pass_brightness': 'Turn your screen brightness up so the kiosk can read the code.',
  'steps_title': 'At the kiosk',
  'pass_s1': '1. On the kiosk welcome screen, tap “Scan QR Code”.',
  'pass_s2': '2. Hold this code 15–20 cm from the camera until it is recognised.',
  'pass_s3': '3. Agree to the terms, then tap “Begin Health Check”.',
  'pass_s4': '4. Follow the steps: Height → Weight → Temperature → Blood Pressure → Blood Glucose (optional).',
  'pass_s5': '5. Save your record. It shows up in this app after it syncs.',
  'pass_privacy': 'This QR code contains your name. Only show it at the kiosk.',

  // profile
  'records_count': 'Saved records',
  'name_locked': 'Your name is linked to your kiosk record, so it can only be changed by the barangay health officer.',
  'language': 'Language',
  'privacy': 'Privacy',
  'view_terms': 'View Terms & Conditions',
  'delete_account': 'Delete my account',
  'delete_account_body': 'This permanently deletes your login, profile and cloud health records. The kiosk keeps its own copy until the barangay health officer removes it. This cannot be undone.',
  'confirm_password': 'Enter your password to confirm',
};

const Map<String, String> _fil = <String, String>{
  // general
  'app_sub': 'Kasama ng Smart Barangay Health Kiosk',
  'back': 'Bumalik',
  'cancel': 'Kanselahin',
  'close': 'Isara',
  'send': 'Ipadala',
  'delete': 'Burahin',
  'continue_btn': 'Magpatuloy',
  'logout': 'Mag-logout',
  'req': 'Kailangan ito',
  'optional': 'opsyonal',
  'name_chars': 'Letra, espasyo, . - at apostrophe lamang',
  'male': 'Lalaki',
  'female': 'Babae',
  'gender': 'Kasarian',
  'birthdate': 'Petsa ng Kapanganakan',
  'pick_date': 'I-tap para pumili ng petsa',
  'email': 'Email Address',
  'password': 'Password',
  'password_again': 'Ulitin ang Password',
  'pass_hint': 'Hindi bababa sa 8 character',
  'pass_mismatch': 'Hindi magkapareho ang mga password',
  'last_name': 'Apelyido',
  'first_name': 'Pangalan',
  'middle_name': 'Gitnang Pangalan',
  'kiosk_name_hint': 'Ganito ka makikilala ng kiosk:',
  'connecting': 'Kumokonekta…',

  // welcome
  'wsub': 'Smart Barangay Health Kiosk',
  'wtag': 'Libreng health check — walang appointment',
  'welcome': 'Maligayang Pagdating!',
  'proceed': 'Paano mo gustong magpatuloy?',
  'b_exist': 'May Account Na Ako',
  'b_new': 'Magrehistro bilang Bagong Residente',
  'perk_pass': 'Mabilis na check-in sa kiosk',
  'perk_track': 'Subaybayan ang iyong mga sukat',
  'perk_private': 'Pribado at ligtas',

  // login / register
  'ltitle': 'Login ng Residente',
  'lhint': 'Ilagay ang iyong rehistradong detalye:',
  'forgot': 'Nakalimutan ang password?',
  'b_login': 'Mag-login  →',
  'no_account': 'Wala pang account? Magrehistro',
  'forgot_title': 'I-reset ang password',
  'forgot_body': 'Padadalhan ka namin ng email na may link para magpalit ng password.',
  'forgot_sent': 'Naipadala na ang email para sa pag-reset ng password. Pakisuri ang iyong inbox.',
  'rtitle': 'Pagrerehistro ng Bagong Residente',
  'rhint': 'Punan ang iyong detalye para magawa ang iyong health profile.',
  'b_register': 'Magrehistro at Magpatuloy  →',
  'have_account': 'Nakarehistro na? Mag-login',
  'complete_title': 'Kumpletuhin ang iyong profile',
  'complete_hint': 'Wala pang profile ng residente ang iyong account. Pakipunan ang iyong detalye.',
  'save_continue': 'I-save at Magpatuloy  →',

  // errors
  'err_bad_login': 'Maling email o password.',
  'err_email_in_use': 'Rehistrado na ang email na iyan. Subukang mag-login.',
  'err_weak_password': 'Dapat hindi bababa sa 8 character ang password.',
  'err_invalid_email': 'Maglagay ng wastong email address.',
  'err_network': 'Walang internet. Pakisubukan ulit.',
  'err_too_many': 'Masyadong maraming pagsubok. Maghintay sandali at subukan ulit.',
  'err_recent_login': 'Mag-login ulit, saka subukan muli.',
  'err_permission': 'Wala kang pahintulot para sa gawaing iyon.',
  'err_generic': 'May nangyaring mali. Pakisubukan ulit.',
  'err_name_taken': 'May nakarehistro nang residente na may ganitong pangalan. Kung ikaw iyon, mag-login na lang, o humingi ng tulong sa health officer ng barangay.',
  'err_load_title': 'Hindi ma-load ang iyong datos',
  'err_number': 'Maglagay ng numero',
  'err_range': 'Sa pagitan ng {lo} at {hi}',
  'err_bp_both': 'Ilagay ang itaas (systolic) at ibaba (diastolic) na numero.',
  'err_bp_order': 'Dapat mas mataas ang itaas na numero kaysa sa ibaba.',
  'err_need_one': 'Maglagay ng kahit isang sukat.',

  // terms
  'tnc_title': 'Mga Tuntunin at Kundisyon',
  'tnc_sub': 'Pakibasa at sumang-ayon bago magpatuloy.',
  'tnc_agree': '✔  Sumasang-ayon Ako',
  'tnc_decline': '✖  Tanggihan',
  'tnc_body': 'PRIVACY NG DATA AT PAHINTULOT\n'
      '━━━━━━━━━━━━━━━━━━━━━━━\n'
      'Sa paggamit ng Sentro Ginhawa, pumapayag ka sa pagkolekta at ligtas na pag-iimbak ng '
      'iyong personal na impormasyon (pangalan, edad, kasarian, petsa ng kapanganakan, email) '
      'at mga sukat ng kalusugan (temperatura, presyon ng dugo, glucose, taas, timbang, BMI) '
      'alinsunod sa Data Privacy Act of 2012 (Batas Republika Blg. 10173).\n\n'
      'Ang iyong datos ay kinokolekta lamang para sa pagbibigay ng serbisyong pangkalusugan sa '
      'barangay. Hindi ito ibebenta, ibabahagi sa mga third party, o gagamitin para sa '
      'komersyal na layunin nang walang iyong pahintulot. Maaari kang humingi ng access, '
      'pagwawasto, o pagtanggal ng iyong mga rekord sa pamamagitan ng pakikipag-ugnayan sa '
      'health officer ng barangay, o burahin ang iyong account sa Profile tab.\n\n'
      'DISCLAIMER SA PANANAGUTAN\n'
      '━━━━━━━━━━━━━━━━━━━━━━━\n'
      'Ang mga resulta ng kalusugan mula sa kiosk at sa app na ito ay para lamang sa '
      'pangkalahatang pagsusuri at impormasyon. Hindi ito bumubuo ng medikal na diagnosis, '
      'propesyonal na payo sa kalusugan, o kapalit ng konsultasyon sa lisensyadong manggagamot.\n\n'
      'Ang barangay, STI College Caloocan, at mga developer ng Sentro Ginhawa ay hindi '
      'mananagot sa anumang desisyon sa kalusugan na ginawa batay lamang sa mga resultang ito. '
      'Kung mayroon kang medikal na emergency o alalahanin tungkol sa iyong kalusugan, '
      'kumonsulta agad sa isang kwalipikadong manggagamot.\n\n'
      "Sa pag-tap ng 'Sumasang-ayon Ako', kinukumpirma mo na nabasa, naunawaan, at tinatanggap "
      'mo ang mga tuntuning ito.',

  // welcome interstitial
  'wi_welcome': 'Maligayang Pagdating, {name}!',
  'wi_reg_success': 'Matagumpay ang pagrehistro! Nagawa na ang iyong health profile.',
  'wi_pass_title': 'Magpa-health check',
  'wi_pass_desc': 'Ipakita ang QR code ng iyong Kiosk Pass sa Sentro Ginhawa kiosk para simulan ang guided health check.',
  'wi_pass_btn': 'Buksan ang Kiosk Pass ko  →',
  'wi_dash_title': 'Aking mga health record',
  'wi_dash_desc': 'Tingnan ang iyong mga pinakabagong sukat at kasaysayan. Lalabas ang mga ito rito pagkatapos ng bawat pagbisita sa kiosk.',
  'wi_dash_btn': 'Tingnan ang aking mga record',

  // navigation
  'nav_vitals': 'Vitals',
  'nav_history': 'Kasaysayan',
  'nav_pass': 'Kiosk Pass',
  'nav_profile': 'Profile',
  'log_reading': 'Mag-log ng sukat',

  // home
  'age_n': '{n} taong gulang',
  'cta_title': 'Handa na para sa checkup?',
  'cta_body': 'Pumunta sa Sentro Ginhawa kiosk dala ang iyong Kiosk Pass. Awtomatikong lalabas dito ang iyong mga resulta.',
  'howto_title': 'Paano ito gumagana',
  'howto_1': '1. Buksan ang Kiosk Pass tab at ipakita ang QR code sa camera ng kiosk.',
  'howto_2': '2. Sundan ang guided check: Taas → Timbang → Temperatura → Presyon ng Dugo → Glucose sa Dugo.',
  'howto_3': '3. I-save ang record (at i-print ang resibo) sa kiosk.',
  'howto_4': '4. Bumalik dito para makita ang iyong mga resulta, payo, at kasaysayan.',
  'show_pass': 'Ipakita ang Kiosk Pass ko',
  'tips_title': '💡 Mga Simpleng Payo at Paalala sa Kalusugan',
  'disclaimer': 'Mga pangkalahatang paalala lamang ito at hindi medikal na diagnosis.',
  'latest_readings': 'Mga Pinakabagong Sukat',
  'not_yet': 'Wala pang tala',
  'mod_temp': 'Temperatura ng Katawan',
  'mod_bp': 'Presyon ng Dugo',
  'mod_glu': 'Glucose sa Dugo',
  'mod_ht': 'Taas',
  'mod_wt': 'Timbang',
  'mod_bmi': 'BMI',

  // status chips
  'st_dangerously_low': 'Mapanganib na Mababa',
  'st_below_normal': 'Mas Mababa sa Normal',
  'st_normal': '✓ Normal',
  'st_low_fever': 'Bahagyang Lagnat',
  'st_fever': 'May Lagnat',
  'st_low_bp': 'Mababa (Hypotension)',
  'st_elevated': 'Medyo Mataas',
  'st_stage1': 'Mataas – Stage 1',
  'st_stage2': 'Mataas – Stage 2',
  'st_low_glucose': 'Mababa (Hypoglycemia)',
  'st_prediabetes': 'Saklaw ng Prediabetes',
  'st_diabetes': 'Saklaw ng Diabetes',
  'st_underweight': 'Kulang ang Timbang',
  'st_overweight': 'Sobra ang Timbang',
  'st_obese': 'Obese',
  'st_recorded': '✓ Naitala',

  // tips
  'tip_low_glucose': '🍏 Mababang Blood Sugar: Maaaring kumain ng meryenda o uminom ng juice. Magpahinga kung nakararamdam ng pagkahilo.',
  'tip_high_glucose': '💧 Mataas na Blood Sugar: Uminom ng sapat na tubig at isangguni sa Barangay Health Worker kung kinakailangan.',
  'tip_norm_glucose': '✨ Blood Sugar: Nasa maayos at katamtamang antas. Ipagpatuloy ang malusog na pamumuhay!',
  'tip_pre_glucose': '🥗 Blood Sugar: Bahagyang mataas. Bawasan ang matatamis na inumin at magtanong sa Barangay Health Worker tungkol sa susunod na pagsusuri.',
  'tip_high_bp': '🫀 Presyon ng Dugo: Medyo mataas. Huminga nang malalim, magpahinga ng 5-10 minuto, at magpasuri ulit.',
  'tip_high_bp2': '🫀 Presyon ng Dugo: Mataas. Umupo at magpahinga, saka magpasuri ulit. Magpakonsulta agad sa Barangay Health Worker.',
  'tip_low_bp': '🫀 Presyon ng Dugo: Medyo mababa. Uminom ng tubig at iwasang tumayo nang biglaan.',
  'tip_norm_bp': '🫀 Presyon ng Dugo: Normal at maayos ang iyong resulta.',
  'tip_fever': '🌡️ Temperatura: May kaunting lagnat. Magpahinga sa preskong lugar at uminom ng maraming tubig.',
  'tip_default': '💡 Paalala: Ang regular na pagpapasuri ay nakatutulong sa pagpapanatili ng mabuting kalusugan.',

  // metric detail
  'no_data_metric': 'Wala pang sukat',
  'no_data_metric_hint': 'Pumunta sa kiosk o mag-log ng sukat para makita ito rito.',
  'src_kiosk': 'Sinukat sa kiosk',
  'src_app': 'Sariling ulat',
  'where_you_are': 'Kung nasaan ka',
  'bp_systolic_note': 'Ang marker ay nagpapakita ng iyong itaas (systolic) na numero.',
  'trend': 'Takbo ng mga sukat',
  'trend_need_two': 'Kailangan ng dalawa o higit pang sukat para makita ang takbo.',
  'about_reading': 'Tungkol sa sukat na ito',
  'about_temperature': 'Ipinapakita ng temperatura ng katawan kung maaaring may nilalabanang impeksyon ang iyong katawan. Ang normal na saklaw ng nasa hustong gulang ay mga 36.1–37.2 °C.',
  'about_bp': 'Ang presyon ng dugo ay ang lakas ng dugo sa pader ng iyong mga ugat. Ang itaas na numero (systolic) ay sinusukat kapag tumitibok ang puso; ang ibaba (diastolic) kapag nagpapahinga ito. Mas mababa sa 120/80 mmHg ang itinuturing na normal.',
  'about_glucose': 'Ang glucose ay ang asukal sa iyong dugo. Ang normal na antas habang walang kain ay mga 70–99 mg/dL. Maaaring mas mataas ang sukat pagkatapos kumain.',
  'about_height': 'Sinusukat ang taas sa sentimetro at ginagamit kasama ng iyong timbang para kalkulahin ang BMI.',
  'about_weight': 'Sinusukat ang timbang sa kilo at ginagamit kasama ng iyong taas para kalkulahin ang BMI.',
  'about_bmi': 'Inihahambing ng Body Mass Index ang timbang sa taas. Ang 18.5–24.9 ay itinuturing na malusog na saklaw; ito ay numerong pang-screening lamang, hindi diagnosis.',
  'past_readings': 'Mga nakaraang sukat',

  // history
  'delete_record': 'Burahin ang sukat na ito?',
  'delete_record_body': 'Aalisin nito ang iyong sariling ulat na sukat mula sa app.',
  'filter_all': 'Lahat',
  'filter_kiosk': 'Kiosk',
  'filter_mine': 'Sariling ulat',
  'no_history': 'Wala pang record',
  'no_history_hint': 'Ililista rito ang iyong mga sukat sa kiosk at sariling ulat na sukat.',
  'latest': 'Pinakabago',

  // add reading
  'self_report_note': 'Ang mga sukat na ilalagay mo rito ay mamarkahan bilang sariling ulat. Maaaring hindi ito kasing-tumpak ng sukat sa kiosk.',
  'measured_at': 'Petsa ng pagsukat',
  'systolic': 'Systolic (itaas)',
  'diastolic': 'Diastolic (ibaba)',
  'save_reading': 'I-save ang sukat',
  'reading_saved': 'Na-save na ang sukat.',

  // kiosk pass
  'pass_title': 'Aking Kiosk Pass',
  'pass_hint': 'Itapat ang QR code na ito sa camera ng kiosk.',
  'pass_brightness': 'Lakasan ang liwanag ng screen para mabasa ng kiosk ang code.',
  'steps_title': 'Sa kiosk',
  'pass_s1': '1. Sa welcome screen ng kiosk, i-tap ang “Scan QR Code”.',
  'pass_s2': '2. Itapat ang code na ito 15–20 cm mula sa camera hanggang makilala.',
  'pass_s3': '3. Sumang-ayon sa mga tuntunin, saka i-tap ang “Magsimula ng Health Check”.',
  'pass_s4': '4. Sundan ang mga hakbang: Taas → Timbang → Temperatura → Presyon ng Dugo → Glucose sa Dugo (opsyonal).',
  'pass_s5': '5. I-save ang iyong record. Lalabas ito sa app na ito pagkatapos ma-sync.',
  'pass_privacy': 'Naglalaman ng iyong pangalan ang QR code na ito. Ipakita lamang ito sa kiosk.',

  // profile
  'records_count': 'Mga naka-save na record',
  'name_locked': 'Nakakabit ang iyong pangalan sa iyong record sa kiosk, kaya ang health officer ng barangay lamang ang puwedeng magpalit nito.',
  'language': 'Wika',
  'privacy': 'Privacy',
  'view_terms': 'Tingnan ang Mga Tuntunin at Kundisyon',
  'delete_account': 'Burahin ang aking account',
  'delete_account_body': 'Permanenteng buburahin nito ang iyong login, profile, at mga health record sa cloud. May sariling kopya ang kiosk hanggang alisin ito ng health officer ng barangay. Hindi na ito mababawi.',
  'confirm_password': 'Ilagay ang iyong password para kumpirmahin',
};
