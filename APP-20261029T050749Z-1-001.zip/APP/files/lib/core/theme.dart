import 'package:flutter/material.dart';

/// Colour palette — mirrors the kiosk's `C = {...}` dictionary so the app and
/// the kiosk look like one product.
class K {
  K._();
  static const Color bg = Color(0xFFF0F4F8);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color s2 = Color(0xFFE8F0FE);
  static const Color hdr = Color(0xFF1A3A6B);
  static const Color hdr2 = Color(0xFF1E4D8C);
  static const Color acc = Color(0xFF1A56A0);
  static const Color accLt = Color(0xFFDBEAFE);
  static const Color grn = Color(0xFF16A34A);
  static const Color grnLt = Color(0xFFDCFCE7);
  static const Color gld = Color(0xFFD97706);
  static const Color gldLt = Color(0xFFFEF9C3);
  static const Color red = Color(0xFFDC2626);
  static const Color txt = Color(0xFF0F172A);
  static const Color sub = Color(0xFF475569);
  static const Color mut = Color(0xFF94A3B8);
  static const Color bdr = Color(0xFFE2E8F0);
  static const Color strip = Color(0xFFF8FAFC);
  static const Color orange = Color(0xFFEA580C);
  static const Color info = Color(0xFF0369A1);
  static const Color deep = Color(0xFF1E40AF);
  static const Color tipsBg = Color(0xFFF0FDF4);
  static const Color skyBlue = Color(0xFF93C5FD);
}

ThemeData buildTheme() {
  final RoundedRectangleBorder shape =
      RoundedRectangleBorder(borderRadius: BorderRadius.circular(8));
  final ColorScheme scheme = ColorScheme.fromSeed(
    seedColor: K.acc,
    primary: K.acc,
    secondary: K.grn,
    surface: K.surface,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: K.bg,
    appBarTheme: const AppBarTheme(
      backgroundColor: K.hdr,
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        color: Colors.white,
        fontSize: 18,
        fontWeight: FontWeight.bold,
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: K.acc,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(52),
        shape: shape,
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: K.acc,
        minimumSize: const Size.fromHeight(52),
        side: const BorderSide(color: K.acc, width: 1.5),
        shape: shape,
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: K.s2,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: K.acc, width: 2),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: K.red, width: 1.5),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: K.red, width: 2),
      ),
    ),
    navigationBarTheme: const NavigationBarThemeData(
      backgroundColor: K.surface,
      indicatorColor: K.accLt,
    ),
  );
}
