import 'package:flutter/material.dart';

import 'strings.dart';

/// App-wide UI state (currently just the language). Wrapped in [AppScope] so
/// any widget that calls `context.t('key')` rebuilds when the language flips.
class AppState extends ChangeNotifier {
  String _lang = 'EN';

  String get lang => _lang;
  bool get isFil => _lang == 'FIL';

  void setLang(String lang) {
    if (lang != 'EN' && lang != 'FIL') return;
    if (lang == _lang) return;
    _lang = lang;
    notifyListeners();
  }

  String tr(String key) =>
      kStrings[_lang]?[key] ?? kStrings['EN']?[key] ?? key;

  String trf(String key, Map<String, String> args) {
    String s = tr(key);
    args.forEach((String k, String v) {
      s = s.replaceAll('{$k}', v);
    });
    return s;
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({
    super.key,
    required AppState state,
    required super.child,
  }) : super(notifier: state);

  static AppState of(BuildContext context) {
    final AppScope? scope =
        context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope is missing above this widget');
    return scope!.notifier!;
  }
}

extension AppContext on BuildContext {
  AppState get app => AppScope.of(this);
  String t(String key) => AppScope.of(this).tr(key);
  String tf(String key, Map<String, String> args) =>
      AppScope.of(this).trf(key, args);
}
