import 'package:flutter/material.dart';

import '../models/vital_record.dart';
import 'theme.dart';

/// Static description of each tracked metric.
class MetricInfo {
  final Metric metric;
  final String titleKey;
  final String unit;
  final IconData icon;
  const MetricInfo(this.metric, this.titleKey, this.unit, this.icon);
}

/// Same order as the kiosk dashboard.
const List<MetricInfo> kMetrics = <MetricInfo>[
  MetricInfo(Metric.temperature, 'mod_temp', '°C', Icons.thermostat),
  MetricInfo(Metric.bp, 'mod_bp', 'mmHg', Icons.favorite),
  MetricInfo(Metric.glucose, 'mod_glu', 'mg/dL', Icons.water_drop),
  MetricInfo(Metric.height, 'mod_ht', 'cm', Icons.height),
  MetricInfo(Metric.weight, 'mod_wt', 'kg', Icons.monitor_weight),
  MetricInfo(Metric.bmi, 'mod_bmi', '', Icons.bar_chart),
];

MetricInfo infoOf(Metric m) =>
    kMetrics.firstWhere((MetricInfo e) => e.metric == m);

// ── Status (triage) ─────────────────────────────────────────────────────────
// Thresholds are copied from the kiosk's `_metric_status_en()` so a reading
// gets the same chip on the kiosk and in the app.

class Status {
  final String labelKey;
  final Color color;

  /// 0 = fine, 1 = keep an eye on it, 2 = needs attention
  final int level;
  const Status(this.labelKey, this.color, this.level);
}

Status _tempStatus(double v) {
  if (v < 35.0) return const Status('st_dangerously_low', K.deep, 2);
  if (v < 36.1) return const Status('st_below_normal', K.info, 1);
  if (v <= 37.2) return const Status('st_normal', K.grn, 0);
  if (v <= 38.0) return const Status('st_low_fever', K.gld, 1);
  return const Status('st_fever', K.red, 2);
}

Status _bpStatus(int sys) {
  if (sys < 90) return const Status('st_low_bp', K.info, 2);
  if (sys < 120) return const Status('st_normal', K.grn, 0);
  if (sys < 130) return const Status('st_elevated', K.gld, 1);
  if (sys < 140) return const Status('st_stage1', K.orange, 1);
  return const Status('st_stage2', K.red, 2);
}

Status _glucoseStatus(double v) {
  if (v < 70) return const Status('st_low_glucose', K.info, 2);
  if (v <= 99) return const Status('st_normal', K.grn, 0);
  if (v <= 125) return const Status('st_prediabetes', K.gld, 1);
  return const Status('st_diabetes', K.red, 2);
}

Status _bmiStatus(double v) {
  if (v < 18.5) return const Status('st_underweight', K.info, 1);
  if (v < 25.0) return const Status('st_normal', K.grn, 0);
  if (v < 30.0) return const Status('st_overweight', K.gld, 1);
  return const Status('st_obese', K.red, 2);
}

Status? statusFor(Metric m, VitalRecord r) {
  if (m == Metric.temperature) {
    final double? v = r.temperature;
    return v == null ? null : _tempStatus(v);
  }
  if (m == Metric.bp) {
    final int? s = r.systolic;
    return s == null ? null : _bpStatus(s);
  }
  if (m == Metric.glucose) {
    final double? v = r.glucose;
    return v == null ? null : _glucoseStatus(v);
  }
  if (m == Metric.bmi) {
    final double? v = r.bmi;
    return v == null ? null : _bmiStatus(v);
  }
  if (m == Metric.height) {
    return r.height == null ? null : const Status('st_recorded', K.grn, 0);
  }
  if (m == Metric.weight) {
    return r.weight == null ? null : const Status('st_recorded', K.grn, 0);
  }
  return null;
}

/// Highest-severity status inside a record (used for the history card accent).
Status? worstStatus(VitalRecord r) {
  Status? worst;
  for (final MetricInfo i in kMetrics) {
    final Status? s = statusFor(i.metric, r);
    if (s == null) continue;
    if (worst == null || s.level > worst.level) worst = s;
  }
  return worst;
}

// ── Values ──────────────────────────────────────────────────────────────────

String _num(double v, {int decimals = 1}) {
  if (v == v.roundToDouble()) return v.toInt().toString();
  return v.toStringAsFixed(decimals);
}

String? valueText(Metric m, VitalRecord r) {
  switch (m) {
    case Metric.temperature:
      return r.temperature == null ? null : r.temperature!.toStringAsFixed(1);
    case Metric.bp:
      return r.bpText;
    case Metric.glucose:
      return r.glucose == null ? null : _num(r.glucose!);
    case Metric.height:
      return r.height == null ? null : _num(r.height!);
    case Metric.weight:
      return r.weight == null ? null : _num(r.weight!);
    case Metric.bmi:
      return r.bmi == null ? null : r.bmi!.toStringAsFixed(1);
  }
}

double? computeBmi(double? heightCm, double? weightKg) {
  if (heightCm == null || weightKg == null) return null;
  if (heightCm <= 0 || weightKg <= 0) return null;
  final double h = heightCm / 100.0;
  return weightKg / (h * h);
}

/// English label stored next to the BMI number (kept for old app versions / reports).
String bmiLabelEn(double b) {
  if (b < 18.5) return 'Underweight';
  if (b < 25.0) return 'Normal';
  if (b < 30.0) return 'Overweight';
  return 'Obese';
}

// ── Latest value per metric ─────────────────────────────────────────────────
// A resident may log only a blood-pressure reading at home; the other cards
// should keep showing their last known value instead of going blank.

class LatestVitals {
  final Map<Metric, VitalRecord> src;
  const LatestVitals(this.src);

  bool get isEmpty => src.isEmpty;
  VitalRecord? of(Metric m) => src[m];

  double? get temperature => src[Metric.temperature]?.temperature;
  int? get systolic => src[Metric.bp]?.systolic;
  double? get glucose => src[Metric.glucose]?.glucose;
  double? get height => src[Metric.height]?.height;

  DateTime? get lastTime {
    DateTime? best;
    for (final VitalRecord r in src.values) {
      if (best == null || r.time.isAfter(best)) best = r.time;
    }
    return best;
  }
}

/// [records] must be sorted newest → oldest.
LatestVitals latestFrom(List<VitalRecord> records) {
  final Map<Metric, VitalRecord> map = <Metric, VitalRecord>{};
  for (final VitalRecord r in records) {
    for (final Metric m in Metric.values) {
      if (!map.containsKey(m) && r.has(m)) map[m] = r;
    }
  }
  return LatestVitals(map);
}

// ── Tips (same cut-offs as the statuses above) ──────────────────────────────

class Tip {
  final String key;
  final int priority;
  const Tip(this.key, this.priority);
}

List<Tip> tipsFor(LatestVitals l) {
  final List<Tip> high = <Tip>[];
  final List<Tip> mid = <Tip>[];
  final List<Tip> low = <Tip>[];

  void add(Tip t) {
    if (t.priority >= 2) {
      high.add(t);
    } else if (t.priority == 1) {
      mid.add(t);
    } else {
      low.add(t);
    }
  }

  final double? g = l.glucose;
  if (g != null) {
    if (g < 70) {
      add(const Tip('tip_low_glucose', 2));
    } else if (g <= 99) {
      add(const Tip('tip_norm_glucose', 0));
    } else if (g <= 125) {
      add(const Tip('tip_pre_glucose', 1));
    } else {
      add(const Tip('tip_high_glucose', 2));
    }
  }

  final int? s = l.systolic;
  if (s != null) {
    if (s < 90) {
      add(const Tip('tip_low_bp', 2));
    } else if (s < 120) {
      add(const Tip('tip_norm_bp', 0));
    } else if (s < 140) {
      add(const Tip('tip_high_bp', 1));
    } else {
      add(const Tip('tip_high_bp2', 2));
    }
  }

  final double? t = l.temperature;
  if (t != null && t > 37.2) add(const Tip('tip_fever', 2));

  final List<Tip> out = <Tip>[...high, ...mid, ...low];
  if (out.isEmpty) out.add(const Tip('tip_default', 0));
  return out;
}

// ── Range bars ──────────────────────────────────────────────────────────────

class RangeSeg {
  final double from;
  final double to;
  final Color color;
  final String labelKey;
  const RangeSeg(this.from, this.to, this.color, this.labelKey);
}

class RangeSpec {
  final double min;
  final double max;
  final List<RangeSeg> segs;
  const RangeSpec(this.min, this.max, this.segs);
}

RangeSpec? rangeFor(Metric m) {
  if (m == Metric.temperature) {
    return const RangeSpec(34, 40, <RangeSeg>[
      RangeSeg(34, 35, K.deep, 'st_dangerously_low'),
      RangeSeg(35, 36.1, K.info, 'st_below_normal'),
      RangeSeg(36.1, 37.2, K.grn, 'st_normal'),
      RangeSeg(37.2, 38.0, K.gld, 'st_low_fever'),
      RangeSeg(38.0, 40, K.red, 'st_fever'),
    ]);
  }
  if (m == Metric.bp) {
    return const RangeSpec(70, 180, <RangeSeg>[
      RangeSeg(70, 90, K.info, 'st_low_bp'),
      RangeSeg(90, 120, K.grn, 'st_normal'),
      RangeSeg(120, 130, K.gld, 'st_elevated'),
      RangeSeg(130, 140, K.orange, 'st_stage1'),
      RangeSeg(140, 180, K.red, 'st_stage2'),
    ]);
  }
  if (m == Metric.glucose) {
    return const RangeSpec(50, 200, <RangeSeg>[
      RangeSeg(50, 70, K.info, 'st_low_glucose'),
      RangeSeg(70, 100, K.grn, 'st_normal'),
      RangeSeg(100, 126, K.gld, 'st_prediabetes'),
      RangeSeg(126, 200, K.red, 'st_diabetes'),
    ]);
  }
  if (m == Metric.bmi) {
    return const RangeSpec(15, 40, <RangeSeg>[
      RangeSeg(15, 18.5, K.info, 'st_underweight'),
      RangeSeg(18.5, 25, K.grn, 'st_normal'),
      RangeSeg(25, 30, K.gld, 'st_overweight'),
      RangeSeg(30, 40, K.red, 'st_obese'),
    ]);
  }
  return null;
}

/// The number plotted on the range bar (systolic for blood pressure).
double? rangeValue(Metric m, VitalRecord r) {
  if (m == Metric.temperature) return r.temperature;
  if (m == Metric.bp) return r.systolic?.toDouble();
  if (m == Metric.glucose) return r.glucose;
  if (m == Metric.bmi) return r.bmi;
  return null;
}

// ── Date formatting ─────────────────────────────────────────────────────────

const List<String> _months = <String>[
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

String fmtDate(DateTime d) => '${_months[d.month - 1]} ${d.day}, ${d.year}';

String fmtTime(DateTime d) {
  final int h12 = d.hour % 12 == 0 ? 12 : d.hour % 12;
  final String mm = d.minute.toString().padLeft(2, '0');
  return '$h12:$mm ${d.hour >= 12 ? 'PM' : 'AM'}';
}

String fmtDateTime(DateTime d) => '${fmtDate(d)} • ${fmtTime(d)}';
