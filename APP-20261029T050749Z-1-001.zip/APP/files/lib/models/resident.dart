import 'package:cloud_firestore/cloud_firestore.dart';

/// "luffy, MONKEY D" -> "Luffy, Monkey D" (same as the kiosk's format_display_name).
String formatDisplayName(String name) {
  if (name.trim().isEmpty) return name;
  final List<String> parts = name.split(',').map((String p) => p.trim()).toList();
  final List<String> out = <String>[];
  for (final String p in parts) {
    final String w = p
        .split(RegExp(r'\s+'))
        .where((String s) => s.isNotEmpty)
        .map((String s) => s[0].toUpperCase() + s.substring(1).toLowerCase())
        .join(' ');
    if (w.isNotEmpty) out.add(w);
  }
  return out.join(', ');
}

class Resident {
  final String uid;
  final String lastName;
  final String firstName;
  final String middleName;

  /// 'Male' | 'Female' (same values the kiosk stores)
  final String gender;

  /// 'YYYY-MM-DD' (same format the kiosk stores)
  final String birthdate;
  final String email;
  final String lang;
  final bool acceptedTerms;

  const Resident({
    required this.uid,
    required this.lastName,
    required this.firstName,
    this.middleName = '',
    required this.gender,
    required this.birthdate,
    required this.email,
    this.lang = 'EN',
    this.acceptedTerms = false,
  });

  /// The kiosk identifies a resident by this exact string ("LASTNAME, Firstname Middle").
  /// It is also the payload of the Kiosk Pass QR code.
  String get kioskName {
    final StringBuffer b =
        StringBuffer('${lastName.trim().toUpperCase()}, ${firstName.trim()}');
    if (middleName.trim().isNotEmpty) b.write(' ${middleName.trim()}');
    return b.toString();
  }

  String get kioskKey => kioskKeyOf(kioskName);

  static String kioskKeyOf(String name) => name
      .trim()
      .toUpperCase()
      .replaceAll(RegExp(r'\s+'), ' ')
      .replaceAll('/', '-');

  String get displayName => formatDisplayName(kioskName);

  String get greetingName {
    final String f = firstName.trim();
    if (f.isEmpty) return displayName;
    return f[0].toUpperCase() + f.substring(1);
  }

  DateTime? get birthDate => DateTime.tryParse(birthdate);

  int? get age {
    final DateTime? b = birthDate;
    if (b == null) return null;
    final DateTime now = DateTime.now();
    int a = now.year - b.year;
    if (now.month < b.month || (now.month == b.month && now.day < b.day)) a--;
    return a < 0 ? null : a;
  }

  String get initials {
    final String a = lastName.trim().isNotEmpty ? lastName.trim()[0] : '';
    final String b = firstName.trim().isNotEmpty ? firstName.trim()[0] : '';
    final String s = (b + a).toUpperCase();
    return s.isEmpty ? '?' : s;
  }

  Resident copyWith({
    String? uid,
    String? email,
    String? lang,
    bool? acceptedTerms,
  }) {
    return Resident(
      uid: uid ?? this.uid,
      lastName: lastName,
      firstName: firstName,
      middleName: middleName,
      gender: gender,
      birthdate: birthdate,
      email: email ?? this.email,
      lang: lang ?? this.lang,
      acceptedTerms: acceptedTerms ?? this.acceptedTerms,
    );
  }

  Map<String, dynamic> toCreateMap() => <String, dynamic>{
        'lastName': lastName.trim(),
        'firstName': firstName.trim(),
        'middleName': middleName.trim(),
        'gender': gender,
        'birthdate': birthdate,
        'email': email.trim(),
        'kioskName': kioskName,
        'lang': lang,
        'acceptedTerms': acceptedTerms,
        'createdAt': FieldValue.serverTimestamp(),
      };

  factory Resident.fromMap(String uid, Map<String, dynamic> m) {
    return Resident(
      uid: uid,
      lastName: (m['lastName'] as String?) ?? '',
      firstName: (m['firstName'] as String?) ?? '',
      middleName: (m['middleName'] as String?) ?? '',
      gender: (m['gender'] as String?) ?? 'Male',
      birthdate: (m['birthdate'] as String?) ?? '',
      email: (m['email'] as String?) ?? '',
      lang: (m['lang'] as String?) ?? 'EN',
      acceptedTerms: (m['acceptedTerms'] as bool?) ?? false,
    );
  }
}
