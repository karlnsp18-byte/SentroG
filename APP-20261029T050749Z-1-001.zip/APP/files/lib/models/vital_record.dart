import 'package:cloud_firestore/cloud_firestore.dart';

enum Metric { temperature, bp, glucose, height, weight, bmi }

double? _toDouble(dynamic v) {
  if (v == null) return null;
  if (v is num) return v.toDouble();
  final String s = v.toString().trim();
  if (s.isEmpty) return null;
  // The kiosk used to store BMI as "21.3  (Normal)" — take the first token.
  return double.tryParse(s.split(RegExp(r'\s+')).first.replaceAll(',', '.'));
}

/// One health measurement session (from the kiosk, or self-reported in the app).
class VitalRecord {
  final String id;
  final DateTime time;
  final double? temperature;
  final int? systolic;
  final int? diastolic;
  final double? glucose;
  final double? height;
  final double? weight;
  final double? bmi;

  /// 'kiosk' | 'app'
  final String source;

  const VitalRecord({
    required this.id,
    required this.time,
    this.temperature,
    this.systolic,
    this.diastolic,
    this.glucose,
    this.height,
    this.weight,
    this.bmi,
    this.source = 'kiosk',
  });

  bool get fromKiosk => source != 'app';
  String? get bpText =>
      (systolic != null && diastolic != null) ? '$systolic/$diastolic' : null;

  bool has(Metric m) {
    switch (m) {
      case Metric.temperature:
        return temperature != null;
      case Metric.bp:
        return systolic != null && diastolic != null;
      case Metric.glucose:
        return glucose != null;
      case Metric.height:
        return height != null;
      case Metric.weight:
        return weight != null;
      case Metric.bmi:
        return bmi != null;
    }
  }

  factory VitalRecord.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final Map<String, dynamic> m = doc.data() ?? <String, dynamic>{};

    DateTime time = DateTime.fromMillisecondsSinceEpoch(0);
    final dynamic ts = m['timestamp'];
    if (ts is Timestamp) {
      time = ts.toDate();
    } else if (m['dateString'] is String) {
      final DateTime? p =
          DateTime.tryParse((m['dateString'] as String).replaceFirst(' ', 'T'));
      if (p != null) time = p;
    }

    int? sys;
    int? dia;
    final dynamic bp = m['bp'];
    if (bp != null) {
      final RegExpMatch? match =
          RegExp(r'^\s*(\d{2,3})\s*/\s*(\d{2,3})\s*$').firstMatch(bp.toString());
      if (match != null) {
        sys = int.tryParse(match.group(1)!);
        dia = int.tryParse(match.group(2)!);
      }
    }

    return VitalRecord(
      id: doc.id,
      time: time,
      temperature: _toDouble(m['temperature']),
      systolic: sys,
      diastolic: dia,
      glucose: _toDouble(m['glucose']),
      height: _toDouble(m['height']),
      weight: _toDouble(m['weight']),
      bmi: _toDouble(m['bmi']),
      source: (m['source'] as String?) ?? 'kiosk',
    );
  }

  /// Firestore map for a self-reported record (see firestore.rules: the app may
  /// only create records with source == 'app').
  Map<String, dynamic> toAppMap(String bmiStatusEn) {
    String two(int n) => n.toString().padLeft(2, '0');
    final Map<String, dynamic> out = <String, dynamic>{
      'timestamp': Timestamp.fromDate(time),
      'dateString':
          '${time.year}-${two(time.month)}-${two(time.day)} ${two(time.hour)}:${two(time.minute)}',
      'source': 'app',
    };
    if (temperature != null) out['temperature'] = temperature;
    if (bpText != null) out['bp'] = bpText;
    if (glucose != null) out['glucose'] = glucose;
    if (height != null) out['height'] = height;
    if (weight != null) out['weight'] = weight;
    if (bmi != null) {
      out['bmi'] = bmi;
      out['bmiStatus'] = bmiStatusEn;
    }
    return out;
  }
}
