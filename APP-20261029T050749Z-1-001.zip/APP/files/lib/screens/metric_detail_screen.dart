import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/health.dart';
import '../core/theme.dart';
import '../models/vital_record.dart';
import '../widgets/common.dart';
import '../widgets/range_bar.dart';
import '../widgets/trend_chart.dart';

/// One metric in detail: big value, status, range bar, trend and past readings.
class MetricDetailScreen extends StatelessWidget {
  final Metric metric;

  /// Newest first.
  final List<VitalRecord> records;

  const MetricDetailScreen({
    super.key,
    required this.metric,
    required this.records,
  });

  @override
  Widget build(BuildContext context) {
    final MetricInfo info = infoOf(metric);
    final List<VitalRecord> mine =
        records.where((VitalRecord r) => r.has(metric)).toList();
    final VitalRecord? latest = mine.isEmpty ? null : mine.first;
    final Status? status = latest == null ? null : statusFor(metric, latest);
    final RangeSpec? spec = rangeFor(metric);
    final double? rv = latest == null ? null : rangeValue(metric, latest);

    return Scaffold(
      appBar: AppBar(title: Text(context.t(info.titleKey))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: ContentWidth(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              if (latest == null)
                EmptyState(
                  icon: info.icon,
                  title: context.t('no_data_metric'),
                  body: context.t('no_data_metric_hint'),
                )
              else ...<Widget>[
                AccentCard(
                  accent: status?.color ?? K.acc,
                  border: status?.color ?? K.bdr,
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Icon(info.icon, color: status?.color ?? K.acc, size: 28),
                          const SizedBox(width: 10),
                          const Spacer(),
                          if (status != null) StatusChip(status: status, large: true),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.end,
                        children: <Widget>[
                          Text(
                            valueText(metric, latest) ?? '—',
                            style: const TextStyle(
                              fontSize: 44,
                              fontWeight: FontWeight.w800,
                              color: K.txt,
                            ),
                          ),
                          if (info.unit.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(left: 6, bottom: 8),
                              child: Text(
                                info.unit,
                                style: const TextStyle(fontSize: 16, color: K.sub),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: <Widget>[
                          Icon(
                            latest.fromKiosk
                                ? Icons.monitor_heart_outlined
                                : Icons.edit_note,
                            size: 16,
                            color: K.sub,
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              '${fmtDateTime(latest.time)}  •  '
                              '${context.t(latest.fromKiosk ? 'src_kiosk' : 'src_app')}',
                              style: const TextStyle(color: K.sub, fontSize: 13),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                if (spec != null && rv != null) ...<Widget>[
                  const SizedBox(height: 16),
                  SectionTitle(context.t('where_you_are')),
                  AccentCard(
                    accent: K.bdr,
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        RangeBar(spec: spec, value: rv),
                        if (metric == Metric.bp)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(
                              context.t('bp_systolic_note'),
                              style: const TextStyle(fontSize: 11, color: K.sub),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                SectionTitle(context.t('trend')),
                _trend(context, mine),
              ],
              const SizedBox(height: 16),
              SectionTitle(context.t('about_reading')),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: K.s2,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  context.t('about_${metric.name}'),
                  style: const TextStyle(height: 1.45, color: K.txt),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                context.t('disclaimer'),
                style: const TextStyle(
                  fontSize: 11,
                  fontStyle: FontStyle.italic,
                  color: K.sub,
                ),
              ),
              if (mine.isNotEmpty) ...<Widget>[
                const SizedBox(height: 16),
                SectionTitle(context.t('past_readings')),
                for (final VitalRecord r in mine.take(20)) _row(context, r),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _trend(BuildContext context, List<VitalRecord> mine) {
    // Chart the last 10 readings, oldest → newest.
    final List<VitalRecord> pts = mine.take(10).toList().reversed.toList();
    if (pts.length < 2) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: K.surface,
          border: Border.all(color: K.bdr),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          context.t('trend_need_two'),
          style: const TextStyle(color: K.sub),
        ),
      );
    }

    final List<TrendSeries> series = <TrendSeries>[];
    if (metric == Metric.bp) {
      series.add(TrendSeries(
        values: pts.map((VitalRecord r) => r.systolic!.toDouble()).toList(),
        dotColors: pts.map((VitalRecord r) => statusFor(metric, r)?.color ?? K.acc).toList(),
        lineColor: K.hdr2,
      ));
      series.add(TrendSeries(
        values: pts.map((VitalRecord r) => r.diastolic!.toDouble()).toList(),
        dotColors: pts.map((VitalRecord _) => K.mut).toList(),
        lineColor: K.mut,
      ));
    } else {
      series.add(TrendSeries(
        values: pts.map((VitalRecord r) => rawValue(r)).toList(),
        dotColors: pts.map((VitalRecord r) => statusFor(metric, r)?.color ?? K.acc).toList(),
        lineColor: K.hdr2,
      ));
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(8, 12, 8, 8),
      decoration: BoxDecoration(
        color: K.surface,
        border: Border.all(color: K.bdr),
        borderRadius: BorderRadius.circular(8),
      ),
      child: TrendChart(
        series: series,
        startLabel: fmtDate(pts.first.time),
        endLabel: fmtDate(pts.last.time),
      ),
    );
  }

  double rawValue(VitalRecord r) {
    switch (metric) {
      case Metric.temperature:
        return r.temperature!;
      case Metric.bp:
        return r.systolic!.toDouble();
      case Metric.glucose:
        return r.glucose!;
      case Metric.height:
        return r.height!;
      case Metric.weight:
        return r.weight!;
      case Metric.bmi:
        return r.bmi!;
    }
  }

  Widget _row(BuildContext context, VitalRecord r) {
    final Status? s = statusFor(metric, r);
    final MetricInfo info = infoOf(metric);
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: K.surface,
        border: Border.all(color: K.bdr),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 6,
            height: 36,
            decoration: BoxDecoration(
              color: s?.color ?? K.bdr,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  '${valueText(metric, r) ?? '—'} ${info.unit}'.trim(),
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
                Text(
                  fmtDateTime(r.time),
                  style: const TextStyle(fontSize: 12, color: K.sub),
                ),
              ],
            ),
          ),
          if (s != null) StatusChip(status: s),
        ],
      ),
    );
  }
}
