import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../models/resident.dart';
import '../services/auth_service.dart';
import '../widgets/common.dart';
import 'auth/auth_flow.dart';
import 'auth/complete_profile_screen.dart';
import 'auth/terms_screen.dart';
import 'shell.dart';
import 'welcome_interstitial.dart';

/// Decides what to show: login flow, profile completion, terms, the welcome
/// interstitial, or the main app.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: AuthService.busy,
      builder: (BuildContext context, bool busy, Widget? _) {
        return StreamBuilder<User?>(
          stream: AuthService.authChanges,
          builder: (BuildContext context, AsyncSnapshot<User?> snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Splash();
            }
            final User? user = snap.data;
            // While register() is running keep the form on screen so it can
            // show errors and keep what the resident typed.
            if (user == null || busy) return const AuthFlow();
            return ProfileGate(key: ValueKey<String>(user.uid), user: user);
          },
        );
      },
    );
  }
}

class ProfileGate extends StatefulWidget {
  final User user;
  const ProfileGate({super.key, required this.user});

  @override
  State<ProfileGate> createState() => _ProfileGateState();
}

class _ProfileGateState extends State<ProfileGate> {
  late final Stream<DocumentSnapshot<Map<String, dynamic>>> _doc =
      AuthService.residentDoc(widget.user.uid);

  bool _showWelcome = false;
  bool _langAdopted = false;
  int _initialTab = 0;

  Future<void> _agree() async {
    // Show the interstitial as soon as the (local) write lands.
    setState(() => _showWelcome = true);
    try {
      await AuthService.acceptTerms(widget.user.uid);
    } catch (e) {
      if (!mounted) return;
      setState(() => _showWelcome = false);
      showSnack(context, context.t(AuthService.errorKey(e)), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _doc,
      builder: (BuildContext context,
          AsyncSnapshot<DocumentSnapshot<Map<String, dynamic>>> snap) {
        if (snap.hasError) {
          return Scaffold(
            body: Column(
              children: <Widget>[
                const KioskHeader(),
                Expanded(
                  child: EmptyState(
                    icon: Icons.cloud_off,
                    title: context.t('err_load_title'),
                    body: context.t(AuthService.errorKey(snap.error!)),
                    action: OutlinedButton(
                      onPressed: AuthService.signOut,
                      child: Text(context.t('logout')),
                    ),
                  ),
                ),
              ],
            ),
          );
        }
        if (!snap.hasData) return const Splash();
        final DocumentSnapshot<Map<String, dynamic>> d = snap.data!;

        if (!d.exists) {
          // Offline on first launch: do not mistake "not cached yet" for "no profile".
          if (d.metadata.isFromCache) {
            return Splash(message: context.t('connecting'));
          }
          return CompleteProfileScreen(user: widget.user);
        }

        final Resident r = Resident.fromMap(widget.user.uid, d.data()!);
        // Adopt the saved language once per login (later changes come from the
        // user's own toggle, so they must not be overwritten by a stale snapshot).
        if (!_langAdopted) {
          _langAdopted = true;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) context.app.setLang(r.lang);
          });
        }

        if (!r.acceptedTerms) {
          return TermsScreen(onAgree: _agree, onDecline: AuthService.signOut);
        }
        if (_showWelcome) {
          return WelcomeInterstitial(
            resident: r,
            onChoose: (int tab) => setState(() {
              _showWelcome = false;
              _initialTab = tab;
            }),
          );
        }
        return Shell(
          key: ValueKey<String>(r.uid),
          resident: r,
          initialIndex: _initialTab,
        );
      },
    );
  }
}
