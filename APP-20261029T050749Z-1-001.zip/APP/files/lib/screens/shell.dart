import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/health.dart';
import '../core/theme.dart';
import '../models/resident.dart';
import '../models/vital_record.dart';
import '../services/auth_service.dart';
import '../services/vitals_service.dart';
import '../widgets/common.dart';
import 'add_reading_screen.dart';
import 'history_screen.dart';
import 'home_screen.dart';
import 'pass_screen.dart';
import 'profile_screen.dart';

/// Bottom-navigation shell. Subscribes to the resident's history once and
/// hands the records to every tab.
class Shell extends StatefulWidget {
  final Resident resident;
  final int initialIndex;
  const Shell({super.key, required this.resident, this.initialIndex = 0});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  late int _index = widget.initialIndex;
  late final Stream<List<VitalRecord>> _stream =
      VitalsService.historyStream(widget.resident.uid);

  void _goTo(int i) => setState(() => _index = i);

  void _openAdd(List<VitalRecord> records) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext _) => AddReadingScreen(
          uid: widget.resident.uid,
          latest: latestFrom(records),
        ),
      ),
    );
  }

  Widget _tab(List<VitalRecord> records) {
    switch (_index) {
      case 1:
        return HistoryScreen(uid: widget.resident.uid, records: records);
      case 2:
        return PassScreen(resident: widget.resident);
      case 3:
        return ProfileScreen(resident: widget.resident, recordCount: records.length);
      default:
        return HomeScreen(
          resident: widget.resident,
          records: records,
          onShowPass: () => _goTo(2),
          onAdd: () => _openAdd(records),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<VitalRecord>>(
      stream: _stream,
      builder: (BuildContext context, AsyncSnapshot<List<VitalRecord>> snap) {
        final List<VitalRecord> records = snap.data ?? const <VitalRecord>[];

        Widget body;
        if (snap.hasError) {
          body = Column(
            children: <Widget>[
              const KioskHeader(),
              Expanded(
                child: EmptyState(
                  icon: Icons.cloud_off,
                  title: context.t('err_load_title'),
                  body: context.t(AuthService.errorKey(snap.error!)),
                ),
              ),
            ],
          );
        } else if (!snap.hasData) {
          body = Column(
            children: const <Widget>[
              KioskHeader(),
              Expanded(child: Center(child: CircularProgressIndicator())),
            ],
          );
        } else {
          body = _tab(records);
        }

        return Scaffold(
          body: body,
          floatingActionButton: (_index == 0 && snap.hasData)
              ? FloatingActionButton.extended(
                  onPressed: () => _openAdd(records),
                  backgroundColor: K.grn,
                  foregroundColor: Colors.white,
                  icon: const Icon(Icons.add),
                  label: Text(context.t('log_reading')),
                )
              : null,
          bottomNavigationBar: NavigationBar(
            selectedIndex: _index,
            onDestinationSelected: _goTo,
            destinations: <NavigationDestination>[
              NavigationDestination(
                icon: const Icon(Icons.health_and_safety_outlined),
                selectedIcon: const Icon(Icons.health_and_safety),
                label: context.t('nav_vitals'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.history_outlined),
                selectedIcon: const Icon(Icons.history),
                label: context.t('nav_history'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.qr_code_2_outlined),
                selectedIcon: const Icon(Icons.qr_code_2),
                label: context.t('nav_pass'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.person_outline),
                selectedIcon: const Icon(Icons.person),
                label: context.t('nav_profile'),
              ),
            ],
          ),
        );
      },
    );
  }
}
