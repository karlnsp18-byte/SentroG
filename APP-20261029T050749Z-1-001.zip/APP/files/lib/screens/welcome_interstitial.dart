import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import '../models/resident.dart';
import '../widgets/common.dart';

/// Shown once after registration + terms (the kiosk's "welcome interstitial").
class WelcomeInterstitial extends StatelessWidget {
  final Resident resident;

  /// 0 = health records, 2 = kiosk pass
  final void Function(int tab) onChoose;

  const WelcomeInterstitial({
    super.key,
    required this.resident,
    required this.onChoose,
  });

  Widget _action(
    BuildContext context, {
    required Color color,
    required double border,
    required IconData icon,
    required String titleKey,
    required String descKey,
    required String buttonKey,
    required int tab,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: K.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color, width: border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(icon, color: color, size: 26),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  context.t(titleKey),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: K.hdr,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(context.t(descKey), style: const TextStyle(color: K.sub, height: 1.4)),
          const SizedBox(height: 14),
          ElevatedButton(
            onPressed: () => onChoose(tab),
            style: ElevatedButton.styleFrom(backgroundColor: color),
            child: Text(context.t(buttonKey)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: <Widget>[
          const KioskHeader(),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: ContentWidth(
                child: Column(
                  children: <Widget>[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: K.surface,
                        border: Border.all(color: K.bdr),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: <Widget>[
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: const BoxDecoration(
                              color: K.accLt,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.local_hospital,
                              size: 38,
                              color: K.hdr,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  context.tf('wi_welcome',
                                      <String, String>{'name': resident.greetingName}),
                                  style: const TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: K.hdr,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  context.t('wi_reg_success'),
                                  style: const TextStyle(color: K.sub, height: 1.4),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    _action(
                      context,
                      color: K.grn,
                      border: 3,
                      icon: Icons.qr_code_2,
                      titleKey: 'wi_pass_title',
                      descKey: 'wi_pass_desc',
                      buttonKey: 'wi_pass_btn',
                      tab: 2,
                    ),
                    const SizedBox(height: 14),
                    _action(
                      context,
                      color: K.acc,
                      border: 2,
                      icon: Icons.bar_chart,
                      titleKey: 'wi_dash_title',
                      descKey: 'wi_dash_desc',
                      buttonKey: 'wi_dash_btn',
                      tab: 0,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
