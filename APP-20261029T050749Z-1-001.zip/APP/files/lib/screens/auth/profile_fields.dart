import 'package:flutter/material.dart';

import '../../core/app_state.dart';
import '../../core/health.dart';
import '../../core/theme.dart';
import '../../models/resident.dart';

/// Holds the values of the shared "who are you" fields (register + complete profile).
class ProfileFieldsController {
  final TextEditingController last = TextEditingController();
  final TextEditingController first = TextEditingController();
  final TextEditingController middle = TextEditingController();
  String? gender;
  DateTime? birth;

  bool get hasPreview =>
      last.text.trim().isNotEmpty && first.text.trim().isNotEmpty;
  bool get genderMissing => gender == null;
  bool get birthMissing => birth == null;

  String get birthString {
    final DateTime b = birth!;
    String two(int n) => n.toString().padLeft(2, '0');
    return '${b.year.toString().padLeft(4, '0')}-${two(b.month)}-${two(b.day)}';
  }

  /// Only call after validation passed.
  Resident toResident({required String email, required String lang}) {
    return Resident(
      uid: '',
      lastName: last.text.trim(),
      firstName: first.text.trim(),
      middleName: middle.text.trim(),
      gender: gender ?? 'Male',
      birthdate: birthString,
      email: email.trim(),
      lang: lang,
    );
  }

  void dispose() {
    last.dispose();
    first.dispose();
    middle.dispose();
  }
}

class ProfileFields extends StatefulWidget {
  final ProfileFieldsController controller;
  final bool showErrors;
  final VoidCallback onChanged;

  const ProfileFields({
    super.key,
    required this.controller,
    required this.showErrors,
    required this.onChanged,
  });

  @override
  State<ProfileFields> createState() => _ProfileFieldsState();
}

class _ProfileFieldsState extends State<ProfileFields> {
  ProfileFieldsController get c => widget.controller;

  String? _nameValidator(String? v, {required bool required}) {
    final String s = (v ?? '').trim();
    if (s.isEmpty) return required ? context.t('req') : null;
    if (!RegExp(r"^[A-Za-zÀ-ÿ .'\-]+$").hasMatch(s)) return context.t('name_chars');
    return null;
  }

  Future<void> _pickBirth() async {
    final DateTime now = DateTime.now();
    final DateTime? d = await showDatePicker(
      context: context,
      initialDate: c.birth ?? DateTime(now.year - 25, 1, 1),
      firstDate: DateTime(1900),
      lastDate: now,
      helpText: context.t('birthdate'),
    );
    if (d != null) {
      setState(() => c.birth = d);
      widget.onChanged();
    }
  }

  @override
  Widget build(BuildContext context) {
    final Resident preview = c.toResidentPreview();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: TextFormField(
                controller: c.last,
                textCapitalization: TextCapitalization.words,
                decoration: InputDecoration(labelText: context.t('last_name')),
                validator: (String? v) => _nameValidator(v, required: true),
                onChanged: (_) {
                  setState(() {});
                  widget.onChanged();
                },
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextFormField(
                controller: c.first,
                textCapitalization: TextCapitalization.words,
                decoration: InputDecoration(labelText: context.t('first_name')),
                validator: (String? v) => _nameValidator(v, required: true),
                onChanged: (_) {
                  setState(() {});
                  widget.onChanged();
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: c.middle,
          textCapitalization: TextCapitalization.words,
          decoration: InputDecoration(
            labelText: '${context.t('middle_name')} (${context.t('optional')})',
          ),
          validator: (String? v) => _nameValidator(v, required: false),
          onChanged: (_) {
            setState(() {});
            widget.onChanged();
          },
        ),
        if (c.hasPreview) ...<Widget>[
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: K.accLt,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              '${context.t('kiosk_name_hint')}\n${preview.kioskName}',
              style: const TextStyle(fontSize: 12, color: K.hdr, height: 1.4),
            ),
          ),
        ],
        const SizedBox(height: 16),
        Text(
          context.t('gender'),
          style: const TextStyle(fontWeight: FontWeight.bold, color: K.acc),
        ),
        const SizedBox(height: 6),
        Wrap(
          spacing: 10,
          children: <Widget>[
            for (final String g in <String>['Male', 'Female'])
              ChoiceChip(
                label: Text(context.t(g == 'Male' ? 'male' : 'female')),
                selected: c.gender == g,
                selectedColor: K.accLt,
                onSelected: (bool _) {
                  setState(() => c.gender = g);
                  widget.onChanged();
                },
              ),
          ],
        ),
        if (widget.showErrors && c.genderMissing)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              context.t('req'),
              style: const TextStyle(color: K.red, fontSize: 12),
            ),
          ),
        const SizedBox(height: 16),
        Text(
          context.t('birthdate'),
          style: const TextStyle(fontWeight: FontWeight.bold, color: K.acc),
        ),
        const SizedBox(height: 6),
        InkWell(
          onTap: _pickBirth,
          borderRadius: BorderRadius.circular(8),
          child: InputDecorator(
            decoration: InputDecoration(
              suffixIcon: const Icon(Icons.calendar_month, color: K.acc),
              errorText: (widget.showErrors && c.birthMissing)
                  ? context.t('req')
                  : null,
            ),
            child: Text(
              c.birth == null ? context.t('pick_date') : fmtDate(c.birth!),
              style: TextStyle(color: c.birth == null ? K.mut : K.txt),
            ),
          ),
        ),
      ],
    );
  }
}

extension on ProfileFieldsController {
  /// Name preview that works before gender/birthdate are chosen.
  Resident toResidentPreview() => Resident(
        uid: '',
        lastName: last.text,
        firstName: first.text,
        middleName: middle.text,
        gender: gender ?? 'Male',
        birthdate: '',
        email: '',
      );
}
