import 'package:flutter/material.dart';

import '../../core/app_state.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';

/// Data-privacy consent + liability disclaimer (same text as the kiosk).
/// With [readOnly] it just shows the text with a Close button.
class TermsScreen extends StatelessWidget {
  final VoidCallback? onAgree;
  final VoidCallback? onDecline;
  final bool readOnly;

  const TermsScreen({
    super.key,
    this.onAgree,
    this.onDecline,
    this.readOnly = false,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: <Widget>[
          const KioskHeader(),
          Expanded(
            child: ContentWidth(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      context.t('tnc_title'),
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: K.hdr,
                      ),
                    ),
                    Text(
                      context.t('tnc_sub'),
                      style: const TextStyle(color: K.sub, fontSize: 12),
                    ),
                    const SizedBox(height: 10),
                    Expanded(
                      child: Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: K.surface,
                          border: Border.all(color: K.bdr),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Scrollbar(
                          child: SingleChildScrollView(
                            padding: const EdgeInsets.all(16),
                            child: Text(
                              context.t('tnc_body'),
                              style: const TextStyle(fontSize: 13, height: 1.45),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (readOnly)
                      ElevatedButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: Text(context.t('close')),
                      )
                    else
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: OutlinedButton(
                              onPressed: onDecline,
                              style: OutlinedButton.styleFrom(
                                foregroundColor: K.red,
                                side: const BorderSide(color: K.red, width: 1.5),
                              ),
                              child: Text(context.t('tnc_decline')),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: onAgree,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: K.grn,
                              ),
                              child: Text(context.t('tnc_agree')),
                            ),
                          ),
                        ],
                      ),
                    SafeArea(top: false, child: const SizedBox(height: 4)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
