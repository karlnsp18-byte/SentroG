import 'package:flutter/material.dart';

import '../../core/app_state.dart';
import '../../core/theme.dart';
import '../../models/resident.dart';
import '../../services/auth_service.dart';
import '../../widgets/common.dart';
import 'profile_fields.dart';

enum _AuthView { welcome, login, register }

final RegExp _emailRe = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

/// Welcome → Login / Register, in the kiosk's visual style.
class AuthFlow extends StatefulWidget {
  const AuthFlow({super.key});

  @override
  State<AuthFlow> createState() => _AuthFlowState();
}

class _AuthFlowState extends State<AuthFlow> {
  _AuthView _view = _AuthView.welcome;

  void _go(_AuthView v) => setState(() => _view = v);

  Widget _body() {
    switch (_view) {
      case _AuthView.login:
        return LoginView(
          key: const ValueKey<String>('login'),
          onRegister: () => _go(_AuthView.register),
        );
      case _AuthView.register:
        return RegisterView(
          key: const ValueKey<String>('register'),
          onLogin: () => _go(_AuthView.login),
        );
      case _AuthView.welcome:
        return WelcomeView(
          key: const ValueKey<String>('welcome'),
          onLogin: () => _go(_AuthView.login),
          onRegister: () => _go(_AuthView.register),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: K.bg,
      body: Column(
        children: <Widget>[
          KioskHeader(
            actions: <Widget>[
              if (_view != _AuthView.welcome)
                TextButton.icon(
                  onPressed: () => _go(_AuthView.welcome),
                  icon: const Icon(Icons.arrow_back, color: Colors.white, size: 18),
                  label: Text(
                    context.t('back'),
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
            ],
          ),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              child: _body(),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Welcome ─────────────────────────────────────────────────────────────────

class WelcomeView extends StatelessWidget {
  final VoidCallback onLogin;
  final VoidCallback onRegister;
  const WelcomeView({super.key, required this.onLogin, required this.onRegister});

  Widget _perk(BuildContext context, IconData icon, String key) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Icon(icon, size: 18, color: K.acc),
        const SizedBox(width: 6),
        Text(context.t(key), style: const TextStyle(fontSize: 13, color: K.sub)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: ContentWidth(
        maxWidth: 520,
        child: Column(
          children: <Widget>[
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              padding: const EdgeInsets.symmetric(vertical: 26, horizontal: 20),
              decoration: BoxDecoration(
                color: K.hdr,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: <Widget>[
                  const CrossBadge(size: 96),
                  const SizedBox(height: 14),
                  const Text(
                    'SENTRO GINHAWA',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.8,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    context.t('wsub'),
                    style: const TextStyle(color: K.skyBlue, fontSize: 13),
                  ),
                  Container(
                    height: 2,
                    width: 200,
                    margin: const EdgeInsets.symmetric(vertical: 14),
                    color: K.gld,
                  ),
                  Text(
                    context.t('wtag'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: K.accLt, fontSize: 14),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 26, 20, 20),
              child: Column(
                children: <Widget>[
                  Text(
                    context.t('welcome'),
                    style: const TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                      color: K.hdr,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    context.t('proceed'),
                    style: const TextStyle(color: K.sub, fontSize: 14),
                  ),
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: onLogin,
                      child: Text(context.t('b_exist')),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: onRegister,
                      child: Text(context.t('b_new')),
                    ),
                  ),
                  const SizedBox(height: 22),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 16,
                    runSpacing: 8,
                    children: <Widget>[
                      _perk(context, Icons.qr_code_2, 'perk_pass'),
                      _perk(context, Icons.show_chart, 'perk_track'),
                      _perk(context, Icons.lock_outline, 'perk_private'),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Login ───────────────────────────────────────────────────────────────────

class LoginView extends StatefulWidget {
  final VoidCallback onRegister;
  const LoginView({super.key, required this.onRegister});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final GlobalKey<FormState> _form = GlobalKey<FormState>();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _pass = TextEditingController();
  bool _obscure = true;
  bool _loading = false;
  String? _errorKey;

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _errorKey = null;
    });
    try {
      await AuthService.login(_email.text, _pass.text);
    } catch (e) {
      if (mounted) setState(() => _errorKey = AuthService.errorKey(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _forgot() async {
    final TextEditingController c =
        TextEditingController(text: _email.text.trim());
    final String? email = await showDialog<String>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: Text(ctx.t('forgot_title')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(ctx.t('forgot_body')),
            const SizedBox(height: 12),
            TextField(
              controller: c,
              keyboardType: TextInputType.emailAddress,
              decoration: InputDecoration(labelText: ctx.t('email')),
            ),
          ],
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(ctx.t('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(c.text.trim()),
            child: Text(ctx.t('send')),
          ),
        ],
      ),
    );
    if (email == null || email.isEmpty) return;
    try {
      await AuthService.resetPassword(email);
      if (mounted) showSnack(context, context.t('forgot_sent'));
    } catch (e) {
      if (mounted) showSnack(context, context.t(AuthService.errorKey(e)), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: ContentWidth(
        maxWidth: 480,
        child: AccentCard(
          accent: K.acc,
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _form,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  context.t('ltitle'),
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                Text(
                  context.t('lhint'),
                  style: const TextStyle(color: K.sub, fontSize: 13),
                ),
                const SizedBox(height: 18),
                if (_errorKey != null) ...<Widget>[
                  ErrorBox(context.t(_errorKey!)),
                  const SizedBox(height: 12),
                ],
                TextFormField(
                  controller: _email,
                  keyboardType: TextInputType.emailAddress,
                  autofillHints: const <String>[AutofillHints.email],
                  decoration: InputDecoration(labelText: context.t('email')),
                  validator: (String? v) {
                    final String s = (v ?? '').trim();
                    if (s.isEmpty) return context.t('req');
                    if (!_emailRe.hasMatch(s)) return context.t('err_invalid_email');
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _pass,
                  obscureText: _obscure,
                  autofillHints: const <String>[AutofillHints.password],
                  decoration: InputDecoration(
                    labelText: context.t('password'),
                    suffixIcon: IconButton(
                      icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                  validator: (String? v) =>
                      (v ?? '').isEmpty ? context.t('req') : null,
                  onFieldSubmitted: (_) => _submit(),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: _loading ? null : _forgot,
                    child: Text(context.t('forgot')),
                  ),
                ),
                const SizedBox(height: 4),
                if (_loading)
                  const Center(child: CircularProgressIndicator())
                else
                  ElevatedButton(
                    onPressed: _submit,
                    child: Text(context.t('b_login')),
                  ),
                Center(
                  child: TextButton(
                    onPressed: widget.onRegister,
                    child: Text(context.t('no_account')),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Register ────────────────────────────────────────────────────────────────

class RegisterView extends StatefulWidget {
  final VoidCallback onLogin;
  const RegisterView({super.key, required this.onLogin});

  @override
  State<RegisterView> createState() => _RegisterViewState();
}

class _RegisterViewState extends State<RegisterView> {
  final GlobalKey<FormState> _form = GlobalKey<FormState>();
  final ProfileFieldsController _pf = ProfileFieldsController();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _pass = TextEditingController();
  final TextEditingController _pass2 = TextEditingController();
  bool _obscure = true;
  bool _loading = false;
  bool _tried = false;
  String? _errorKey;

  @override
  void dispose() {
    _pf.dispose();
    _email.dispose();
    _pass.dispose();
    _pass2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => _tried = true);
    final bool formOk = _form.currentState!.validate();
    if (!formOk || _pf.genderMissing || _pf.birthMissing) return;

    setState(() {
      _loading = true;
      _errorKey = null;
    });
    try {
      final Resident draft =
          _pf.toResident(email: _email.text, lang: context.app.lang);
      await AuthService.register(
        email: _email.text,
        password: _pass.text,
        draft: draft,
      );
    } catch (e) {
      if (mounted) setState(() => _errorKey = AuthService.errorKey(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: ContentWidth(
        maxWidth: 480,
        child: AccentCard(
          accent: K.grn,
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _form,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  context.t('rtitle'),
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                Text(
                  context.t('rhint'),
                  style: const TextStyle(color: K.sub, fontSize: 13),
                ),
                const SizedBox(height: 18),
                if (_errorKey != null) ...<Widget>[
                  ErrorBox(context.t(_errorKey!)),
                  const SizedBox(height: 12),
                ],
                ProfileFields(
                  controller: _pf,
                  showErrors: _tried,
                  onChanged: () => setState(() {}),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(labelText: context.t('email')),
                  validator: (String? v) {
                    final String s = (v ?? '').trim();
                    if (s.isEmpty) return context.t('req');
                    if (!_emailRe.hasMatch(s)) return context.t('err_invalid_email');
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _pass,
                  obscureText: _obscure,
                  decoration: InputDecoration(
                    labelText: context.t('password'),
                    helperText: context.t('pass_hint'),
                    suffixIcon: IconButton(
                      icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                  validator: (String? v) {
                    final String s = v ?? '';
                    if (s.isEmpty) return context.t('req');
                    if (s.length < 8) return context.t('err_weak_password');
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _pass2,
                  obscureText: _obscure,
                  decoration:
                      InputDecoration(labelText: context.t('password_again')),
                  validator: (String? v) =>
                      (v ?? '') == _pass.text ? null : context.t('pass_mismatch'),
                ),
                const SizedBox(height: 20),
                if (_loading)
                  const Center(child: CircularProgressIndicator())
                else
                  ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(backgroundColor: K.grn),
                    child: Text(context.t('b_register')),
                  ),
                Center(
                  child: TextButton(
                    onPressed: widget.onLogin,
                    child: Text(context.t('have_account')),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
