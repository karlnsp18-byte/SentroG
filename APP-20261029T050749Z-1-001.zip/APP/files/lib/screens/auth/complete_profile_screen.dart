import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../core/app_state.dart';
import '../../core/theme.dart';
import '../../models/resident.dart';
import '../../services/auth_service.dart';
import '../../widgets/common.dart';
import 'profile_fields.dart';

/// For accounts that exist in Firebase Auth but have no resident profile yet
/// (e.g. accounts created by an older version of the app).
class CompleteProfileScreen extends StatefulWidget {
  final User user;
  const CompleteProfileScreen({super.key, required this.user});

  @override
  State<CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends State<CompleteProfileScreen> {
  final GlobalKey<FormState> _form = GlobalKey<FormState>();
  final ProfileFieldsController _pf = ProfileFieldsController();
  bool _loading = false;
  bool _tried = false;
  String? _errorKey;

  @override
  void dispose() {
    _pf.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => _tried = true);
    final bool ok = _form.currentState!.validate();
    if (!ok || _pf.genderMissing || _pf.birthMissing) return;
    setState(() {
      _loading = true;
      _errorKey = null;
    });
    try {
      final Resident r = _pf
          .toResident(email: widget.user.email ?? '', lang: context.app.lang)
          .copyWith(uid: widget.user.uid);
      await AuthService.createProfile(r);
    } catch (e) {
      if (mounted) setState(() => _errorKey = AuthService.errorKey(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: <Widget>[
          KioskHeader(
            actions: <Widget>[
              TextButton(
                onPressed: AuthService.signOut,
                child: Text(
                  context.t('logout'),
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: ContentWidth(
                maxWidth: 480,
                child: AccentCard(
                  accent: K.gld,
                  padding: const EdgeInsets.all(20),
                  child: Form(
                    key: _form,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          context.t('complete_title'),
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          context.t('complete_hint'),
                          style: const TextStyle(color: K.sub, fontSize: 13),
                        ),
                        const SizedBox(height: 18),
                        if (_errorKey != null) ...<Widget>[
                          ErrorBox(context.t(_errorKey!)),
                          const SizedBox(height: 12),
                        ],
                        ProfileFields(
                          controller: _pf,
                          showErrors: _tried,
                          onChanged: () => setState(() {}),
                        ),
                        const SizedBox(height: 20),
                        if (_loading)
                          const Center(child: CircularProgressIndicator())
                        else
                          ElevatedButton(
                            onPressed: _submit,
                            style: ElevatedButton.styleFrom(backgroundColor: K.grn),
                            child: Text(context.t('save_continue')),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
