import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/health.dart';
import '../core/theme.dart';
import '../models/resident.dart';
import '../services/auth_service.dart';
import '../widgets/common.dart';
import 'auth/terms_screen.dart';

class ProfileScreen extends StatelessWidget {
  final Resident resident;
  final int recordCount;
  const ProfileScreen({
    super.key,
    required this.resident,
    required this.recordCount,
  });

  Widget _row(BuildContext context, IconData icon, String labelKey, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: <Widget>[
          Icon(icon, size: 20, color: K.acc),
          const SizedBox(width: 12),
          Expanded(
            child: Text(context.t(labelKey), style: const TextStyle(color: K.sub)),
          ),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _delete(BuildContext context) async {
    final bool ok = await confirmDialog(
      context,
      title: context.t('delete_account'),
      body: context.t('delete_account_body'),
      confirmLabel: context.t('continue_btn'),
      danger: true,
    );
    if (!ok || !context.mounted) return;

    final TextEditingController pw = TextEditingController();
    final String? password = await showDialog<String>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: Text(ctx.t('confirm_password')),
        content: TextField(
          controller: pw,
          obscureText: true,
          decoration: InputDecoration(labelText: ctx.t('password')),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(ctx.t('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(pw.text),
            style: TextButton.styleFrom(foregroundColor: K.red),
            child: Text(ctx.t('delete')),
          ),
        ],
      ),
    );
    if (password == null || password.isEmpty || !context.mounted) return;

    try {
      await AuthService.deleteAccount(password);
      // The auth stream now returns null and the app goes back to the welcome screen.
    } catch (e) {
      if (context.mounted) {
        showSnack(context, context.t(AuthService.errorKey(e)), error: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final int? age = resident.age;
    final DateTime? bd = resident.birthDate;

    return Column(
      children: <Widget>[
        const KioskHeader(),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: <Widget>[
              ContentWidth(
                maxWidth: 520,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    AccentCard(
                      accent: K.acc,
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              CircleAvatar(
                                radius: 28,
                                backgroundColor: K.hdr,
                                child: Text(
                                  resident.initials,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(
                                      resident.displayName,
                                      style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: K.hdr,
                                      ),
                                    ),
                                    Text(
                                      resident.email,
                                      style: const TextStyle(color: K.sub, fontSize: 13),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const Divider(height: 24),
                          _row(
                            context,
                            Icons.wc,
                            'gender',
                            context.t(resident.gender == 'Male' ? 'male' : 'female'),
                          ),
                          _row(
                            context,
                            Icons.cake_outlined,
                            'birthdate',
                            bd == null
                                ? '—'
                                : '${fmtDate(bd)}${age != null ? ' ($age)' : ''}',
                          ),
                          _row(
                            context,
                            Icons.monitor_heart_outlined,
                            'records_count',
                            '$recordCount',
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      context.t('name_locked'),
                      style: const TextStyle(fontSize: 11, color: K.sub),
                    ),
                    const SizedBox(height: 16),
                    SectionTitle(context.t('language')),
                    SegmentedButton<String>(
                      segments: const <ButtonSegment<String>>[
                        ButtonSegment<String>(value: 'EN', label: Text('English')),
                        ButtonSegment<String>(value: 'FIL', label: Text('Filipino')),
                      ],
                      selected: <String>{context.app.lang},
                      onSelectionChanged: (Set<String> s) {
                        context.app.setLang(s.first);
                        AuthService.saveLang(s.first);
                      },
                    ),
                    const SizedBox(height: 20),
                    SectionTitle(context.t('privacy')),
                    OutlinedButton.icon(
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (BuildContext _) =>
                              const TermsScreen(readOnly: true),
                        ),
                      ),
                      icon: const Icon(Icons.description_outlined),
                      label: Text(context.t('view_terms')),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () => _delete(context),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: K.red,
                        side: const BorderSide(color: K.red, width: 1.5),
                      ),
                      icon: const Icon(Icons.delete_forever_outlined),
                      label: Text(context.t('delete_account')),
                    ),
                    const SizedBox(height: 22),
                    ElevatedButton.icon(
                      onPressed: AuthService.signOut,
                      icon: const Icon(Icons.logout),
                      label: Text(context.t('logout')),
                    ),
                    const SizedBox(height: 16),
                    Center(
                      child: Text(
                        'Sentro Ginhawa • v1.0.0',
                        style: const TextStyle(color: K.mut, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
