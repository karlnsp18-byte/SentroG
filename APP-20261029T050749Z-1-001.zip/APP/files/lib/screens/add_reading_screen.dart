import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/health.dart';
import '../core/theme.dart';
import '../models/vital_record.dart';
import '../services/auth_service.dart';
import '../services/vitals_service.dart';
import '../widgets/common.dart';

/// Self-reported ("home") reading. Saved with source = 'app' so it is always
/// labelled differently from kiosk measurements.
class AddReadingScreen extends StatefulWidget {
  final String uid;
  final LatestVitals latest;
  const AddReadingScreen({super.key, required this.uid, required this.latest});

  @override
  State<AddReadingScreen> createState() => _AddReadingScreenState();
}

class _AddReadingScreenState extends State<AddReadingScreen> {
  final GlobalKey<FormState> _form = GlobalKey<FormState>();
  final TextEditingController _temp = TextEditingController();
  final TextEditingController _sys = TextEditingController();
  final TextEditingController _dia = TextEditingController();
  final TextEditingController _glu = TextEditingController();
  final TextEditingController _ht = TextEditingController();
  final TextEditingController _wt = TextEditingController();
  DateTime _when = DateTime.now();
  bool _saving = false;
  String? _errorKey;

  @override
  void dispose() {
    _temp.dispose();
    _sys.dispose();
    _dia.dispose();
    _glu.dispose();
    _ht.dispose();
    _wt.dispose();
    super.dispose();
  }

  double? _d(TextEditingController c) =>
      double.tryParse(c.text.trim().replaceAll(',', '.'));

  /// Optional number field: empty is fine, otherwise it must be inside [lo, hi].
  String? _range(String? v, double lo, double hi) {
    final String s = (v ?? '').trim();
    if (s.isEmpty) return null;
    final double? n = double.tryParse(s.replaceAll(',', '.'));
    if (n == null) return context.t('err_number');
    if (n < lo || n > hi) {
      return context.tf('err_range', <String, String>{
        'lo': lo.toStringAsFixed(lo == lo.roundToDouble() ? 0 : 1),
        'hi': hi.toStringAsFixed(0),
      });
    }
    return null;
  }

  Future<void> _pickWhen() async {
    final DateTime now = DateTime.now();
    final DateTime? d = await showDatePicker(
      context: context,
      initialDate: _when,
      firstDate: DateTime(2000),
      lastDate: now,
    );
    if (d == null || !mounted) return;
    final TimeOfDay? t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_when),
    );
    if (t == null) return;
    DateTime picked = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    if (picked.isAfter(now)) picked = now;
    setState(() => _when = picked);
  }

  Future<void> _save() async {
    setState(() => _errorKey = null);
    if (!_form.currentState!.validate()) return;

    final double? temp = _d(_temp);
    final double? sysD = _d(_sys);
    final double? diaD = _d(_dia);
    final double? glu = _d(_glu);
    final double? ht = _d(_ht);
    final double? wt = _d(_wt);

    if ((sysD == null) != (diaD == null)) {
      setState(() => _errorKey = 'err_bp_both');
      return;
    }
    if (sysD != null && diaD != null && sysD <= diaD) {
      setState(() => _errorKey = 'err_bp_order');
      return;
    }
    if (temp == null && sysD == null && glu == null && ht == null && wt == null) {
      setState(() => _errorKey = 'err_need_one');
      return;
    }

    // BMI needs both; fall back to the last known height if only weight was typed.
    final double? bmi = computeBmi(ht ?? widget.latest.height, wt);

    final VitalRecord rec = VitalRecord(
      id: '',
      time: _when,
      temperature: temp,
      systolic: sysD?.round(),
      diastolic: diaD?.round(),
      glucose: glu,
      height: ht,
      weight: wt,
      bmi: bmi,
      source: 'app',
    );

    setState(() => _saving = true);
    try {
      await VitalsService.addReading(
        widget.uid,
        rec,
        bmi == null ? '' : bmiLabelEn(bmi),
      );
      if (!mounted) return;
      showSnack(context, context.t('reading_saved'));
      Navigator.of(context).pop();
    } catch (e) {
      if (mounted) {
        setState(() {
          _saving = false;
          _errorKey = AuthService.errorKey(e);
        });
      }
    }
  }

  Widget _field(
    TextEditingController c,
    String labelKey,
    String unit,
    double lo,
    double hi,
  ) {
    return TextFormField(
      controller: c,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: context.t(labelKey),
        suffixText: unit,
      ),
      validator: (String? v) => _range(v, lo, hi),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.t('log_reading'))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: ContentWidth(
          maxWidth: 480,
          child: Form(
            key: _form,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: K.gldLt,
                    border: Border.all(color: K.gld),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Icon(Icons.info_outline, color: K.gld, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          context.t('self_report_note'),
                          style: const TextStyle(fontSize: 13, height: 1.4),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                if (_errorKey != null) ...<Widget>[
                  ErrorBox(context.t(_errorKey!)),
                  const SizedBox(height: 12),
                ],
                InkWell(
                  onTap: _pickWhen,
                  borderRadius: BorderRadius.circular(8),
                  child: InputDecorator(
                    decoration: InputDecoration(
                      labelText: context.t('measured_at'),
                      suffixIcon: const Icon(Icons.schedule, color: K.acc),
                    ),
                    child: Text(fmtDateTime(_when)),
                  ),
                ),
                const SizedBox(height: 12),
                _field(_temp, 'mod_temp', '°C', 30, 45),
                const SizedBox(height: 12),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(child: _field(_sys, 'systolic', 'mmHg', 50, 260)),
                    const SizedBox(width: 10),
                    Expanded(child: _field(_dia, 'diastolic', 'mmHg', 30, 160)),
                  ],
                ),
                const SizedBox(height: 12),
                _field(_glu, 'mod_glu', 'mg/dL', 20, 600),
                const SizedBox(height: 12),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(child: _field(_ht, 'mod_ht', 'cm', 50, 250)),
                    const SizedBox(width: 10),
                    Expanded(child: _field(_wt, 'mod_wt', 'kg', 10, 400)),
                  ],
                ),
                const SizedBox(height: 22),
                if (_saving)
                  const Center(child: CircularProgressIndicator())
                else
                  ElevatedButton(
                    onPressed: _save,
                    style: ElevatedButton.styleFrom(backgroundColor: K.grn),
                    child: Text(context.t('save_reading')),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
