import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../core/app_state.dart';
import '../core/theme.dart';
import '../models/resident.dart';
import '../widgets/common.dart';

/// The resident's QR "Kiosk Pass". The payload is exactly the name string the
/// kiosk looks residents up by ("LASTNAME, Firstname Middle").
class PassScreen extends StatelessWidget {
  final Resident resident;
  const PassScreen({super.key, required this.resident});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        const KioskHeader(),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: <Widget>[
              ContentWidth(
                maxWidth: 480,
                child: Column(
                  children: <Widget>[
                    AccentCard(
                      accent: K.acc,
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: <Widget>[
                          Text(
                            context.t('pass_title'),
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: K.hdr,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            context.t('pass_hint'),
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: K.sub, fontSize: 13),
                          ),
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(color: K.accLt, width: 2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: QrImageView(
                              data: resident.kioskName,
                              version: QrVersions.auto,
                              size: 230,
                              backgroundColor: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            resident.displayName,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                              color: K.txt,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: K.gldLt,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                const Icon(Icons.brightness_high, size: 18, color: K.gld),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    context.t('pass_brightness'),
                                    style: const TextStyle(fontSize: 12, height: 1.4),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    AccentCard(
                      accent: K.grn,
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            context.t('steps_title'),
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: K.hdr,
                            ),
                          ),
                          const SizedBox(height: 10),
                          for (final String k in <String>[
                            'pass_s1',
                            'pass_s2',
                            'pass_s3',
                            'pass_s4',
                            'pass_s5',
                          ])
                            Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Text(context.t(k), style: const TextStyle(height: 1.4)),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      context.t('pass_privacy'),
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 11, color: K.sub),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
