import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/health.dart';
import '../core/theme.dart';
import '../models/resident.dart';
import '../models/vital_record.dart';
import '../widgets/common.dart';
import '../widgets/metric_card.dart';
import 'metric_detail_screen.dart';

class HomeScreen extends StatelessWidget {
  final Resident resident;
  final List<VitalRecord> records;
  final VoidCallback onShowPass;
  final VoidCallback onAdd;

  const HomeScreen({
    super.key,
    required this.resident,
    required this.records,
    required this.onShowPass,
    required this.onAdd,
  });

  void _open(BuildContext context, MetricInfo info) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext _) =>
            MetricDetailScreen(metric: info.metric, records: records),
      ),
    );
  }

  Widget _identityStrip(BuildContext context, LatestVitals latest) {
    final Color gc = resident.gender == 'Male' ? K.deep : const Color(0xFF9D174D);
    final int? age = resident.age;
    final String who =
        '${resident.displayName}  •  ${context.t(resident.gender == 'Male' ? 'male' : 'female')}'
        '${age != null ? '  •  ${context.tf('age_n', <String, String>{'n': '$age'})}' : ''}';
    return Container(
      width: double.infinity,
      color: K.strip,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: <Widget>[
          Icon(Icons.person, color: gc, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              who,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontWeight: FontWeight.bold, color: gc, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _cta(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: K.gldLt,
        border: Border.all(color: K.gld),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Icon(Icons.lightbulb_outline, color: K.gld, size: 20),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  context.t('cta_title'),
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: K.gld,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(context.t('cta_body'), style: const TextStyle(color: K.sub, height: 1.4)),
        ],
      ),
    );
  }

  Widget _howTo(BuildContext context) {
    return AccentCard(
      accent: K.acc,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            context.t('howto_title'),
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: K.hdr,
            ),
          ),
          const SizedBox(height: 10),
          for (final String k in <String>['howto_1', 'howto_2', 'howto_3', 'howto_4'])
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(context.t(k), style: const TextStyle(height: 1.4)),
            ),
          const SizedBox(height: 8),
          ElevatedButton.icon(
            onPressed: onShowPass,
            style: ElevatedButton.styleFrom(backgroundColor: K.grn),
            icon: const Icon(Icons.qr_code_2),
            label: Text(context.t('show_pass')),
          ),
        ],
      ),
    );
  }

  Widget _tipsCard(BuildContext context, LatestVitals latest) {
    final List<Tip> tips = tipsFor(latest);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: K.tipsBg,
        border: Border.all(color: K.grn),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            context.t('tips_title'),
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: K.hdr,
            ),
          ),
          const SizedBox(height: 8),
          for (final Tip t in tips)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(context.t(t.key), style: const TextStyle(height: 1.4)),
            ),
          Text(
            context.t('disclaimer'),
            style: const TextStyle(
              fontSize: 11,
              fontStyle: FontStyle.italic,
              color: K.sub,
            ),
          ),
        ],
      ),
    );
  }

  Widget _grid(BuildContext context, LatestVitals latest) {
    final List<Widget> cards = kMetrics
        .map(
          (MetricInfo i) => MetricCard(
            info: i,
            record: latest.of(i.metric),
            onTap: () => _open(context, i),
          ),
        )
        .toList();
    final List<Widget> rows = <Widget>[];
    for (int i = 0; i < cards.length; i += 2) {
      rows.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Expanded(child: cards[i]),
                const SizedBox(width: 12),
                Expanded(child: i + 1 < cards.length ? cards[i + 1] : const SizedBox()),
              ],
            ),
          ),
        ),
      );
    }
    return Column(children: rows);
  }

  @override
  Widget build(BuildContext context) {
    final LatestVitals latest = latestFrom(records);
    final DateTime? last = latest.lastTime;

    return Column(
      children: <Widget>[
        const KioskHeader(),
        _identityStrip(context, latest),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 96),
            children: <Widget>[
              ContentWidth(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    if (latest.isEmpty) ...<Widget>[
                      _cta(context),
                      const SizedBox(height: 14),
                      _howTo(context),
                    ] else ...<Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(child: SectionTitle(context.t('latest_readings'))),
                          if (last != null)
                            Text(
                              fmtDate(last),
                              style: const TextStyle(color: K.sub, fontSize: 12),
                            ),
                        ],
                      ),
                      _grid(context, latest),
                      const SizedBox(height: 4),
                      _tipsCard(context, latest),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
