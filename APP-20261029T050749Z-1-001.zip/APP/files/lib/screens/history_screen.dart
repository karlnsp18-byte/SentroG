import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/health.dart';
import '../core/theme.dart';
import '../models/vital_record.dart';
import '../services/auth_service.dart';
import '../services/vitals_service.dart';
import '../widgets/common.dart';

enum _Filter { all, kiosk, mine }

class HistoryScreen extends StatefulWidget {
  final String uid;
  final List<VitalRecord> records;
  const HistoryScreen({super.key, required this.uid, required this.records});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  _Filter _filter = _Filter.all;

  List<VitalRecord> get _visible {
    switch (_filter) {
      case _Filter.kiosk:
        return widget.records.where((VitalRecord r) => r.fromKiosk).toList();
      case _Filter.mine:
        return widget.records.where((VitalRecord r) => !r.fromKiosk).toList();
      case _Filter.all:
        return widget.records;
    }
  }

  Future<void> _delete(VitalRecord r) async {
    final bool ok = await confirmDialog(
      context,
      title: context.t('delete_record'),
      body: context.t('delete_record_body'),
      confirmLabel: context.t('delete'),
      danger: true,
    );
    if (!ok) return;
    try {
      await VitalsService.delete(widget.uid, r.id);
    } catch (e) {
      if (mounted) {
        showSnack(context, context.t(AuthService.errorKey(e)), error: true);
      }
    }
  }

  Widget _chip(String key, _Filter f) {
    return ChoiceChip(
      label: Text(context.t(key)),
      selected: _filter == f,
      selectedColor: K.accLt,
      onSelected: (bool _) => setState(() => _filter = f),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<VitalRecord> list = _visible;
    return Column(
      children: <Widget>[
        const KioskHeader(),
        Container(
          width: double.infinity,
          color: K.strip,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Wrap(
            spacing: 8,
            children: <Widget>[
              _chip('filter_all', _Filter.all),
              _chip('filter_kiosk', _Filter.kiosk),
              _chip('filter_mine', _Filter.mine),
            ],
          ),
        ),
        Expanded(
          child: list.isEmpty
              ? EmptyState(
                  icon: Icons.history,
                  title: context.t('no_history'),
                  body: context.t('no_history_hint'),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: list.length,
                  itemBuilder: (BuildContext context, int i) {
                    final VitalRecord r = list[i];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: ContentWidth(
                        child: _RecordCard(
                          record: r,
                          latest: widget.records.isNotEmpty &&
                              widget.records.first.id == r.id,
                          onDelete: r.fromKiosk ? null : () => _delete(r),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class _RecordCard extends StatelessWidget {
  final VitalRecord record;
  final bool latest;
  final VoidCallback? onDelete;
  const _RecordCard({
    required this.record,
    required this.latest,
    required this.onDelete,
  });

  Widget _tile(BuildContext context, MetricInfo info) {
    final String? v = valueText(info.metric, record);
    if (v == null) return const SizedBox.shrink();
    final Status? s = statusFor(info.metric, record);
    return Container(
      padding: const EdgeInsets.fromLTRB(0, 0, 8, 0),
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Container(
              width: 5,
              decoration: BoxDecoration(
                color: s?.color ?? K.bdr,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    context.t(info.titleKey),
                    style: const TextStyle(fontSize: 11, color: K.sub),
                  ),
                  Text(
                    '$v ${info.unit}'.trim(),
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  if (s != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 3),
                      child: StatusChip(status: s),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Status? worst = worstStatus(record);
    final List<Widget> tiles = kMetrics
        .map((MetricInfo i) => _tile(context, i))
        .where((Widget w) => w is! SizedBox)
        .toList();

    final List<Widget> rows = <Widget>[];
    for (int i = 0; i < tiles.length; i += 2) {
      rows.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(child: tiles[i]),
              Expanded(child: i + 1 < tiles.length ? tiles[i + 1] : const SizedBox()),
            ],
          ),
        ),
      );
    }

    return AccentCard(
      accent: worst?.color ?? K.bdr,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Icon(Icons.calendar_today, size: 15, color: K.hdr),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  fmtDateTime(record.time),
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
              ),
              if (latest)
                Container(
                  margin: const EdgeInsets.only(right: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: K.grnLt,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    context.t('latest'),
                    style: const TextStyle(
                      color: K.grn,
                      fontWeight: FontWeight.bold,
                      fontSize: 11,
                    ),
                  ),
                ),
              if (onDelete != null)
                InkWell(
                  onTap: onDelete,
                  child: const Padding(
                    padding: EdgeInsets.all(4),
                    child: Icon(Icons.delete_outline, size: 20, color: K.red),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: <Widget>[
              Icon(
                record.fromKiosk ? Icons.monitor_heart_outlined : Icons.edit_note,
                size: 14,
                color: K.mut,
              ),
              const SizedBox(width: 4),
              Text(
                context.t(record.fromKiosk ? 'src_kiosk' : 'src_app'),
                style: const TextStyle(fontSize: 12, color: K.sub),
              ),
            ],
          ),
          const Divider(height: 20),
          ...rows,
        ],
      ),
    );
  }
}
