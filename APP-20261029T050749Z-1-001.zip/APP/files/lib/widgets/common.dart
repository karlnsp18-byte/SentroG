import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/health.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';

/// Keeps content readable on tablets / web (max 640 px wide).
class ContentWidth extends StatelessWidget {
  final Widget child;
  final double maxWidth;
  const ContentWidth({super.key, required this.child, this.maxWidth = 640});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: child,
      ),
    );
  }
}

void toggleLanguage(BuildContext context) {
  final AppState app = context.app;
  final String next = app.isFil ? 'EN' : 'FIL';
  app.setLang(next);
  AuthService.saveLang(next);
}

/// Navy kiosk-style header bar with the gold accent line.
class KioskHeader extends StatelessWidget {
  final bool showLanguage;
  final List<Widget> actions;
  const KioskHeader({
    super.key,
    this.showLanguage = true,
    this.actions = const <Widget>[],
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          width: double.infinity,
          color: K.hdr,
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 10, 10),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          'SENTRO GINHAWA',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            letterSpacing: 0.6,
                          ),
                        ),
                        Text(
                          context.t('app_sub'),
                          style: const TextStyle(color: K.skyBlue, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                  ...actions,
                  if (showLanguage) const LangToggle(),
                ],
              ),
            ),
          ),
        ),
        Container(height: 3, color: K.gld),
      ],
    );
  }
}

class LangToggle extends StatelessWidget {
  const LangToggle({super.key});

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: () => toggleLanguage(context),
      style: TextButton.styleFrom(
        foregroundColor: Colors.white,
        side: const BorderSide(color: Colors.white54),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        minimumSize: const Size(0, 36),
      ),
      child: Text(
        context.app.isFil ? 'English' : 'Filipino',
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
      ),
    );
  }
}

class StatusChip extends StatelessWidget {
  final Status status;
  final bool large;
  const StatusChip({super.key, required this.status, this.large = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: large ? 12 : 8,
        vertical: large ? 6 : 3,
      ),
      decoration: BoxDecoration(
        color: status.color,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        context.t(status.labelKey),
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: large ? 14 : 11,
        ),
      ),
    );
  }
}

/// Card with a coloured strip on top — the kiosk's dashboard/summary look.
class AccentCard extends StatelessWidget {
  final Color accent;
  final Widget child;
  final EdgeInsets padding;
  final Color? background;
  final Color? border;
  final VoidCallback? onTap;

  const AccentCard({
    super.key,
    required this.accent,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.background,
    this.border,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final BorderRadius radius = BorderRadius.circular(10);
    return Material(
      color: background ?? K.surface,
      borderRadius: radius,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: border ?? K.bdr, width: 1.5),
            borderRadius: radius,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(height: 6, color: accent),
              Padding(padding: padding, child: child),
            ],
          ),
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 6, bottom: 8),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: K.hdr,
        ),
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  final Widget? action;
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.body,
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 64, color: K.mut),
            const SizedBox(height: 14),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              body,
              textAlign: TextAlign.center,
              style: const TextStyle(color: K.sub, height: 1.4),
            ),
            if (action != null) ...<Widget>[
              const SizedBox(height: 18),
              action!,
            ],
          ],
        ),
      ),
    );
  }
}

class ErrorBox extends StatelessWidget {
  final String message;
  const ErrorBox(this.message, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFEE2E2),
        border: Border.all(color: K.red),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Icon(Icons.error_outline, color: K.red, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Text(message, style: const TextStyle(color: Color(0xFF991B1B))),
          ),
        ],
      ),
    );
  }
}

/// Navy splash with the cross badge.
class Splash extends StatelessWidget {
  final String? message;
  const Splash({super.key, this.message});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: K.hdr,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const CrossBadge(size: 96),
            const SizedBox(height: 18),
            const Text(
              'SENTRO GINHAWA',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 18),
            const SizedBox(
              width: 26,
              height: 26,
              child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white),
            ),
            if (message != null) ...<Widget>[
              const SizedBox(height: 14),
              Text(message!, style: const TextStyle(color: K.skyBlue)),
            ],
          ],
        ),
      ),
    );
  }
}

/// White circle with the red cross (the kiosk's welcome badge).
class CrossBadge extends StatelessWidget {
  final double size;
  const CrossBadge({super.key, this.size = 100});

  @override
  Widget build(BuildContext context) {
    final double arm = size * 0.24;
    final double len = size * 0.56;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        border: Border.all(color: K.accLt, width: 3),
      ),
      child: Center(
        child: SizedBox(
          width: len,
          height: len,
          child: Stack(
            alignment: Alignment.center,
            children: <Widget>[
              Container(width: arm, height: len, color: const Color(0xFFDC2626)),
              Container(width: len, height: arm, color: const Color(0xFFDC2626)),
            ],
          ),
        ),
      ),
    );
  }
}

void showSnack(BuildContext context, String message, {bool error = false}) {
  final ScaffoldMessengerState m = ScaffoldMessenger.of(context);
  m.hideCurrentSnackBar();
  m.showSnackBar(
    SnackBar(
      content: Text(message),
      backgroundColor: error ? K.red : K.hdr,
      behavior: SnackBarBehavior.floating,
    ),
  );
}

Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String body,
  required String confirmLabel,
  bool danger = false,
}) async {
  final bool? ok = await showDialog<bool>(
    context: context,
    builder: (BuildContext ctx) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(false),
          child: Text(ctx.t('cancel')),
        ),
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(true),
          style: TextButton.styleFrom(foregroundColor: danger ? K.red : K.acc),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return ok ?? false;
}
