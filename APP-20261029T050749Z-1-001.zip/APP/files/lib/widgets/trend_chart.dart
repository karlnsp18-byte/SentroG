import 'package:flutter/material.dart';

import '../core/theme.dart';

class TrendSeries {
  final List<double> values;
  final List<Color> dotColors;
  final Color lineColor;
  const TrendSeries({
    required this.values,
    required this.dotColors,
    required this.lineColor,
  });
}

/// Small dependency-free line chart (oldest → newest, left → right).
class TrendChart extends StatelessWidget {
  final List<TrendSeries> series;
  final String startLabel;
  final String endLabel;
  const TrendChart({
    super.key,
    required this.series,
    required this.startLabel,
    required this.endLabel,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 190,
      width: double.infinity,
      child: CustomPaint(
        painter: _TrendPainter(series, startLabel, endLabel),
      ),
    );
  }
}

class _TrendPainter extends CustomPainter {
  final List<TrendSeries> series;
  final String startLabel;
  final String endLabel;
  _TrendPainter(this.series, this.startLabel, this.endLabel);

  void _text(
    Canvas canvas,
    String s,
    Offset at, {
    TextAlign align = TextAlign.left,
    Color color = K.sub,
    double size = 11,
    FontWeight weight = FontWeight.normal,
  }) {
    final TextPainter tp = TextPainter(
      text: TextSpan(
        text: s,
        style: TextStyle(color: color, fontSize: size, fontWeight: weight),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    double dx = at.dx;
    if (align == TextAlign.right) dx -= tp.width;
    if (align == TextAlign.center) dx -= tp.width / 2;
    tp.paint(canvas, Offset(dx, at.dy));
  }

  @override
  void paint(Canvas canvas, Size size) {
    double lo = double.infinity;
    double hi = -double.infinity;
    int n = 0;
    for (final TrendSeries s in series) {
      if (s.values.length > n) n = s.values.length;
      for (final double v in s.values) {
        if (v < lo) lo = v;
        if (v > hi) hi = v;
      }
    }
    if (n < 2 || lo == double.infinity) return;
    if (hi - lo < 1) {
      hi += 1;
      lo -= 1;
    }
    final double pad = (hi - lo) * 0.15;
    lo -= pad;
    hi += pad;

    const double left = 40;
    const double right = 12;
    const double top = 10;
    const double bottom = 24;
    final double w = size.width - left - right;
    final double h = size.height - top - bottom;

    final Paint grid = Paint()
      ..color = K.bdr
      ..strokeWidth = 1;
    for (int i = 0; i <= 3; i++) {
      final double y = top + h * i / 3;
      canvas.drawLine(Offset(left, y), Offset(left + w, y), grid);
      final double val = hi - (hi - lo) * i / 3;
      _text(canvas, val.toStringAsFixed(val.abs() >= 100 ? 0 : 1),
          Offset(left - 6, y - 7), align: TextAlign.right, size: 10);
    }

    for (final TrendSeries s in series) {
      final int m = s.values.length;
      if (m == 0) continue;
      final List<Offset> pts = <Offset>[];
      for (int i = 0; i < m; i++) {
        final double x = left + w * (m == 1 ? 0.5 : i / (m - 1));
        final double y = top + h * (1 - (s.values[i] - lo) / (hi - lo));
        pts.add(Offset(x, y));
      }
      final Paint line = Paint()
        ..color = s.lineColor
        ..strokeWidth = 2.5
        ..style = PaintingStyle.stroke
        ..strokeJoin = StrokeJoin.round;
      final Path path = Path()..moveTo(pts.first.dx, pts.first.dy);
      for (int i = 1; i < pts.length; i++) {
        path.lineTo(pts[i].dx, pts[i].dy);
      }
      canvas.drawPath(path, line);
      for (int i = 0; i < pts.length; i++) {
        canvas.drawCircle(pts[i], 6, Paint()..color = Colors.white);
        canvas.drawCircle(pts[i], 4.5, Paint()..color = s.dotColors[i]);
      }
    }

    _text(canvas, startLabel, Offset(left, size.height - 16), size: 10);
    _text(canvas, endLabel, Offset(left + w, size.height - 16),
        align: TextAlign.right, size: 10);
  }

  @override
  bool shouldRepaint(covariant _TrendPainter old) => true;
}
