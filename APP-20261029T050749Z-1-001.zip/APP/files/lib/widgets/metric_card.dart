import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/health.dart';
import '../core/theme.dart';
import '../models/vital_record.dart';
import 'common.dart';

/// Dashboard card: status strip + status chip + big readable value.
class MetricCard extends StatelessWidget {
  final MetricInfo info;
  final VitalRecord? record;
  final VoidCallback onTap;

  const MetricCard({
    super.key,
    required this.info,
    required this.record,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final VitalRecord? r = record;
    final Status? status = r == null ? null : statusFor(info.metric, r);
    final String? value = r == null ? null : valueText(info.metric, r);
    final bool empty = value == null;
    final Color accent = status?.color ?? K.acc;

    return AccentCard(
      accent: accent,
      border: empty ? K.acc : accent,
      background: empty ? K.s2 : K.surface,
      onTap: onTap,
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(info.icon, color: accent, size: 22),
              ),
              const Spacer(),
              if (status != null) Flexible(child: StatusChip(status: status)),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            context.t(info.titleKey),
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: K.txt,
            ),
          ),
          const SizedBox(height: 2),
          if (empty)
            Text(
              context.t('not_yet'),
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: K.acc,
              ),
            )
          else
            Wrap(
              crossAxisAlignment: WrapCrossAlignment.end,
              children: <Widget>[
                Text(
                  value!,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: K.txt,
                  ),
                ),
                if (info.unit.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(left: 4, bottom: 3),
                    child: Text(
                      info.unit,
                      style: const TextStyle(fontSize: 12, color: K.sub),
                    ),
                  ),
              ],
            ),
          if (r != null && !empty) ...<Widget>[
            const SizedBox(height: 4),
            Row(
              children: <Widget>[
                Icon(
                  r.fromKiosk ? Icons.monitor_heart_outlined : Icons.edit_note,
                  size: 13,
                  color: K.mut,
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    fmtDate(r.time),
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11, color: K.mut),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
