import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/health.dart';
import '../core/theme.dart';

/// Horizontal colour-banded bar with a marker at the resident's value
/// (the app version of the kiosk's metric range bar).
class RangeBar extends StatelessWidget {
  final RangeSpec spec;
  final double value;
  const RangeBar({super.key, required this.spec, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 36,
          width: double.infinity,
          child: CustomPaint(painter: _RangePainter(spec, value)),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 12,
          runSpacing: 4,
          children: spec.segs
              .map(
                (RangeSeg s) => Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: s.color,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      context.t(s.labelKey),
                      style: const TextStyle(fontSize: 11, color: K.sub),
                    ),
                  ],
                ),
              )
              .toList(),
        ),
      ],
    );
  }
}

class _RangePainter extends CustomPainter {
  final RangeSpec spec;
  final double value;
  _RangePainter(this.spec, this.value);

  @override
  void paint(Canvas canvas, Size size) {
    const double barTop = 12;
    const double barH = 12;
    final double span = spec.max - spec.min;
    if (span <= 0) return;

    canvas.save();
    canvas.clipRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, barTop, size.width, barH),
        const Radius.circular(6),
      ),
    );
    for (final RangeSeg s in spec.segs) {
      final double x0 = ((s.from - spec.min) / span).clamp(0.0, 1.0).toDouble() * size.width;
      final double x1 = ((s.to - spec.min) / span).clamp(0.0, 1.0).toDouble() * size.width;
      canvas.drawRect(
        Rect.fromLTRB(x0, barTop, x1, barTop + barH),
        Paint()..color = s.color,
      );
    }
    canvas.restore();

    final double vx = ((value - spec.min) / span).clamp(0.0, 1.0).toDouble() * size.width;
    final Offset c = Offset(vx, barTop + barH / 2);
    canvas.drawCircle(c, 10, Paint()..color = Colors.white);
    canvas.drawCircle(
      c,
      10,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = K.txt,
    );
  }

  @override
  bool shouldRepaint(covariant _RangePainter old) =>
      old.value != value || old.spec != spec;
}
