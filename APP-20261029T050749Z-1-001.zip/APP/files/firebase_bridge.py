"""
Sentro Ginhawa kiosk  ->  Firebase bridge  (optional, fail-safe)

What it does
  * push_record()   after the kiosk saves a health record, copy it to Firestore at
                    vitals/{uid}/history/{id}  so the resident sees it in the app.
  * pull_resident() when a scanned Kiosk Pass QR is not in the kiosk's local SQLite
                    DB, look the resident up in Firestore (registered in the app)
                    and hand back their details so the kiosk can create the local row.

How residents are linked
  The kiosk identifies a resident by the string "LASTNAME, Firstname Middle".
  The app stores that same string (kioskName) and claims kioskNames/{KEY}
  (KEY = upper-case, single-spaced). The bridge finds the uid from that key.
  Residents who never installed the app are simply skipped.

Safety
  * If the key file / firebase-admin / internet is missing, the kiosk keeps working
    exactly as before: nothing here ever raises into the kiosk code.
  * Records that cannot be pushed (offline) go to firebase_outbox.jsonl and are
    retried on the next save. Documents have deterministic ids, so retries and the
    one-time backfill never create duplicates.

Setup
  pip install firebase-admin
  Firebase console -> Project settings -> Service accounts -> Generate new private key
  Save it OUTSIDE the project folder / git repo, then in the kiosk's .env:
      SENTRO_FIREBASE_KEY=C:\\path\\to\\serviceAccountKey.json
      SENTRO_TZ_OFFSET=8          # kiosk clock is Philippine time (UTC+8)
  The service-account key gives full access to the project. Keep it on the kiosk only.
"""
import hashlib
import json
import os
import re
import sqlite3
import threading
from datetime import datetime, timedelta, timezone

_fs = None          # firebase_admin.firestore module
_db = None          # Firestore client
_db_path = None     # kiosk SQLite path
_lock = threading.Lock()
_synced_names = set()
_OUTBOX = os.path.join(os.path.dirname(os.path.abspath(__file__)), "firebase_outbox.jsonl")


def _tz():
    try:
        return timezone(timedelta(hours=float(os.environ.get("SENTRO_TZ_OFFSET", "8"))))
    except Exception:
        return timezone(timedelta(hours=8))


def init(db_path):
    """Connect to Firebase. Returns True when the bridge is active."""
    global _fs, _db, _db_path
    _db_path = db_path
    key = os.environ.get("SENTRO_FIREBASE_KEY", "").strip().strip('"')
    if not key or not os.path.exists(key):
        print("[bridge] disabled (set SENTRO_FIREBASE_KEY to a service-account JSON to enable)")
        return False
    try:
        import firebase_admin
        from firebase_admin import credentials, firestore
        if not firebase_admin._apps:
            firebase_admin.initialize_app(credentials.Certificate(key))
        _db = firestore.client()
        _fs = firestore
        print("[bridge] connected to Firebase")
        flush_outbox()
        return True
    except Exception as e:
        print(f"[bridge] disabled: {e}")
        _db = None
        return False


def enabled():
    return _db is not None


# ── helpers ──────────────────────────────────────────────────────────────────
def kiosk_key(name):
    """Must match Resident.kioskKeyOf() in the Flutter app."""
    return re.sub(r"\s+", " ", (name or "").strip().upper()).replace("/", "-")


def _num(v):
    if v is None:
        return None
    try:
        return float(str(v).strip().split()[0].replace(",", "."))
    except Exception:
        return None


def _bmi_label(b):
    return "Underweight" if b < 18.5 else "Normal" if b < 25 else "Overweight" if b < 30 else "Obese"


def _uid_for(name):
    snap = _db.collection("kioskNames").document(kiosk_key(name)).get()
    return (snap.to_dict() or {}).get("uid") if snap.exists else None


def _doc_id(name, ts):
    return "k" + hashlib.sha1(f"{name}|{ts}".encode("utf-8")).hexdigest()[:20]


def _payload(rec):
    """rec: dict(temp, bp, glucose, height, weight, bmi, timestamp)."""
    out = {"source": "kiosk"}
    ts = rec.get("timestamp") or ""
    try:
        when = datetime.strptime(ts, "%Y-%m-%d %H:%M").replace(tzinfo=_tz())
    except Exception:
        when = datetime.now(_tz())
    out["timestamp"] = when
    out["dateString"] = ts or when.strftime("%Y-%m-%d %H:%M")
    for field, src in (("temperature", "temp"), ("glucose", "glucose"),
                       ("height", "height"), ("weight", "weight")):
        n = _num(rec.get(src))
        if n is not None:
            out[field] = n
    bp = (rec.get("bp") or "").strip()
    if re.match(r"^\d{2,3}\s*/\s*\d{2,3}$", bp):
        out["bp"] = bp.replace(" ", "")
    b = _num(rec.get("bmi"))
    if b is not None:
        out["bmi"] = round(b, 1)
        out["bmiStatus"] = _bmi_label(b)
    return out


def _write(uid, name, rec):
    _db.collection("vitals").document(uid).collection("history") \
       .document(_doc_id(name, rec.get("timestamp"))).set(_payload(rec))


# ── public API ───────────────────────────────────────────────────────────────
def push_record(name, rec):
    """Non-blocking. Call right after the record is saved locally."""
    if not enabled():
        return
    threading.Thread(target=_push_safe, args=(name, rec), daemon=True).start()


def _push_safe(name, rec):
    try:
        uid = _uid_for(name)
        if not uid:
            return                       # resident has no app account
        _write(uid, name, rec)
        if name not in _synced_names:    # first save this session: backfill older records
            _synced_names.add(name)
            _backfill(uid, name)
        flush_outbox()
    except Exception as e:
        print(f"[bridge] push failed, queued: {e}")
        _queue(name, rec)


def _backfill(uid, name):
    try:
        with sqlite3.connect(_db_path) as c:
            rows = c.execute(
                "SELECT temp,bp,glucose,height,weight,bmi,timestamp "
                "FROM health_records WHERE name=?", (name,)).fetchall()
        for t, bp, g, h, w, b, ts in rows:
            _write(uid, name, {"temp": t, "bp": bp, "glucose": g, "height": h,
                               "weight": w, "bmi": b, "timestamp": ts})
    except Exception as e:
        print(f"[bridge] backfill failed: {e}")


def pull_resident(qr_data):
    """Details of an app-registered resident for a scanned QR payload, or None."""
    if not enabled():
        return None
    try:
        uid = _uid_for(qr_data)
        if not uid:
            return None
        snap = _db.collection("residents").document(uid).get()
        d = snap.to_dict() or {}
        if not d.get("kioskName"):
            return None
        age = ""
        try:
            b = datetime.strptime(d.get("birthdate", ""), "%Y-%m-%d")
            t = datetime.now()
            age = str(t.year - b.year - ((t.month, t.day) < (b.month, b.day)))
        except Exception:
            pass
        return {"name": d["kioskName"], "gender": d.get("gender", ""),
                "email": d.get("email", ""), "birthdate": d.get("birthdate", ""), "age": age}
    except Exception as e:
        print(f"[bridge] lookup failed: {e}")
        return None


# ── offline outbox ───────────────────────────────────────────────────────────
def _queue(name, rec):
    try:
        with _lock, open(_OUTBOX, "a", encoding="utf-8") as f:
            f.write(json.dumps({"name": name, "rec": rec}) + "\n")
    except Exception as e:
        print(f"[bridge] could not queue record: {e}")


def flush_outbox():
    if not enabled() or not os.path.exists(_OUTBOX):
        return
    with _lock:
        try:
            with open(_OUTBOX, encoding="utf-8") as f:
                lines = [ln for ln in f.read().splitlines() if ln.strip()]
        except Exception:
            return
        remaining = []
        for ln in lines:
            try:
                item = json.loads(ln)
                uid = _uid_for(item["name"])
                if uid:
                    _write(uid, item["name"], item["rec"])
            except Exception:
                remaining.append(ln)
        try:
            if remaining:
                with open(_OUTBOX, "w", encoding="utf-8") as f:
                    f.write("\n".join(remaining) + "\n")
            else:
                os.remove(_OUTBOX)
        except Exception:
            pass
