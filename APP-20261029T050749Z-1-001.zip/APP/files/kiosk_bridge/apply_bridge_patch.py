"""
Adds the Firebase bridge to a copy of the kiosk script with three small edits.

    python apply_bridge_patch.py Sentro_Ginhawa_adviser_3.py  Sentro_Ginhawa_adviser_4.py

Every edit is asserted to match exactly once, so if your file changed the script
stops instead of guessing. Put firebase_bridge.py next to the kiosk script.
"""
import sys

src_path, out_path = sys.argv[1], sys.argv[2]
src = open(src_path, encoding="utf-8").read()


def rep(old, new):
    global src
    assert src.count(old) == 1, f"expected exactly one match, found {src.count(old)}:\n{old[:90]}"
    src = src.replace(old, new)


# 1) start the bridge (silently disabled when not configured)
rep('''def format_display_name(name):''',
'''try:
    import firebase_bridge
    firebase_bridge.init(DB)     # silently stays disabled when not configured
except Exception as _e:          # bridge is optional
    firebase_bridge = None
    print(f"[bridge] not loaded: {_e}")


def format_display_name(name):''')

# 2) QR login: case-insensitive local lookup, then fall back to the cloud profile
rep('''        with sqlite3.connect(DB) as c:
            cur = c.cursor()
            cur.execute("SELECT gender, email FROM residents WHERE name=?", (data.strip(),))
            row = cur.fetchone()
        if row:
            def proceed():
                self.user, self.gender, self.email = data.strip(), row[0], (row[1] or "")''',
'''        with sqlite3.connect(DB) as c:
            cur = c.cursor()
            cur.execute("SELECT gender, email, name FROM residents WHERE name=? COLLATE NOCASE",
                        (data.strip(),))
            row = cur.fetchone()
            if not row and firebase_bridge and firebase_bridge.enabled():
                # Resident registered in the mobile app: create the local row on first scan
                info = firebase_bridge.pull_resident(data.strip())
                if info:
                    c.execute("INSERT INTO residents (name,age,gender,email,birthdate) VALUES (?,?,?,?,?)",
                              (info["name"], info["age"], info["gender"], info["email"], info["birthdate"]))
                    row = (info["gender"], info["email"], info["name"])
        if row:
            def proceed():
                self.user, self.gender, self.email = row[2], row[0], (row[1] or "")''')

# 3) after a successful local save, push the record to Firestore
rep('''                          (self.user, s["Body Temperature"], s["Blood Pressure"],
                           s["Blood Glucose"], s["Height"], s["Weight"],
                           s["BMI Calculation"], now))
            self._alert("info", self.s("ok"))''',
'''                          (self.user, s["Body Temperature"], s["Blood Pressure"],
                           s["Blood Glucose"], s["Height"], s["Weight"],
                           s["BMI Calculation"], now))
            if firebase_bridge:
                firebase_bridge.push_record(self.user, {
                    "temp": s["Body Temperature"], "bp": s["Blood Pressure"],
                    "glucose": s["Blood Glucose"], "height": s["Height"],
                    "weight": s["Weight"], "bmi": s["BMI Calculation"], "timestamp": now})
            self._alert("info", self.s("ok"))''')

open(out_path, "w", encoding="utf-8").write(src)
print("patched ->", out_path)
