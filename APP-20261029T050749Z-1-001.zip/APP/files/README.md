# Sentro Ginhawa — resident app + kiosk bridge

```
lib/                      Flutter app (replace your lib/ with this; delete the old lib/login_screen.dart)
test/health_test.dart     unit tests for the status/tip logic  (delete test/widget_test.dart)
firestore.rules           Firestore security rules
kiosk_bridge/             optional Python bridge so kiosk records appear in the app
```

No new Flutter packages are needed — `pubspec.yaml` stays as it is
(`firebase_core`, `firebase_auth`, `cloud_firestore`, `qr_flutter`).
`lib/firebase_options.dart` is yours and is not touched.

## 1. Run the app
1. Replace your project's `lib/` with this one (keep your `firebase_options.dart`).
   Delete `lib/login_screen.dart` and `test/widget_test.dart` (the default counter test no longer matches).
2. Firebase console → **Authentication → Sign-in method → Email/Password → Enable**.
3. Firebase console → **Firestore Database** → create it, then **Rules** → paste `firestore.rules` → **Publish**.
   (Do not leave test mode on: without rules anyone can read residents' health data.)
4. `flutter pub get`, `flutter analyze`, `flutter test`, `flutter run`.

## 2. Data model
| Path | What |
|---|---|
| `residents/{uid}` | profile: names, gender, birthdate (`YYYY-MM-DD`), email, `kioskName`, `lang`, `acceptedTerms` |
| `kioskNames/{KEY}` | claims `"LASTNAME, FIRSTNAME MIDDLE"` (upper-case) → `{uid}`; create-only, so names are unique |
| `vitals/{uid}/history/{id}` | one measurement: `temperature, bp ("120/80"), glucose, height, weight, bmi, bmiStatus, timestamp, dateString, source ('kiosk' \| 'app')` |

The old single `vitals/{uid}` "latest" document is no longer used: the app derives the latest value
of every metric from the history, so a home BP reading does not blank the other cards.

## 3. Connect the kiosk (needed for data to show up)
The kiosk is SQLite-only today, so nothing writes to Firestore yet.
1. `pip install firebase-admin`
2. Firebase console → Project settings → Service accounts → *Generate new private key*.
   Store the JSON **outside** the project/repo and add to the kiosk `.env`:
   `SENTRO_FIREBASE_KEY=C:\path\to\serviceAccountKey.json` and `SENTRO_TZ_OFFSET=8`.
3. Copy `firebase_bridge.py` next to the kiosk script, then
   `python apply_bridge_patch.py Sentro_Ginhawa_adviser_3.py Sentro_Ginhawa_adviser_4.py`
   (3 small edits; `kiosk_bridge.diff` shows them).

How it behaves: after a record is saved on the kiosk it is pushed to the resident's history
(offline → queued in `firebase_outbox.jsonl`, retried on the next save). Scanning the app's Kiosk Pass QR
for a resident who registered only in the app creates their local kiosk row automatically.
If the key/internet is missing, the kiosk runs exactly as before.

## 4. Things to know
* **Linking is by name.** The kiosk's identity is `"LASTNAME, Firstname Middle"`; the app builds the same
  string and uses it as the QR payload. A resident who registered at the kiosk first must register in the app
  with the same spelling (the app shows a "kiosk name" preview while typing).
* Status chips and tips use the kiosk's thresholds. Blood pressure is classified by **systolic only**, as in the
  kiosk's `_metric_status`; change it in both places if you add diastolic.
* The QR contains the resident's name (that is what the kiosk looks up). The app tells residents to show it only at the kiosk.
* Account deletion removes the cloud data and login; the kiosk's local copy stays until the barangay health officer removes it.
