# ══════════════════════════════════════════════════════════════════════════════
# HOW TO APPLY
#   1. In class App, DELETE the old `def show_login(self, mode=None): ...` method
#      (everything from "def show_login" down to just before "def _complete_login").
#   2. Paste ALL the methods below in its place (same indentation, inside class App).
#   3. Keep _complete_login / _do_login / _do_login_email exactly as they are.
#      show_welcome is untouched.
# ══════════════════════════════════════════════════════════════════════════════

    # ── Shared graphics helpers (same look as show_welcome) ───────────────────
    def _gfx(self):
        import math
        import numpy as np
        from types import SimpleNamespace
        from PIL import ImageDraw
        imgs = self._wl_imgs = []            # keep PhotoImage refs alive

        def rgb(h, a=255):
            h = h.lstrip("#")
            return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)

        def photo(im):
            p = ImageTk.PhotoImage(im); imgs.append(p); return p

        def rr(w, h, r, fill, outline=None, ow=1):
            w, h = max(2, int(w)), max(2, int(h)); ss = 3
            im = Image.new("RGBA", (w * ss, h * ss), tuple(fill[:3]) + (0,))
            ImageDraw.Draw(im).rounded_rectangle(
                [0, 0, w * ss - 1, h * ss - 1], radius=int(r * ss),
                fill=fill, outline=outline, width=ow * ss)
            return im.resize((w, h), Image.LANCZOS)

        def icon(kind, size, color, lw=0.09):
            size = max(8, int(size)); ss = 4; S = size * ss
            c = rgb(color)[:3]; col = c + (255,)
            im = Image.new("RGBA", (S, S), c + (0,)); d = ImageDraw.Draw(im)
            w = max(2, int(S * lw)); P = lambda x, y: (x * S, y * S)
            if kind == "globe":
                d.ellipse([S*.08, S*.08, S*.92, S*.92], outline=col, width=w)
                d.ellipse([S*.32, S*.08, S*.68, S*.92], outline=col, width=w)
                d.line([P(.08, .5), P(.92, .5)], fill=col, width=w)
            elif kind == "exit":
                d.line([P(.45, .12), P(.12, .12), P(.12, .88), P(.45, .88)], fill=col, width=w, joint="curve")
                d.line([P(.35, .5), P(.88, .5)], fill=col, width=w)
                d.line([P(.66, .28), P(.88, .5), P(.66, .72)], fill=col, width=w, joint="curve")
            elif kind == "qr":
                for cx, cy, sx, sy in ((.14, .14, 1, 1), (.86, .14, -1, 1), (.14, .86, 1, -1), (.86, .86, -1, -1)):
                    d.line([P(cx + sx*.26, cy), P(cx, cy), P(cx, cy + sy*.26)], fill=col, width=w, joint="curve")
                d.rectangle([P(.38, .38), P(.62, .62)], fill=col)
            elif kind == "shield":
                pts = [P(.5, .06), P(.88, .2), P(.88, .5), P(.5, .95), P(.12, .5), P(.12, .2)]
                d.line(pts + [pts[0]], fill=col, width=w, joint="curve")
                d.line([P(.32, .5), P(.46, .64), P(.70, .36)], fill=col, width=w, joint="curve")
            elif kind == "heart":
                pts = []
                for i in range(0, 361, 3):
                    a = math.radians(i); x = 16 * math.sin(a) ** 3
                    y = 13*math.cos(a) - 5*math.cos(2*a) - 2*math.cos(3*a) - math.cos(4*a)
                    pts.append((S * (0.5 + x / 38), S * (0.47 - y / 38)))
                d.line(pts, fill=col, width=w, joint="curve")
                d.line([P(.2, .5), P(.38, .5), P(.46, .3), P(.56, .68), P(.63, .5), P(.8, .5)],
                       fill=col, width=w, joint="curve")
            return im.resize((size, size), Image.LANCZOS)

        def gradient(w, h, c1, c2):
            yy = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
            xx = np.linspace(0, 1, w, dtype=np.float32)[None, :, None]
            tt = np.clip(0.65 * yy + 0.35 * xx, 0, 1)
            a = np.array(c1, np.float32); b = np.array(c2, np.float32)
            return Image.fromarray((a * (1 - tt) + b * tt).astype(np.uint8), "RGB")

        return SimpleNamespace(rgb=rgb, photo=photo, rr=rr, icon=icon, gradient=gradient)

    @staticmethod
    def _hit(cv, tag, img_id, normal, press, cmd):
        def down(e):  cv.itemconfig(img_id, image=press)
        def leave(e): cv.itemconfig(img_id, image=normal)
        def up(e):    cv.itemconfig(img_id, image=normal); cmd()
        cv.tag_bind(tag, "<Enter>", down);  cv.tag_bind(tag, "<Leave>", leave)
        cv.tag_bind(tag, "<ButtonPress-1>", down); cv.tag_bind(tag, "<ButtonRelease-1>", up)

    def _round_btn(self, parent, g, w, h, text, fill, fg, press, cmd,
                   outline=None, size=12, bg="#ffffff", ic=None):
        """Rounded, anti-aliased button (Label + rendered image) for use inside normal Tk frames."""
        def mk(f):
            im = g.rr(w, h, h * 0.3, g.rgb(f), outline=g.rgb(outline) if outline else None, ow=2)
            if ic:
                s = int(h * 0.42)
                im.alpha_composite(g.icon(ic[0], s, ic[1]), (int(h * 0.4), (h - s) // 2))
            return g.photo(im)
        n_, p_ = mk(fill), mk(press)
        lb = tk.Label(parent, image=n_, text=text, compound="center", bd=0, bg=bg,
                      highlightthickness=0, fg=fg, cursor="hand2",
                      font=("Helvetica", self.sf(size), "bold"))
        lb.bind("<ButtonPress-1>", lambda e: lb.configure(image=p_))
        lb.bind("<Leave>",         lambda e: lb.configure(image=n_))
        lb.bind("<ButtonRelease-1>", lambda e: (lb.configure(image=n_), cmd()))
        return lb

    def _draw_brand_panel(self, cv, g, x0, y0, lw, ch, R):
        import numpy as np
        from PIL import ImageDraw
        t = lambda en, fil: fil if self.lang == "FIL" else en
        F = "Helvetica"
        cx, cy = lw // 2, int(ch * 0.34)
        r = int(min(lw * 0.15, ch * 0.11))
        gh = self.sc(92); gx0 = int(lw * 0.07); gx1 = lw - gx0
        gy1 = ch - self.sc(28); gy0 = gy1 - gh

        yy, xx = np.mgrid[0:ch, 0:lw].astype(np.float32)
        tv = (yy / ch)[..., None]
        base = np.array([22, 68, 128], np.float32) * (1 - tv) + np.array([10, 38, 84], np.float32) * tv
        glow = (np.clip(1 - np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / (lw * .8), 0, 1) ** 2 * 0.55)[..., None]
        base = base * (1 - glow) + np.array([60, 124, 204], np.float32) * glow
        panel = Image.fromarray(base.astype(np.uint8), "RGB").convert("RGBA")

        ss = 3
        ov = Image.new("RGBA", (lw * ss, ch * ss), (255, 255, 255, 0)); od = ImageDraw.Draw(ov)
        for mult, al in ((1.9, 46), (3.0, 32), (4.2, 20)):
            rad = r * mult * ss
            od.ellipse([cx*ss - rad, cy*ss - rad, cx*ss + rad, cy*ss + rad],
                       outline=(255, 255, 255, al), width=2 * ss)
        od.ellipse([(cx - r) * ss, (cy - r) * ss, (cx + r) * ss, (cy + r) * ss], fill=(255, 255, 255, 255))
        od.rounded_rectangle([gx0 * ss, gy0 * ss, gx1 * ss, gy1 * ss], radius=self.sc(16) * ss,
                             fill=(255, 255, 255, 36), outline=(255, 255, 255, 80), width=ss)
        panel.alpha_composite(ov.resize((lw, ch), Image.LANCZOS))
        hi = int(r * 1.15)
        panel.alpha_composite(g.icon("heart", hi, "#dc2626", lw=0.08), (cx - hi // 2, cy - hi // 2))

        mask = Image.new("L", (lw * ss, ch * ss), 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, lw * ss + R * 2 * ss, ch * ss - 1], radius=R * ss, fill=255)
        panel.putalpha(mask.resize((lw, ch), Image.LANCZOS))
        cv.create_image(x0, y0, anchor="nw", image=g.photo(panel))
        cv.create_rectangle(x0 + lw, y0, x0 + lw + 3, y0 + ch, fill="#f59e0b", width=0)

        cv.create_text(x0 + cx, y0 + cy + r + self.sc(34), text="Sentro Ginhawa",
                       font=(F, self.sf(19), "bold"), fill="white")
        cv.create_text(x0 + cx, y0 + cy + r + self.sc(62), text=self.s("wsub"),
                       font=(F, self.sf(10), "bold"), fill="#8ec5ff", width=lw - self.sc(40), justify="center")
        gtx = x0 + gx0 + self.sc(16); gtw = gx1 - gx0 - self.sc(32); sI = self.sc(13)
        cv.create_image(gtx, y0 + gy0 + self.sc(14), anchor="nw", image=g.photo(g.icon("shield", sI, "#fbbf24", lw=0.1)))
        cv.create_text(gtx + sI + self.sc(6), y0 + gy0 + self.sc(14) + sI // 2, anchor="w",
                       text=t("Free community health service", "Libreng serbisyong pangkalusugan"),
                       font=(F, self.sf(9), "bold"), fill="#fbbf24", width=gtw - sI)
        cv.create_text(gtx, y0 + gy0 + self.sc(38), anchor="nw",
                       text=t("Your health, closer to home.", "Kalusugan, mas malapit sa iyo."),
                       font=(F, self.sf(13), "bold"), fill="white", width=gtw)
        cv.create_text(gtx, y0 + gy0 + self.sc(64), anchor="nw",
                       text=t("No appointment needed", "Walang kailangang appointment"),
                       font=(F, self.sf(9)), fill="#b7d3f5", width=gtw)

    def _draw_topbar(self, cv, g, x0, x1, barH, active):
        import tkinter.font as tkfont
        t = lambda en, fil: fil if self.lang == "FIL" else en
        F = "Helvetica"; NAVY = "#12305f"; GRAY = "#64748b"
        W = self.SW; bc = int(barH * 0.5); ts = self.sc(42)
        cv.create_image(x0, bc - ts // 2, anchor="nw", tags="brand",
                        image=g.photo(g.rr(ts, ts, self.sc(12), (255, 255, 255, 255), outline=(214, 224, 240, 255))))
        hs = int(ts * 0.62)
        cv.create_image(x0 + (ts - hs) // 2, bc - hs // 2, anchor="nw", tags="brand",
                        image=g.photo(g.icon("heart", hs, "#dc2626", lw=0.08)))
        bx = x0 + ts + self.sc(10)
        cv.create_text(bx, bc - self.sc(2), anchor="sw", text="Sentro Ginhawa",
                       font=(F, self.sf(12), "bold"), fill=NAVY, tags="brand")
        cv.create_text(bx, bc, anchor="nw", text=self.s("wsub"), font=(F, self.sf(9)), fill=GRAY, tags="brand")
        cv.tag_bind("brand", "<Triple-Button-1>", lambda e: self._admin_login())

        nf = tkfont.Font(family=F, size=self.sf(10), weight="bold")
        tabs = [("welcome", t("Welcome", "Pagbati"), self.show_welcome),
                ("login", t("Log in", "Mag-login"), None),
                ("register", t("Register", "Mag-rehistro"), self.show_register)]
        tpad, th_, pp = self.sc(16), self.sc(34), self.sc(5)
        tws = [nf.measure(n) + tpad * 2 for _, n, _ in tabs]
        pw = sum(tws) + pp * 2; ph = th_ + pp * 2; px = (W - pw) // 2
        cv.create_image(px, bc - ph // 2, anchor="nw",
                        image=g.photo(g.rr(pw, ph, ph // 2, (255, 255, 255, 215), outline=(214, 224, 240, 255))))
        tx = px + pp
        for i, ((key, name, cmd), tw_) in enumerate(zip(tabs, tws)):
            ty = bc - th_ // 2
            if key == active:
                cv.create_image(tx, ty, anchor="nw", image=g.photo(g.rr(tw_, th_, th_ // 2, g.rgb(NAVY))))
                cv.create_text(tx + tw_ // 2, bc, text=name, font=nf, fill="white")
            else:
                n_ = g.photo(g.rr(tw_, th_, th_ // 2, (255, 255, 255, 0)))
                p_ = g.photo(g.rr(tw_, th_, th_ // 2, g.rgb("#e6eef9")))
                iid = cv.create_image(tx, ty, anchor="nw", image=n_, tags=f"tab{i}")
                cv.create_text(tx + tw_ // 2, bc, text=name, font=nf, fill="#475569", tags=f"tab{i}")
                self._hit(cv, f"tab{i}", iid, n_, p_, cmd)
            tx += tw_

        def pill(right, label, ic, fill, outline, fg, press_fill, cmd, tag):
            ph2 = self.sc(36); isz = self.sc(15); gap = self.sc(8); pd = self.sc(14)
            w_ = pd * 2 + isz + gap + nf.measure(label); left = right - w_; top = bc - ph2 // 2
            n_ = g.photo(g.rr(w_, ph2, ph2 // 2, g.rgb(fill), outline=g.rgb(outline)))
            p_ = g.photo(g.rr(w_, ph2, ph2 // 2, g.rgb(press_fill), outline=g.rgb(outline)))
            iid = cv.create_image(left, top, anchor="nw", image=n_, tags=tag)
            cv.create_image(left + pd, bc - isz // 2, anchor="nw", image=g.photo(g.icon(ic, isz, fg)), tags=tag)
            cv.create_text(left + pd + isz + gap, bc, anchor="w", text=label, font=nf, fill=fg, tags=tag)
            self._hit(cv, tag, iid, n_, p_, cmd)
            return left
        lft = pill(x1, self.s("b_exit"), "exit", "#fde8e8", "#f6c6c6", "#b91c1c", "#fbd0d0", sys.exit, "pexit")
        pill(lft - self.sc(10), self.s("lang"), "globe", "#ffffff", "#cfdcee", NAVY, "#e6eef9", self.toggle_lang, "plang")

    # ── SCREEN: LOGIN (redesigned to match the welcome screen) ───────────────
    def show_login(self, mode=None):
        from PIL import ImageDraw, ImageFilter
        self._screen = "login"
        self.clr()
        self._login_mode = mode or getattr(self, "_login_mode", "name")
        t = lambda en, fil: fil if self.lang == "FIL" else en
        S = self.sc; F = "Helvetica"
        NAVY = "#12305f"; BLUE = C["acc"]; GRAY = "#64748b"; LINE = "#c9d8ee"; WH = "#ffffff"
        g = self._gfx()

        W, H = self.SW, self.SH
        cv = tk.Canvas(self, width=W, height=H, highlightthickness=0, bd=0, bg="#e6eef9")
        cv.pack(expand=True, fill="both")
        cv.create_image(0, 0, anchor="nw", image=g.photo(g.gradient(W, H, (243, 247, 253), (210, 224, 243))))

        # Card geometry — identical to show_welcome
        m = S(34); barH = S(80)
        x0, x1, y0, y1 = m, W - m, barH, H - S(30)
        cw, ch = x1 - x0, y1 - y0
        R = S(26); lw = int(cw * 0.42)

        pad = S(30)
        sh = Image.new("RGBA", (cw + pad * 2, ch + pad * 2), (18, 48, 95, 0))
        ImageDraw.Draw(sh).rounded_rectangle([pad, pad, pad + cw, pad + ch], radius=R, fill=(18, 48, 95, 70))
        sh = sh.filter(ImageFilter.GaussianBlur(S(14)))
        cv.create_image(x0 - pad, y0 - pad + S(8), anchor="nw", image=g.photo(sh))
        cv.create_image(x0, y0, anchor="nw", image=g.photo(g.rr(cw, ch, R, (255, 255, 255, 255))))

        self._draw_brand_panel(cv, g, x0, y0, lw, ch, R)
        self._draw_topbar(cv, g, x0, x1, barH, active="login")

        # ── Form (a normal Frame placed over the canvas so the on-screen
        #    keyboard's "slide above the field" fallback keeps working) ─────
        rx0 = x0 + lw + 3; rw = x1 - rx0
        colw = min(int(rw * 0.80), S(520)); fx = rx0 + (rw - colw) // 2
        form = tk.Frame(self, bg=WH)
        form.place(x=fx, y=y0 + int(ch * 0.07), anchor="nw", width=colw)

        def lab(text, size, bold=False, fg=GRAY, **kw):
            return tk.Label(form, text=text, font=(F, self.sf(size), "bold" if bold else "normal"),
                            bg=WH, fg=fg, **kw)

        is_name = self._login_mode == "name"
        lab(t("WELCOME BACK", "MALIGAYANG PAGBABALIK"), 9, True, BLUE).pack(anchor="w")
        lab(self.s("ltitle"), 28, True, NAVY).pack(anchor="w", pady=(S(4), S(2)))
        hint = (t("Enter your registered details to securely access your health record.",
                  self.s("lhint")) if is_name else self.s("lhint_email"))
        lab(hint, 10, fg="#52627a", wraplength=colw, justify="left").pack(anchor="w", pady=(0, S(14)))

        # Segmented "By Name / By Email" switch
        th_ = S(38); segw = colw; tw = (segw - S(8)) // 2
        seg = tk.Label(form, bd=0, bg=WH, image=g.photo(g.rr(segw, th_ + S(8), (th_ + S(8)) * 0.3, g.rgb("#e8eff9"))))
        seg.pack(pady=(0, S(12)))
        for i, (mk, txt) in enumerate((("name", t("By Name", "Sa Pangalan")),
                                       ("email", t("By Email", "Sa Email")))):
            on = self._login_mode == mk
            b = self._round_btn(seg, g, tw, th_, txt, NAVY if on else "#e8eff9",
                                WH if on else GRAY, NAVY if on else "#d9e5f6",
                                (lambda mm=mk: self.show_login(mode=mm)), size=10, bg="#e8eff9")
            b.place(x=S(4) + i * tw, y=S(4))

        def field(parent, label, optional=False):
            box = tk.Frame(parent, bg=WH)
            tk.Label(box, text=label + (f"  {self.s('mid_opt')}" if optional else ""),
                     font=(F, self.sf(10), "bold"), bg=WH, fg=NAVY).pack(anchor="w")
            wrap = tk.Frame(box, bg=LINE, padx=2, pady=2); wrap.pack(fill="x", pady=(S(3), 0))
            e = tk.Entry(wrap, font=(F, self.sf(12)), bg="#f4f8fe", fg=C["txt"], relief="flat",
                         bd=0, insertbackground=BLUE)
            e.pack(fill="x", ipady=S(8), ipadx=S(6))
            e.bind("<FocusIn>",  lambda ev: wrap.configure(bg=BLUE))
            e.bind("<FocusOut>", lambda ev: wrap.configure(bg=LINE))
            return box, e

        if is_name:
            row = tk.Frame(form, bg=WH); row.pack(fill="x")
            row.grid_columnconfigure((0, 1), weight=1, uniform="n")
            b1, self._ll = field(row, self.s("l_login_last"));  b1.grid(row=0, column=0, sticky="ew", padx=(0, S(6)))
            b2, self._lf = field(row, self.s("l_login_first")); b2.grid(row=0, column=1, sticky="ew", padx=(S(6), 0))
            b3, self._lm = field(form, self.s("l_login_mid"), True); b3.pack(fill="x", pady=(S(8), 0))
            self._ll.bind("<Return>", lambda e: self._lf.focus())
            self._lf.bind("<Return>", lambda e: self._lm.focus())
            self._lm.bind("<Return>", lambda e: self._do_login())
            login_cmd = self._do_login
        else:
            b1, self._le = field(form, self.s("l_login_email")); b1.pack(fill="x")
            ph = self.s("lph_email")
            self._le.insert(0, ph); self._le.config(fg=C["mut"])
            self._le.bind("<FocusIn>", lambda e: (self._le.delete(0, "end"), self._le.config(fg=C["txt"]))
                          if self._le.get() == ph else None)
            self._le.bind("<Return>", lambda e: self._do_login_email())
            login_cmd = self._do_login_email

        self._round_btn(form, g, colw, S(54), self.s("b_login"), BLUE, WH, self._dim(BLUE),
                        login_cmd, size=13).pack(pady=(S(18), S(12)))

        dv = tk.Frame(form, bg=WH); dv.pack(fill="x", pady=(0, S(10)))
        tk.Frame(dv, bg=LINE, height=1).pack(side="left", fill="x", expand=True)
        tk.Label(dv, text=t("or continue with", "o magpatuloy gamit ang"), font=(F, self.sf(9)),
                 bg=WH, fg="#9aaac0").pack(side="left", padx=S(10))
        tk.Frame(dv, bg=LINE, height=1).pack(side="left", fill="x", expand=True)

        self._round_btn(form, g, colw, S(50), t("Scan QR code", "I-scan ang QR code"), WH, NAVY,
                        C["acc_lt"], (lambda: self.show_qr_login(back=self.show_login)),
                        outline="#c3d3ea", size=11, ic=("qr", NAVY)).pack()

        back = tk.Label(form, text=self.s("b_back"), font=(F, self.sf(10), "bold"),
                        bg=WH, fg=GRAY, cursor="hand2")
        back.pack(anchor="w", pady=(S(14), 0))
        back.bind("<Enter>", lambda e: back.configure(fg=BLUE))
        back.bind("<Leave>", lambda e: back.configure(fg=GRAY))
        back.bind("<ButtonRelease-1>", lambda e: self.show_welcome())

        lab(t("Your information is protected and used only for barangay health services.",
              "Protektado ang iyong impormasyon at gagamitin lamang sa serbisyong pangkalusugan ng barangay."),
            8, fg="#9aaac0", wraplength=colw, justify="left").pack(anchor="w", pady=(S(10), 0))

        self._nav_bar()
