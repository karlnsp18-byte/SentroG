import serial, serial.tools.list_ports, time

ports = [p.device for p in serial.tools.list_ports.comports()]
print("Ports found:", ports)
if not ports:
    raise SystemExit("No serial port found. Check the USB cable.")

with serial.Serial(ports[0], 9600, timeout=1) as ser:
    time.sleep(2)
    for _ in range(10):
        print(repr(ser.readline()))