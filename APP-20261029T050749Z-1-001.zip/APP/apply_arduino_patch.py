"""
apply_arduino_patch.py
Usage:  python apply_arduino_patch.py sentro_ginhawa.py

Does 2 things to your kiosk file (a .bak backup is made first):
  1. Adds the imports for pyserial + deque
  2. Replaces the old mock "SENSOR STUB" read_sensor() with a real Arduino
     temperature reader (other sensors stay simulated for now)
"""
import sys, shutil

IMPORTS = '''import time
from collections import deque
try:
    import serial
    import serial.tools.list_ports
except ImportError:
    serial = None
    print("[WARNING] pyserial not installed. Run: pip install pyserial")
'''

NEW_BLOCK = '''# ── ARDUINO TEMPERATURE SENSOR ────────────────────────────────────────────────
# Arduino must print one line per reading at 9600 baud, e.g.  TEMP:36.5
# Optional overrides in .env:
#   SENTRO_TEMP_PORT=/dev/ttyUSB0     (blank = auto-detect ttyUSB*/ttyACM*)
#   SENTRO_TEMP_BAUD=9600
TEMP_PORT     = os.environ.get("SENTRO_TEMP_PORT", "")
TEMP_BAUD     = int(os.environ.get("SENTRO_TEMP_BAUD", "9600"))
TEMP_MIN_OK   = 30.0    # readings outside this range are treated as sensor glitches
TEMP_MAX_OK   = 45.0
TEMP_SAMPLES  = 3       # fresh readings averaged per "Read Sensor" press
TEMP_TIMEOUT  = 8.0     # seconds to wait before reporting failure

class ArduinoTemp:
    """Keeps one serial connection open and remembers recent valid readings."""
    def __init__(self, port, baud):
        self.port, self.baud = port, baud
        self._samples = deque(maxlen=50)      # (monotonic_time, value)
        self._lock = threading.Lock()
        self._thread = None
        self.connected = False
        self.last_error = None

    def start(self):
        if serial is None:
            self.last_error = "pyserial not installed"
            return
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _find_port(self):
        if self.port:
            return self.port
        for p in serial.tools.list_ports.comports():
            d = p.device
            if any(k in d for k in ("ttyUSB", "ttyACM", "usbmodem", "usbserial")) \\
               or d.startswith("COM"):
                return d
        return None

    def _run(self):
        while True:
            port = self._find_port()
            if not port:
                self.connected = False
                self.last_error = "Arduino not found"
                time.sleep(2); continue
            try:
                with serial.Serial(port, self.baud, timeout=1) as ser:
                    time.sleep(2)                 # Arduino auto-resets when port opens
                    ser.reset_input_buffer()
                    self.connected, self.last_error = True, None
                    while True:
                        raw = ser.readline()
                        if raw:
                            self._parse(raw.decode("utf-8", "ignore").strip())
            except Exception as e:                # unplugged / busy -> retry
                self.connected = False
                self.last_error = str(e)
                time.sleep(2)

    def _parse(self, line):
        if not line.upper().startswith("TEMP:"):
            return
        try:
            v = float(line.split(":", 1)[1])
        except ValueError:
            return
        if TEMP_MIN_OK <= v <= TEMP_MAX_OK:
            with self._lock:
                self._samples.append((time.monotonic(), v))

    def read(self):
        """Returns (value_str, error_str). Only uses readings taken AFTER this call,
        so a previous resident's old reading is never reused."""
        t0 = time.monotonic()
        self.start()
        deadline = t0 + TEMP_TIMEOUT
        while time.monotonic() < deadline:
            with self._lock:
                fresh = [v for ts, v in self._samples if ts >= t0]
            if len(fresh) >= TEMP_SAMPLES:
                fresh = fresh[-TEMP_SAMPLES:]
                return f"{sum(fresh) / len(fresh):.1f}", None
            time.sleep(0.1)
        return None, (self.last_error or "No valid temperature data from Arduino")

temp_sensor = ArduinoTemp(TEMP_PORT, TEMP_BAUD)
temp_sensor.start()    # connect at startup so the Arduino reset is already done by Step 3

# ── SENSOR STUB (other sensors) ───────────────────────────────────────────────
# Temperature is REAL (Arduino). The rest remain simulated until wired up.
def read_sensor(sensor_id: str):
    """Returns (value_str, error_str) — value_str is None on failure."""
    if sensor_id == "temperature":
        return temp_sensor.read()
    time.sleep(1.2)   # simulate read delay
    stubs = {
        "bp":      f"{random.randint(110,135)}/{random.randint(70,90)}",
        "glucose": f"{random.randint(80,120)}",
        "height":  f"{random.randint(155,175)}",
        "weight":  f"{random.randint(50,80)}",
    }
    return stubs.get(sensor_id, None), None

'''

def main():
    if len(sys.argv) != 2:
        print("Usage: python apply_arduino_patch.py sentro_ginhawa.py"); return 1
    path = sys.argv[1]
    with open(path, encoding="utf-8") as f:
        src = f.read()

    if "class ArduinoTemp" in src:
        print("Already patched - nothing to do."); return 0

    # 1) imports
    anchor_imp = "import time\n"
    if src.count(anchor_imp) < 1:
        print("ERROR: couldn't find 'import time' line."); return 1
    src = src.replace(anchor_imp, IMPORTS, 1)

    # 2) sensor stub -> real Arduino reader
    start_marker = "# ── SENSOR STUB"
    end_marker = "def dispense_lancet():"
    if start_marker not in src or end_marker not in src:
        print("ERROR: couldn't find the SENSOR STUB section."); return 1
    s = src.index(start_marker)
    e = src.index(end_marker)
    if e < s:
        print("ERROR: unexpected section order."); return 1
    src = src[:s] + NEW_BLOCK + src[e:]

    shutil.copy(path, path + ".bak")
    with open(path, "w", encoding="utf-8") as f:
        f.write(src)
    print(f"Done. Backup saved as {path}.bak")
    return 0

if __name__ == "__main__":
    sys.exit(main())
