"""
Usage (run from the folder that has BOTH files):
    python apply_login_patch.py sentro_ginhawa.py

It reads login_redesign.py, replaces the old show_login in your app file,
and writes a NEW file next to it: <yourfile>_patched.py  (original is untouched).
Then run the _patched file.
"""
import sys, os

if len(sys.argv) < 2:
    sys.exit("Usage: python apply_login_patch.py <your_app_file.py>")

src = sys.argv[1]
here = os.path.dirname(os.path.abspath(__file__))
snippet_path = os.path.join(here, "login_redesign.py")

with open(src, encoding="utf-8") as f:
    app = f.read()
with open(snippet_path, encoding="utf-8") as f:
    snip = f.read()

# Keep only the method code (drop the "HOW TO APPLY" comment header)
marker = "    # ── Shared graphics helpers"
i = snip.find(marker)
if i == -1:
    sys.exit("Could not find the start of the snippet in login_redesign.py")
snip = snip[i:].rstrip() + "\n\n"

start = app.find("    def show_login(self")
end = app.find("    def _complete_login")
if start == -1 or end == -1 or end < start:
    sys.exit("Could not find show_login / _complete_login in your app file.")

patched = app[:start] + snip + app[end:]
out = os.path.splitext(src)[0] + "_patched.py"
with open(out, "w", encoding="utf-8") as f:
    f.write(patched)
print(f"Done! Run this file instead: {out}")
