"""Sentro Ginhawa: Smart Barangay Health Kiosk — STI College Caloocan, Thesis Project 2025"""
import sys
import os
import sqlite3
import threading
import tempfile
import subprocess
import smtplib
import ssl
import random
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime
import tkinter as tk
from tkinter import ttk
import cv2
from PIL import Image, ImageTk
from dotenv import load_dotenv
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfgen import canvas as rlc

# ── EMAIL CONFIG ──────────────────────────────────────────────────────────────
# Credentials are loaded from a local .env file (never committed to git).
# See the setup steps in the project README / chat for how to create it.
load_dotenv()

EMAIL_SENDER   = os.environ.get("SENTRO_EMAIL_SENDER", "")
EMAIL_PASSWORD = os.environ.get("SENTRO_EMAIL_PASSWORD", "")
EMAIL_SMTP     = "smtp.gmail.com"
EMAIL_PORT     = 465   # SSL port

if not EMAIL_SENDER or not EMAIL_PASSWORD:
    print(
        "[WARNING] SENTRO_EMAIL_SENDER / SENTRO_EMAIL_PASSWORD not set.\n"
        "          Create a '.env' file next to this script with:\n"
        "              SENTRO_EMAIL_SENDER=your_kiosk_email@gmail.com\n"
        "              SENTRO_EMAIL_PASSWORD=your_16_char_app_password\n"
        "          Email sending will be disabled until then."
    )

# ── IDLE AUTO-LOGOUT ────────────────────────────────────────────────────────
# A logged-in resident's health data stays on screen until they log out —
# on a shared public kiosk, an idle timeout prevents the next person from
# seeing the previous resident's records. Override in .env if needed, e.g.:
#   IDLE_LOGOUT_SECONDS=60
IDLE_LOGOUT_SECONDS = int(os.environ.get("IDLE_LOGOUT_SECONDS", "90"))

# ── DATABASE ──────────────────────────────────────────────────────────────────
DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sentro_ginhawa.db')

def init_db():
    with sqlite3.connect(DB) as c:
        c.execute('''CREATE TABLE IF NOT EXISTS residents
                     (id   INTEGER PRIMARY KEY AUTOINCREMENT,
                      name TEXT, age TEXT, gender TEXT, email TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS health_records
                     (id        INTEGER PRIMARY KEY AUTOINCREMENT,
                      name      TEXT, temp    TEXT, bp      TEXT,
                      glucose   TEXT, height  TEXT, weight  TEXT,
                      bmi       TEXT, timestamp TEXT)''')
        # Migrations for existing DBs
        for col in ("email TEXT", "birthdate TEXT"):
            try:
                c.execute(f"ALTER TABLE residents ADD COLUMN {col}")
            except Exception:
                pass

init_db()

# ── EMOJI FONT CHECK ─────────────────────────────────────────────────────────
# The UI uses emoji glyphs throughout (buttons, icons, status text). Windows
# and macOS ship a color emoji font by default, but a fresh Raspberry Pi OS
# install may not — in that case these glyphs render as empty boxes instead
# of icons. This is a lightweight, best-effort check purely to warn early
# with a fix, rather than swapping every glyph in the UI for plain text.
def _check_emoji_font():
    if sys.platform != "linux":
        return True   # Windows/macOS ship a color emoji font natively
    try:
        out = subprocess.run(["fc-list"], capture_output=True, text=True,
                              timeout=3).stdout.lower()
        return "emoji" in out
    except Exception:
        return True   # fontconfig not available to check — don't false-alarm

if not _check_emoji_font():
    print(
        "[WARNING] No color emoji font detected on this system.\n"
        "          Icons in the kiosk UI (buttons, status glyphs) may show as\n"
        "          empty boxes instead of icons. To fix on Raspberry Pi OS:\n"
        "              sudo apt install -y fonts-noto-color-emoji\n"
        "              sudo reboot"
    )

# ── THEME ─────────────────────────────────────────────────────────────────────
C = {
    "bg":      "#f0f4f8",
    "surface": "#ffffff",
    "s2":      "#e8f0fe",
    "hdr":     "#1a3a6b",
    "hdr2":    "#1e4d8c",
    "acc":     "#1a56a0",
    "acc2":    "#154d8f",
    "acc_lt":  "#dbeafe",
    "grn":     "#16a34a",
    "grn_lt":  "#dcfce7",
    "gld":     "#d97706",
    "gld_lt":  "#fef9c3",
    "red":     "#dc2626",
    "txt":     "#0f172a",
    "sub":     "#475569",
    "mut":     "#94a3b8",
    "bdr":     "#e2e8f0",
    "div":     "#e2e8f0",
    "strip":   "#f8fafc",
    "done":    "#f0fdf4",
    "done_b":  "#16a34a",
    "upd":     "#fffbeb",
    "upd_b":   "#d97706",
}

# ── STRINGS ───────────────────────────────────────────────────────────────────
EN = {
    "wtitle":"SENTRO GINHAWA",        "wsub":"Smart Barangay Health Kiosk",
    "wtag":"Free health check — no appointment needed",
    "b_exist":"I Already Have an Account",
    "b_new":"Register as New Resident",
    "ltitle":"Resident Login",
    "lhint":"Enter your registered name to log in:",
    "lph":"Full Name (e.g. Juan dela Cruz)",
    "l_login_last":"Last Name",   "l_login_first":"First Name",
    "l_login_mid":"Middle Name",
    "tab_by_name":"👤  By Name",
    "tab_by_email":"📧  By Email",
    "lhint_email":"Enter your registered email to log in:",
    "l_login_email":"Email Address",
    "lph_email":"e.g. juan@email.com",
    "e_email_empty":"Please enter your email address.",
    "e_email_nf":"No account found with that email. Please log in by name, or register first.",
    "idle_logout_title":"Session Timed Out",
    "idle_logout_msg":"You've been logged out due to inactivity.",
    "b_login":"Log In →",             "b_qr":"📷  Scan QR Code",
    "b_back":"← Back",
    "qtitle":"Scan Your QR Code",
    "qhint":"Hold your QR card in front of the camera.",
    "qwait":"Waiting for QR code…",
    "rtitle":"New Resident Registration",
    "rsub":"Fill in your details to create your health profile.",
    "l_name":"Full Name",             "l_age":"Age",
    "l_lastname":"Last Name",         "l_firstname":"First Name",
    "l_middlename":"Middle Name",     "mid_opt":"(optional)",
    "l_birthdate":"Date of Birth",    "bdate_ph":"MM/DD/YYYY",
    "l_gender":"Gender",              "male":"Male",      "female":"Female",
    "b_reg":"Register & Continue →",
    "b_update":"✎  Update Health Data",
    "b_cancel":"✕  Cancel Update",
    "b_save":"💾  Save Health Record",
    "b_print":"🖨  Print Record",
    "b_myqr":"🔲  My QR Card",
    "b_history":"📜  Health History",
    "hist_title":"My Health Record History",
    "hist_latest":"Latest",
    "hist_norec":"No past records found yet.",
    "b_logout":"Logout",              "b_exit":"Exit Kiosk",
    "umode":"✎  UPDATE MODE  —  Tap any card to edit",
    "last":"Last recorded:",          "norec":"No records yet. Tap Update to begin.",
    "mod_temp":"Body Temperature",    "mod_bp":"Blood Pressure",
    "mod_glu":"Blood Glucose",        "mod_ht":"Height",
    "mod_wt":"Weight",                "mod_bmi":"BMI",
    "u_temp":"°C","u_bp":"mmHg","u_glu":"mg/dL","u_ht":"cm","u_wt":"kg",
    "notyet":"Not yet recorded",      "bmi_hint":"Auto-calculated from Height & Weight",
    "done_b":"✓  Recorded",           "edit_b":"Tap to Edit",
    "lang":"Filipino",
    "norm":"Normal","under":"Underweight","over":"Overweight","obese":"Obese",
    "e_name":"Please enter your name.",
    "e_gender":"Please select your gender.",
    "e_nf":"Name not found. Please register first.",
    "e_cam":"Camera not found. Please use name login.",
    "ok":"Health record saved successfully!",
    "e_db":"Database error: ",        "p_ok":"Record sent to printer.",
    "qr_fail":"No account found for this QR code.",
    "e_already_exists":"A resident named \"{name}\" is already registered.\n\nPlease log in instead.",
    # Input mode dialog
    "input_mode_title":"How would you like to record this?",
    "input_mode_sub":"Choose an input method for:",
    "btn_manual":"✏️  Manual Entry",
    "btn_sensor":"🔌  Read from Sensor",
    "sensor_note":"Connect the sensor and press Read.",
    "btn_read":"Read Sensor",
    "btn_cancel2":"Cancel",
    "sensor_wait":"Reading from sensor…",
    "sensor_fail":"Could not read from sensor. Please enter manually.",
    "btn_lancet":"🩸  Dispense Lancet",
    "lancet_wait":"Dispensing lancet…",
    "lancet_ok":"Lancet dispensed. Please proceed with the finger prick.",
    "lancet_fail":"Could not dispense a lancet. Please use a manual lancet.",
    # Email
    "l_email":"Email Address (optional)",
    "email_ph":"e.g. juan@email.com",
    "b_email":"📧  Email Record",
    "email_sending":"Sending email…",
    "email_ok":"Health record sent to {email}",
    "email_fail":"Could not send email: {err}",
    "email_none":"No email address on file.\n\nPlease update your profile to add one.",
    "email_cfg":"Email is not configured on this kiosk.\nPlease contact the administrator.",
    # Terms & Conditions
    "tnc_title":"Terms & Conditions",
    "tnc_sub":"Please read and agree before continuing.",
    "tnc_agree":"✔  I Agree",
    "tnc_decline":"✖  Decline",
    "tnc_body":(
        "DATA PRIVACY & CONSENT\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "By using Sentro Ginhawa, you consent to the collection and secure storage of your "
        "personal information (name, age, gender, date of birth, email address) and health "
        "measurements (body temperature, blood pressure, blood glucose, height, weight, BMI) "
        "in accordance with the Data Privacy Act of 2012 (Republic Act No. 10173).\n\n"
        "Your data is collected solely for the purpose of providing barangay health monitoring "
        "services. It will not be sold, shared with third parties, or used for commercial "
        "purposes without your explicit consent. You may request access to, correction of, or "
        "deletion of your records at any time by contacting the barangay health officer.\n\n"
        "LIABILITY DISCLAIMER\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "The health readings provided by this kiosk are for general screening and informational "
        "purposes only. They do NOT constitute a medical diagnosis, professional medical advice, "
        "or a substitute for consultation with a licensed healthcare provider.\n\n"
        "The barangay, STI College Caloocan, and the developers of Sentro Ginhawa shall not be "
        "held liable for any health decisions made solely on the basis of kiosk readings. If you "
        "are experiencing a medical emergency or have concerns about your health, please consult "
        "a qualified medical professional immediately.\n\n"
        "By tapping 'I Agree', you confirm that you have read, understood, and accepted these "
        "terms and conditions."
    ),
    # ── Adviser: welcome / wizard / summary strings ──
    "wi_welcome": "Welcome, {name}!",
    "wi_reg_success": "✅ Registration successful! Your health profile has been created. Here is your personal QR code for future logins.",
    "wi_prompt": "What would you like to do today? Select an option below.",
    "wi_guided_title": "🩺 Guided Health Check",
    "wi_guided_desc": "Follow step-by-step measurements for Height, Weight, BP, Temp, and Blood Sugar.",
    "wi_guided_btn": "Start Health Check →",
    "wi_dash_title": "📊 Dashboard & Records",
    "wi_dash_desc": "View your past health assessments and monitor your health trends over time.",
    "wi_dash_btn": "View Past Records",
    "wiz_step1_title": "Step 1 of 5 — Height",
    "wiz_step1_desc": "Measure your height on the kiosk platform.",
    "wiz_step2_title": "Step 2 of 5 — Weight",
    "wiz_step2_desc": "Measure your body weight on the scale platform.",
    "wiz_step3_title": "Step 3 of 5 — Body Temperature",
    "wiz_step3_desc": "Measure body temperature using the non-contact IR sensor.",
    "wiz_step4_title": "Step 4 of 5 — Blood Pressure",
    "wiz_step4_desc": "Measure resting blood pressure using the automatic cuff.",
    "wiz_step5_title": "Step 5 of 5 — Blood Glucose",
    "wiz_step5_desc": "Optional blood sugar test via finger prick.",
    "wiz_summary_title": "📋 Step 6 of 6 — Health Record Summary",
    "wiz_tips_title": "💡 Simple Health Tips & Reminders:",
    "wiz_tip_low_glucose": "🍏 Low Blood Sugar: Consider having a light snack or juice. Rest if feeling dizzy.",
    "wiz_tip_high_glucose": "💧 High Blood Sugar: Drink adequate water and consult a Barangay Health Worker if needed.",
    "wiz_tip_norm_glucose": "✨ Blood Sugar: Within normal range. Keep up the healthy lifestyle!",
    "wiz_tip_high_bp": "🫀 Blood Pressure: Slightly elevated. Take a deep breath, rest for 5-10 minutes, and recheck.",
    "wiz_tip_low_bp": "🫀 Blood Pressure: Slightly low. Drink water and avoid standing up quickly.",
    "wiz_tip_norm_bp": "🫀 Blood Pressure: Normal and healthy.",
    "wiz_tip_fever": "🌡️ Temperature: Mild fever detected. Rest in a cool area and stay hydrated.",
    "wiz_tip_default": "💡 Reminder: Regular health monitoring helps maintain good wellness. Ask your Barangay Health Officer if you have questions.",
    "btn_save_only": "💾 Save Record Only",
    "btn_save_print": "🖨 Save & Print Receipt",
    "btn_next_step": "Next Step →",
    "btn_skip_test": "Skip Test ↷",
    "btn_start_screening": "🩺 Start Health Screening",
    "wiz_howto": "📖  How to perform this test:",
    "wiz_s1_t1": "1. Stand upright on the kiosk scale platform.",
    "wiz_s1_t2": "2. Keep your back straight and look straight ahead.",
    "wiz_s1_t3": "3. Tap 'Read Sensor' below to record your height.",
    "wiz_s2_t1": "1. Remain standing still with feet flat on the metal plate.",
    "wiz_s2_t2": "2. Avoid leaning against the side handles or moving.",
    "wiz_s2_t3": "3. Tap 'Read Sensor' below to record your weight.",
    "wiz_s3_t1": "1. Position your forehead 3–5 cm away from the infrared sensor.",
    "wiz_s3_t2": "2. Remove caps, hats, or heavy hair covering your forehead.",
    "wiz_s3_t3": "3. Tap 'Read Sensor' below to record your temperature.",
    "wiz_s4_t1": "1. Sit comfortably with both feet flat on the floor.",
    "wiz_s4_t2": "2. Insert your LEFT arm completely into the automatic cuff.",
    "wiz_s4_t3": "3. Keep still and do not speak while the cuff inflates.",
    "wiz_s5_t1": "1. Tap 'Dispense Lancet' to retrieve a sterile lancet needle.",
    "wiz_s5_t2": "2. Prick finger and place a drop of blood on the test strip.",
    "wiz_s5_t3": "3. Insert strip into the meter and tap 'Read Sensor'.",
    "btn_read_sensor": "🔌  Read Sensor",
    "wiz_read_fail": "Read failed — enter manually.",
    "wiz_err_empty": "Please take/enter a reading, or tap 'Skip Test' to bypass.",
    "wiz_err_num": "Please enter a valid number.",
    "wiz_skipped": "(skipped)",
    "btn_back_arrow": "⬅  Back",
    "btn_back_menu": "⬅  Back to Menu",
    "wi_print_qr": "🖨  Print QR Card",
    "wl_qr_hint": "Fastest way — just show your QR card to the camera",
    "wiz_tip_pre_glucose": "🥗 Blood Sugar: Slightly above normal. Limit sweet drinks and ask your Barangay Health Worker about a follow-up check.",
    "wiz_tip_high_bp2": "🫀 Blood Pressure: High. Sit and rest, then recheck. Please consult your Barangay Health Worker soon.",
    "wiz_disclaimer": "These are general reminders only, not a medical diagnosis.",
    "wi_qr_sent": "QR card sent to print.",
    "wi_qr_card_line": "Show this QR at the kiosk\nto log in instantly.",
    "dash_cta_title": "💡  Ready for your checkup?",
    "dash_cta_body": "Tap \"Start Health Screening\" or tap any card below to take a reading.",
    "dash_tap_measure": "👆  Tap to Measure",
    "dash_auto": "AUTO",
}
FIL = {
    "wtitle":"SENTRO GINHAWA",        "wsub":"Matalinong Kiosk ng Kalusugan sa Barangay",
    "wtag":"Libreng health check — walang kailangang appointment",
    "b_exist":"Mayroon Na Akong Account",
    "b_new":"Mag-rehistro",
    "ltitle":"Login ng Residente",
    "lhint":"Ilagay ang iyong nairehistrong pangalan para mag-login:",
    "lph":"Buong Pangalan (hal. Juan dela Cruz)",
    "l_login_last":"Apelyido",   "l_login_first":"Pangalan",
    "l_login_mid":"Gitnang Pangalan",
    "tab_by_name":"👤  Sa Pangalan",
    "tab_by_email":"📧  Sa Email",
    "lhint_email":"Ilagay ang iyong nairehistrong email para mag-login:",
    "l_login_email":"Email Address",
    "lph_email":"hal. juan@email.com",
    "e_email_empty":"Mangyaring ilagay ang iyong email address.",
    "e_email_nf":"Walang account na nahanap gamit ang email na iyon. Mag-login sa pangalan, o mag-rehistro muna.",
    "idle_logout_title":"Natapos ang Session",
    "idle_logout_msg":"Na-logout ka dahil sa hindi paggamit sa loob ng ilang sandali.",
    "b_login":"Mag-login →",          "b_qr":"📷  I-scan ang QR Code",
    "b_back":"← Bumalik",
    "qtitle":"I-scan ang Iyong QR Code",
    "qhint":"Itaas ang iyong QR card sa harap ng camera.",
    "qwait":"Naghihintay ng QR code…",
    "rtitle":"Pagpaparehistro ng Bagong Residente",
    "rsub":"Punan ang iyong impormasyon upang lumikha ng health profile.",
    "l_name":"Buong Pangalan",         "l_age":"Edad",
    "l_lastname":"Apelyido",           "l_firstname":"Pangalan",
    "l_middlename":"Gitnang Pangalan", "mid_opt":"(opsyonal)",
    "l_birthdate":"Petsa ng Kapanganakan", "bdate_ph":"MM/DD/YYYY",
    "l_gender":"Kasarian",             "male":"Lalaki",    "female":"Babae",
    "b_reg":"Irehistro at Magpatuloy →",
    "b_update":"✎  I-update ang Health Data",
    "b_cancel":"✕  Kanselahin ang Update",
    "b_save":"💾  I-save ang Health Record",
    "b_print":"🖨  I-print ang Record",
    "b_myqr":"🔲  Aking QR Card",
    "b_history":"📜  Kasaysayan ng Kalusugan",
    "hist_title":"Kasaysayan ng Health Record Ko",
    "hist_latest":"Pinakabago",
    "hist_norec":"Walang nakitang dating record.",
    "b_logout":"Mag-logout",           "b_exit":"Lumabas sa Kiosk",
    "umode":"✎  UPDATE MODE  —  Pindutin ang card para i-edit",
    "last":"Huling naitala:",          "norec":"Wala pang record. Pindutin ang Update.",
    "mod_temp":"Temperatura ng Katawan","mod_bp":"Presyon ng Dugo",
    "mod_glu":"Glucose sa Dugo",       "mod_ht":"Taas",
    "mod_wt":"Timbang",                "mod_bmi":"BMI",
    "u_temp":"°C","u_bp":"mmHg","u_glu":"mg/dL","u_ht":"cm","u_wt":"kg",
    "notyet":"Hindi pa naitala",       "bmi_hint":"Awtomatikong kinakalkula",
    "done_b":"✓  Naitala na",          "edit_b":"Pindutin para I-edit",
    "lang":"English",
    "norm":"Normal","under":"Kulang ang Timbang","over":"Sobra ang Timbang","obese":"Obese",
    "e_name":"Mangyaring ilagay ang iyong pangalan.",
    "e_gender":"Mangyaring piliin ang iyong kasarian.",
    "e_nf":"Hindi nahanap. Mangyaring mag-rehistro muna.",
    "e_cam":"Hindi nahanap ang camera. Gamitin ang login sa pangalan.",
    "ok":"Matagumpay na na-save ang health record!",
    "e_db":"Error sa database: ",      "p_ok":"Naipadala na ang record sa printer.",
    "qr_fail":"Walang account na nahanap para sa QR code na ito.",
    "e_already_exists":"May nakarehistrong residente na na may pangalang \"{name}\".\n\nMangyaring mag-login na lang.",
    "input_mode_title":"Paano mo gustong itala ito?",
    "input_mode_sub":"Pumili ng paraan para sa:",
    "btn_manual":"✏️  Manual na Pagpasok",
    "btn_sensor":"🔌  Basahin mula sa Sensor",
    "sensor_note":"I-connect ang sensor at pindutin ang Basahin.",
    "btn_read":"Basahin ang Sensor",
    "btn_cancel2":"Kanselahin",
    "sensor_wait":"Binabasa ang sensor…",
    "sensor_fail":"Hindi mabasa ang sensor. Mangyaring mag-enter nang mano-mano.",
    "btn_lancet":"🩸  Maglabas ng Lancet",
    "lancet_wait":"Naglalabas ng lancet…",
    "lancet_ok":"Nailabas na ang lancet. Magpatuloy sa pagtusok sa daliri.",
    "lancet_fail":"Hindi makapaglabas ng lancet. Gumamit ng manual na lancet.",
    # Email
    "l_email":"Email Address (opsyonal)",
    "email_ph":"hal. juan@email.com",
    "b_email":"📧  I-email ang Record",
    "email_sending":"Nagpapadala ng email…",
    "email_ok":"Naipadala ang health record sa {email}",
    "email_fail":"Hindi mapadala ang email: {err}",
    "email_none":"Walang email address na naka-save.\n\nI-update ang iyong profile para magdagdag ng isa.",
    "email_cfg":"Hindi naka-configure ang email sa kioskong ito.\nMangyaring makipag-ugnayan sa administrator.",
    # Terms & Conditions
    "tnc_title":"Mga Tuntunin at Kundisyon",
    "tnc_sub":"Pakibasa at sumang-ayon bago magpatuloy.",
    "tnc_agree":"✔  Sumasang-ayon Ako",
    "tnc_decline":"✖  Tanggihan",
    "tnc_body":(
        "PRIVACY NG DATA AT PAHINTULOT\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "Sa paggamit ng Sentro Ginhawa, pumapayag ka sa pagkolekta at ligtas na pag-iimbak ng "
        "iyong personal na impormasyon (pangalan, edad, kasarian, petsa ng kapanganakan, email) "
        "at mga sukat ng kalusugan (temperatura, presyon ng dugo, glucose, taas, timbang, BMI) "
        "alinsunod sa Data Privacy Act of 2012 (Batas Republika Blg. 10173).\n\n"
        "Ang iyong datos ay kinokolekta lamang para sa pagbibigay ng serbisyong pangkalusugan sa "
        "barangay. Hindi ito ibebenta, ibabahagi sa mga third party, o gagamitin para sa "
        "komersyal na layunin nang walang iyong pahintulot. Maaari kang humingi ng access, "
        "pagwawasto, o pagtanggal ng iyong mga rekord sa pamamagitan ng pakikipag-ugnayan sa "
        "health officer ng barangay.\n\n"
        "DISCLAIMER SA PANANAGUTAN\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "Ang mga resulta ng kalusugan mula sa kioskong ito ay para lamang sa pangkalahatang "
        "pagsusuri at impormasyon. Hindi ito bumubuo ng medikal na diagnosis, propesyonal na "
        "payo sa kalusugan, o kapalit ng konsultasyon sa lisensyadong manggagamot.\n\n"
        "Ang barangay, STI College Caloocan, at mga developer ng Sentro Ginhawa ay hindi "
        "mananagot sa anumang desisyon sa kalusugan na ginawa batay lamang sa mga resulta ng "
        "kiosk. Kung mayroon kang medikal na emergency o alalahanin tungkol sa iyong kalusugan, "
        "kumonsulta agad sa isang kwalipikadong manggagamot.\n\n"
        "Sa pag-tap ng 'Sumasang-ayon Ako', kinukumpirma mo na nabasa, naunawaan, at tinatanggap "
        "mo ang mga tuntuning ito."
    ),
    # ── Adviser: welcome / wizard / summary strings ──
    "wi_welcome": "Maligayang Pagdating, {name}!",
    "wi_reg_success": "✅ Matagumpay ang pagrehistro! Nagawa na ang iyong health profile. Narito ang iyong personal na QR code para sa susunod na login.",
    "wi_prompt": "Ano ang nais mong gawin ngayong araw? Pumili sa mga opsyon sa ibaba.",
    "wi_guided_title": "🩺 Guided Health Check",
    "wi_guided_desc": "Sundan ang step-by-step na pagsusuri para sa Height, Weight, BP, Temp, at Blood Sugar.",
    "wi_guided_btn": "Magsimula Na →",
    "wi_dash_title": "📊 Dashboard & Records",
    "wi_dash_desc": "Tingnan ang iyong mga nakaraang pagsusuri at subaybayan ang iyong kalusugan.",
    "wi_dash_btn": "Tingnan ang Past Records",
    "wiz_step1_title": "Hakbang 1 ng 5 — Taas (Height)",
    "wiz_step1_desc": "Sukatin ang iyong taas sa platform ng kiosk.",
    "wiz_step2_title": "Hakbang 2 ng 5 — Timbang (Weight)",
    "wiz_step2_desc": "Sukatin ang iyong timbang sa timbangan ng kiosk.",
    "wiz_step3_title": "Hakbang 3 ng 5 — Temperatura ng Katawan",
    "wiz_step3_desc": "Sukatin ang temperatura gamit ang non-contact IR sensor.",
    "wiz_step4_title": "Hakbang 4 ng 5 — Presyon ng Dugo (BP)",
    "wiz_step4_desc": "Sukatin ang presyon ng dugo gamit ang automatic cuff.",
    "wiz_step5_title": "Hakbang 5 ng 5 — Glucose sa Dugo",
    "wiz_step5_desc": "Opsyonal na pagsusuri ng asukal sa dugo.",
    "wiz_summary_title": "📋 Hakbang 6 ng 6 — Buod ng Kalusugan",
    "wiz_tips_title": "💡 Mga Simpleng Payo at Paalala sa Kalusugan:",
    "wiz_tip_low_glucose": "🍏 Mababang Blood Sugar: Maaaring kumain ng meryenda o uminom ng juice. Magpahinga kung nakararamdam ng pagkahilo.",
    "wiz_tip_high_glucose": "💧 Mataas na Blood Sugar: Uminom ng sapat na tubig at isangguni sa Barangay Health Worker kung kinakailangan.",
    "wiz_tip_norm_glucose": "✨ Blood Sugar: Nasa maayos at katamtamang antas. Ipagpatuloy ang malusog na pamumuhay!",
    "wiz_tip_high_bp": "🫀 Presyon ng Dugo: Medyo mataas. Huminga nang malalim, magpahinga ng 5-10 minuto, at magpasuri ulit.",
    "wiz_tip_low_bp": "🫀 Presyon ng Dugo: Medyo mababa. Uminom ng tubig at iwasang tumayo nang biglaan.",
    "wiz_tip_norm_bp": "🫀 Presyon ng Dugo: Normal at maayos ang iyong resulta.",
    "wiz_tip_fever": "🌡️ Temperatura: May kaunting lagnat. Magpahinga sa preskong lugar at uminom ng maraming tubig.",
    "wiz_tip_default": "💡 Paalala: Ang regular na pagpapasuri ay nakatutulong sa pagpapanatili ng mabuting kalusugan.",
    "btn_save_only": "💾 I-save ang Record Lamang",
    "btn_save_print": "🖨 I-save at I-print ang Resibo",
    "btn_next_step": "Susunod na Hakbang →",
    "btn_skip_test": "Laktawan muna ↷",
    "btn_start_screening": "🩺 Magsimula ng Pagsusuri",
    "wiz_howto": "📖  Paano gawin ang pagsusuring ito:",
    "wiz_s1_t1": "1. Tumayo nang tuwid sa platform ng kiosk.",
    "wiz_s1_t2": "2. Ituwid ang likod at tumingin nang diretso sa harap.",
    "wiz_s1_t3": "3. Pindutin ang 'Basahin ang Sensor' sa ibaba para itala ang iyong taas.",
    "wiz_s2_t1": "1. Tumayo nang hindi gumagalaw, nakapatong ang mga paa sa metal na plato.",
    "wiz_s2_t2": "2. Huwag sumandal sa mga hawakan sa gilid o gumalaw.",
    "wiz_s2_t3": "3. Pindutin ang 'Basahin ang Sensor' sa ibaba para itala ang iyong timbang.",
    "wiz_s3_t1": "1. Ilagay ang noo 3–5 cm ang layo mula sa infrared sensor.",
    "wiz_s3_t2": "2. Tanggalin ang sombrero o buhok na tumatakip sa noo.",
    "wiz_s3_t3": "3. Pindutin ang 'Basahin ang Sensor' sa ibaba para itala ang iyong temperatura.",
    "wiz_s4_t1": "1. Umupo nang komportable, nakapatong ang dalawang paa sa sahig.",
    "wiz_s4_t2": "2. Ipasok nang buo ang iyong KALIWANG braso sa automatic cuff.",
    "wiz_s4_t3": "3. Huwag gumalaw o magsalita habang napupuno ng hangin ang cuff.",
    "wiz_s5_t1": "1. Pindutin ang 'Maglabas ng Lancet' para kumuha ng sterile na lancet.",
    "wiz_s5_t2": "2. Tusukin ang daliri at ilagay ang patak ng dugo sa test strip.",
    "wiz_s5_t3": "3. Ipasok ang strip sa meter at pindutin ang 'Basahin ang Sensor'.",
    "btn_read_sensor": "🔌  Basahin ang Sensor",
    "wiz_read_fail": "Hindi nabasa — ilagay nang mano-mano.",
    "wiz_err_empty": "Maglagay ng resulta, o pindutin ang 'Laktawan muna' para laktawan.",
    "wiz_err_num": "Maglagay ng wastong numero.",
    "wiz_skipped": "(nilaktawan)",
    "btn_back_arrow": "⬅  Bumalik",
    "btn_back_menu": "⬅  Bumalik sa Menu",
    "wi_print_qr": "🖨  I-print ang QR Card",
    "wl_qr_hint": "Pinakamabilis — ipakita lang ang iyong QR card sa camera",
    "wiz_tip_pre_glucose": "🥗 Blood Sugar: Bahagyang mataas. Bawasan ang matatamis na inumin at magtanong sa Barangay Health Worker tungkol sa susunod na pagsusuri.",
    "wiz_tip_high_bp2": "🫀 Presyon ng Dugo: Mataas. Umupo at magpahinga, saka magpasuri ulit. Magpakonsulta agad sa Barangay Health Worker.",
    "wiz_disclaimer": "Mga pangkalahatang paalala lamang ito at hindi medikal na diagnosis.",
    "wi_qr_sent": "Naipadala na ang QR card sa printer.",
    "wi_qr_card_line": "Ipakita ang QR na ito sa kiosk\npara agad makapag-login.",
    "dash_cta_title": "💡  Handa na para sa iyong checkup?",
    "dash_cta_body": "Pindutin ang \"Magsimula ng Pagsusuri\" o anumang card sa ibaba para magsukat.",
    "dash_tap_measure": "👆  Pindutin para Sukatin",
    "dash_auto": "AWTO",
}
STRINGS = {"EN": EN, "FIL": FIL}

# ── MONTHS ────────────────────────────────────────────────────────────────────
MONTH_NAMES = ["January","February","March","April","May","June",
               "July","August","September","October","November","December"]

# (db_key, str_key, unit_key, icon, sensor_id)
# sensor_id: which sensor reads this field (None = manual only)
MODS = [
    ("Body Temperature", "mod_temp", "u_temp", "🌡", "temperature"),
    ("Blood Pressure",   "mod_bp",   "u_bp",   "💓", "bp"),
    ("Blood Glucose",    "mod_glu",  "u_glu",  "🩸", "glucose"),
    ("Height",           "mod_ht",   "u_ht",   "📏", "height"),
    ("Weight",           "mod_wt",   "u_wt",   "⚖",  "weight"),
    ("BMI Calculation",  "mod_bmi",  "",       "📊", None),
]
FRESH = {k: None for k, *_ in MODS}

def get_bmi_theme(bmi_value):
    """Soft pastel {bg, fg, text} theme for a BMI value/labelled-string, for gentler visual BMI status coding than plain green/gold."""
    try:
        if bmi_value is None or bmi_value == "":
            return {"bg": "#F3F4F6", "fg": "#374151", "text": "N/A"}
        raw = str(bmi_value).strip()
        num_part = raw.split()[0] if raw else raw
        bmi = float(num_part)
        if bmi < 18.5:
            return {"bg": "#FEF3C7", "fg": "#D97706", "text": "Underweight"}
        elif bmi <= 24.9:
            return {"bg": "#DCFCE7", "fg": "#15803D", "text": "Normal"}
        elif bmi <= 29.9:
            return {"bg": "#FFEDD5", "fg": "#C2410C", "text": "Overweight"}
        else:
            return {"bg": "#FEE2E2", "fg": "#B91C1C", "text": "Obese"}
    except (ValueError, IndexError):
        return {"bg": "#F3F4F6", "fg": "#374151", "text": "N/A"}

try:
    import firebase_bridge
    firebase_bridge.init(DB)     # silently stays disabled when not configured
except Exception as _e:          # bridge is optional
    firebase_bridge = None
    print(f"[bridge] not loaded: {_e}")


def format_display_name(name):
    """Standardize a resident's name for display: 'LUFFY, monkey d' or
    'luffy, MONKEY D' -> 'Luffy, Monkey D'. Title-cases every word in every
    comma-separated part so the name reads the same everywhere regardless
    of the capitalization the user originally typed it in. This is purely
    cosmetic — the raw self.user value (used as the DB key / QR payload)
    is left untouched."""
    if not name:
        return name
    parts = [p.strip() for p in name.split(",")]
    formatted = [" ".join(w.capitalize() for w in p.split() if w) for p in parts]
    return ", ".join(f for f in formatted if f)

# ── SENSOR STUB ───────────────────────────────────────────────────────────────
# Replace these functions with real hardware reads when sensors are connected.
def read_sensor(sensor_id: str):
    """Returns (value_str, error_str) — value_str is None on failure, error_str is None on success."""
    time.sleep(1.2)   # simulate read delay
    stubs = {
        "temperature": f"{random.uniform(36.0, 37.5):.1f}",
        "bp":          f"{random.randint(110,135)}/{random.randint(70,90)}",
        "glucose":     f"{random.randint(80,120)}",
        "height":      f"{random.randint(155,175)}",
        "weight":      f"{random.randint(50,80)}",
    }
    return stubs.get(sensor_id, None), None

def dispense_lancet():
    """
    Trigger the lancet dispenser hardware. Returns (True, None) on success
    or (False, error_str) on failure. This is a stub — replace the body
    with the real hardware call once the dispenser is wired up, e.g.:
        import RPi.GPIO as GPIO
        GPIO.output(LANCET_PIN, GPIO.HIGH)
        time.sleep(0.3)
        GPIO.output(LANCET_PIN, GPIO.LOW)
    or a serial/USB command, depending on what the dispenser actually is.
    """
    time.sleep(1.0)   # simulate the dispense mechanism's cycle time
    return True, None

# ── QR GENERATION ─────────────────────────────────────────────────────────────
def qr_pil(data, size=200):
    """Generate a QR code as a PIL Image (do not invert — inverted QR codes cannot be scanned)."""
    try:
        enc = cv2.QRCodeEncoder.create()
        mat = enc.encode(data)          # ndarray, 0=black 255=white
        img = Image.fromarray(mat, 'L').convert('RGB')
        return img.resize((size, size), Image.NEAREST)
    except Exception as e:
        print(f"[qr_pil] {e}")
        return Image.new('RGB', (size, size), color='white')

# ── PDF RECEIPT ───────────────────────────────────────────────────────────────
def make_pdf(name, gender, session, ts):
    fd, path = tempfile.mkstemp(suffix='.pdf')
    os.close(fd)
    cv   = rlc.Canvas(path, pagesize=A4)
    W, H = A4
    BL   = colors.HexColor

    # Ink-saving palette: pure white background throughout, black text/lines
    # only. No solid fills anywhere — everything is built from thin strokes
    # and text, kept to a consistent corner radius and rhythm for polish.
    BLACK    = BL('#000000')
    GRAY_MED = BL('#555555')
    GRAY_LT  = BL('#999999')
    R        = 4   # uniform corner radius used everywhere

    def tracked(x, y, text, font, size, color, spacing=1.3):
        """Draw text with slight letter-spacing — reads as a proper label instead of cramped small caps."""
        cv.setFont(font, size); cv.setFillColor(color)
        cx = x
        for ch in text:
            cv.drawString(cx, y, ch)
            cx += cv.stringWidth(ch, font, size) + spacing
        return cx

    def value_with_unit(x, y, value, unit, color, size_val=13, size_unit=9):
        """Bigger bold value, smaller gray unit right after it — the usual typographic trick for readouts."""
        cv.setFont('Helvetica-Bold', size_val); cv.setFillColor(color)
        cv.drawString(x, y, value)
        vw = cv.stringWidth(value, 'Helvetica-Bold', size_val)
        if unit:
            cv.setFont('Helvetica', size_unit); cv.setFillColor(GRAY_MED)
            cv.drawString(x + vw + 4, y + 1, unit)

    def ok_badge(right_x, y):
        """Small outlined pill instead of plain text — a status badge for almost no extra ink."""
        bw, bh = 22, 13
        bx = right_x - bw
        cv.setStrokeColor(BLACK); cv.setLineWidth(0.8)
        cv.roundRect(bx, y - bh + 3, bw, bh, bh/2, fill=0, stroke=1)
        cv.setFont('Helvetica-Bold', 7); cv.setFillColor(BLACK)
        cv.drawCentredString(bx + bw/2, y - bh + 3 + 4, 'OK')

    # ── Header ──────────────────────────────────────────────────────────
    cv.setStrokeColor(GRAY_LT); cv.setLineWidth(0.6)
    cv.line(28, H-30, W-28, H-30)   # top hairline — frames the masthead

    cv.setFillColor(BLACK); cv.setFont('Helvetica-Bold', 20)
    cv.drawString(28, H-52, 'SENTRO GINHAWA')
    tracked(28, H-68, 'SMART BARANGAY HEALTH KIOSK', 'Helvetica', 8, GRAY_MED, spacing=1.0)

    meta = (f'Printed {datetime.now().strftime("%b %d, %Y  %I:%M %p")}   ·   '
            f'Record date {ts}')
    cv.setFont('Helvetica', 8); cv.setFillColor(GRAY_MED)
    cv.drawRightString(W-28, H-52, meta)
    cv.setFont('Helvetica-Oblique', 9); cv.setFillColor(GRAY_MED)
    cv.drawRightString(W-28, H-66, 'Official Health Record')

    cv.setStrokeColor(BLACK); cv.setLineWidth(1.1)
    cv.line(28, H-80, W-28, H-80)

    # ── Resident info — outline only, no fill ──────────────────────────
    ry = H - 96
    cv.setStrokeColor(GRAY_LT); cv.setLineWidth(0.8)
    cv.roundRect(28, ry-66, W-56, 66, R, fill=0, stroke=1)

    tracked(44, ry-18, 'RESIDENT', 'Helvetica', 7.5, GRAY_MED, spacing=1.5)
    pdf_display_name = name.replace(", ", " ").title() if ", " in name else name.title()
    cv.setFillColor(BLACK); cv.setFont('Helvetica-Bold', 16)
    cv.drawString(44, ry-36, pdf_display_name)
    cv.setFillColor(GRAY_MED); cv.setFont('Helvetica', 10)
    cv.drawString(44, ry-52, f'Gender:  {gender}')

    # thin vertical divider before the QR block
    div_x = W - 30 - 76 - 16
    cv.setStrokeColor(GRAY_LT); cv.setLineWidth(0.6)
    cv.line(div_x, ry-58, div_x, ry-10)

    # QR — the QR itself is mostly white with sparse black modules, so it's
    # naturally light on ink already
    qr_sz = 76
    qr_x  = W - 30 - qr_sz
    qr_y  = ry - 66 + (66 - qr_sz) // 2
    try:
        qi = qr_pil(name, 150)
        qr_fd, qt = tempfile.mkstemp(suffix='.png')
        os.close(qr_fd)
        qi.save(qt); cv.drawImage(qt, qr_x, qr_y, qr_sz, qr_sz, mask='auto')
        os.unlink(qt)
    except Exception:
        pass
    cv.setFillColor(GRAY_LT); cv.setFont('Helvetica', 7)
    cv.drawCentredString(qr_x + qr_sz/2, qr_y - 9, 'Scan to log in')

    # ── Section title ───────────────────────────────────────────────────
    sy = ry - 88
    tracked(28, sy, 'HEALTH MEASUREMENTS', 'Helvetica-Bold', 10, BLACK, spacing=1.2)
    cv.setStrokeColor(GRAY_LT); cv.setLineWidth(0.8)
    cv.line(28, sy-6, W-28, sy-6)

    # ── Measurement rows — outlined table, no fill ─────────────────────
    labels = [
        ("Body Temperature","°C"),  ("Blood Pressure","mmHg"),
        ("Blood Glucose","mg/dL"),  ("Height","cm"),
        ("Weight","kg"),            ("BMI Calculation",""),
    ]
    cw, rh, gap = (W-60)/2, 48, 6
    y0 = sy - 20

    for i, (fld, unit) in enumerate(labels):
        col, row = i % 2, i // 2
        x  = 28 + col * (cw + gap)
        cy = y0 - row * (rh + gap)
        val  = session.get(fld); done = val is not None

        cv.setStrokeColor(GRAY_LT if not done else BLACK)
        cv.setLineWidth(1.0 if done else 0.6)
        cv.roundRect(x, cy-rh, cw, rh, R, fill=0, stroke=1)

        tracked(x+12, cy-16, fld.upper(), 'Helvetica', 7.5, GRAY_MED, spacing=0.8)

        if done:
            if fld == "BMI Calculation":
                cv.setFont('Helvetica-Bold', 13); cv.setFillColor(BLACK)
                cv.drawString(x+12, cy-34, str(val))
            else:
                value_with_unit(x+12, cy-34, str(val), unit, BLACK)
            ok_badge(x+cw-10, cy-14)
        else:
            cv.setFont('Helvetica', 12); cv.setFillColor(GRAY_LT)
            cv.drawString(x+12, cy-34, 'Not yet recorded')

    # ── BMI banner — outline only ───────────────────────────────────────
    bmi = session.get("BMI Calculation")
    if bmi:
        by = y0 - 3*(rh+gap) - 12
        cv.setStrokeColor(BLACK); cv.setLineWidth(1.0)
        cv.roundRect(28, by-26, W-56, 26, R, fill=0, stroke=1)
        tracked(38, by-11, 'BMI RESULT', 'Helvetica', 7.5, GRAY_MED, spacing=0.8)
        cv.setFillColor(BLACK); cv.setFont('Helvetica-Bold', 11)
        cv.drawString(38, by-22, str(bmi))

    # ── Footer — hairline + centered text, mirrors the header frame ────
    cv.setStrokeColor(GRAY_LT); cv.setLineWidth(0.6)
    cv.line(28, 36, W-28, 36)
    cv.setFillColor(GRAY_MED); cv.setFont('Helvetica', 8)
    cv.drawCentredString(W/2, 24,
        'This is a computer-generated health summary. '
        'For medical concerns, consult a licensed healthcare professional.')
    cv.drawCentredString(W/2, 13, 'Sentro Ginhawa  •  Smart Barangay Health Kiosk')

    cv.save(); return path

def open_pdf(p):
    if sys.platform == 'win32':    os.startfile(p)
    elif sys.platform == 'darwin': subprocess.Popen(['open', p])
    else:                          subprocess.Popen(['xdg-open', p])

# ── EMAIL SENDER ──────────────────────────────────────────────────────────────
def send_email_report(to_addr, name, gender, session, ts):
    """Build a PDF health report and email it to to_addr; returns (True, None) or (False, error_string)."""
    if not EMAIL_SENDER or not EMAIL_PASSWORD:
        return False, "not_configured"
    pdf_path = None
    try:
        pdf_path = make_pdf(name, gender, session, ts)

        msg = MIMEMultipart()
        msg["From"]    = EMAIL_SENDER
        msg["To"]      = to_addr
        msg["Subject"] = f"Sentro Ginhawa — Health Record for {name}"

        body = (
            f"Magandang araw / Good day, {name}!\n\n"
            f"Attached is your health record from the Sentro Ginhawa kiosk,\n"
            f"recorded on {ts}.\n\n"
            f"Please consult a healthcare professional if any of your readings\n"
            f"are outside the normal range.\n\n"
            f"— Sentro Ginhawa Smart Barangay Health Kiosk"
        )
        msg.attach(MIMEText(body, "plain"))

        with open(pdf_path, "rb") as f:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(f.read())
        encoders.encode_base64(part)
        part.add_header("Content-Disposition",
                        f'attachment; filename="HealthRecord_{name.replace(" ","_")}.pdf"')
        msg.attach(part)

        ctx = ssl.create_default_context()
        with smtplib.SMTP_SSL(EMAIL_SMTP, EMAIL_PORT, context=ctx) as srv:
            srv.login(EMAIL_SENDER, EMAIL_PASSWORD)
            srv.sendmail(EMAIL_SENDER, to_addr, msg.as_string())

        return True, None
    except Exception as e:
        return False, str(e)
    finally:
        if pdf_path:
            try:
                os.unlink(pdf_path)
            except Exception:
                pass

# ── MAIN APP ──────────────────────────────────────────────────────────────────
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sentro Ginhawa — Smart Barangay Health Kiosk")
        # ── Kiosk fullscreen ─────────────────────────────────────────────
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        self.geometry(f"{sw}x{sh}+0+0")
        self.resizable(False, False)
        self.attributes('-fullscreen', True)       # true fullscreen on all platforms
        self.bind('<Escape>', lambda e: None)       # block accidental fullscreen exit
        self.protocol("WM_DELETE_WINDOW", lambda: None)  # disable OS close button
        # Scale factor relative to 1100×690 baseline.
        # Floor of 0.85 prevents buttons from becoming too small to tap on
        # small RPi screens (7" 800×480 would otherwise give SF ≈ 0.70).
        self.SF = max(0.85, min(sw / 1100, sh / 690))
        self.SW = sw
        self.SH = sh
        self.configure(bg=C["bg"])
        self.lang = "EN"; self.user = ""; self.gender = ""; self.email = ""
        self.update_mode = False; self.session = dict(FRESH)
        self._qr_run = False; self._qr_cap = None; self._cam_lbl = None
        self._screen = "welcome"
        self._init_keyboard()
        self._init_idle_watch()
        self.show_welcome()

    # ── Idle auto-logout ─────────────────────────────────────────────────────
    # Screens where nobody is logged in / no sensitive data is showing yet —
    # the idle timer never needs to act while on one of these.
    _PUBLIC_SCREENS = ("welcome", "login", "qr_login", "register")

    def _init_idle_watch(self):
        self._idle_after_id = None
        # bind_all fires for events anywhere in the app, including Toplevel
        # popups, so activity inside a dialog also resets the timer.
        self.bind_all("<Motion>",     self._reset_idle_timer, add="+")
        self.bind_all("<ButtonPress>", self._reset_idle_timer, add="+")
        self.bind_all("<Key>",        self._reset_idle_timer, add="+")
        self._reset_idle_timer()

    def _reset_idle_timer(self, event=None):
        if self._idle_after_id is not None:
            try: self.after_cancel(self._idle_after_id)
            except Exception: pass
        self._idle_after_id = self.after(IDLE_LOGOUT_SECONDS * 1000, self._on_idle_timeout)

    def _on_idle_timeout(self):
        # Only kick back to welcome if there's actually something sensitive
        # on screen — no point resetting an already-public screen.
        if self._screen not in self._PUBLIC_SCREENS:
            self.show_welcome()
            self._alert("info", self.s("idle_logout_msg"),
                         title=self.s("idle_logout_title"))
        else:
            self._reset_idle_timer()

    # ── Custom phone-style on-screen keyboard ─────────────────────────────────
    # Light whitish-gray theme — soft, neutral, and easy to read on a
    # touchscreen kiosk without competing with the app's navy/blue chrome.
    _KB_BG   = "#e4e8ed"   # panel background — soft whitish gray
    _KB_KEY  = "#ffffff"   # standard letter/number key — white, clearly
                            # lifted off the panel so keys stay easy to spot
    _KB_SPEC = "#cbd3db"   # special / modifier keys (shift, backspace,
                            # mode, space, punctuation) — light-medium gray
                            # so they stand out from plain letter keys
    _KB_SHIFT_ON = C["gld"]  # shift-active highlight — matches the app's
                              # "editing" accent color used elsewhere
    _KB_BLUE = C["grn"]    # Done button — green, matching Save/confirm
                            # buttons used throughout the rest of the kiosk
    _KB_FG      = "#1e293b"  # dark slate text — readable on the light keys
    _KB_FG_ON_ACCENT = "#ffffff"  # white text for the green/amber keys

    # Key rows as plain data — edit these strings to change the actual
    # layout without touching any of the drawing/positioning logic below.
    # Row 3 (letters) and the bottom row are built separately since they
    # mix in the Shift/Backspace/space/Done keys, not just characters.
    _KB_ROW1_LETTERS = "qwertyuiop"
    _KB_ROW2_LETTERS = "asdfghjkl"
    _KB_ROW3_LETTERS = "zxcvbnm"
    _KB_SYM1_ROW1 = "1234567890"
    _KB_SYM1_ROW2 = "-/:;()₱&@\""
    _KB_SYM2_ROW1 = "[]{}#%^*+="
    _KB_SYM2_ROW2 = "_\\|~<>$€£•"
    _KB_SYM_ROW3  = ".,?!'"

    def _init_keyboard(self):
        self._kb_win    = None
        self._kb_target = None
        self._kb_shift  = False
        self._kb_mode   = "letters"   # "letters" | "sym1" | "sym2"
        self.bind_class("Entry", "<FocusIn>", self._kb_on_focus, add="+")
        self.bind_all("<Button-1>", self._kb_check_outside_click, add="+")

    def _kb_on_focus(self, e):
        w = e.widget
        try:
            if str(w.cget("state")) == "disabled":
                return
        except Exception:
            pass
        self._kb_target = w
        self._show_keyboard()

    def _kb_check_outside_click(self, event):
        if self._kb_win is None:
            return
        w = event.widget
        if w is self._kb_target:
            return
        if isinstance(w, tk.Entry):
            return
        try:
            if w.winfo_toplevel() is self._kb_win:
                return
        except Exception:
            pass
        self._hide_keyboard()

    def _hide_keyboard(self):
        if self._kb_win is not None:
            try: self._kb_win.destroy()
            except Exception: pass
            self._kb_win = None
        # Move focus off the Entry so it doesn't immediately re-trigger
        try: self.focus_set()
        except Exception: pass

    def _find_ancestor_canvas(self, w):
        """Walk up from `w` looking for a Canvas ancestor (i.e. the field
        lives inside one of the app's scrollable form panels)."""
        p = w
        while p is not None:
            if isinstance(p, tk.Canvas):
                return p
            p = getattr(p, "master", None)
        return None

    def _kb_scroll_entry_into_view(self, entry, kb_top):
        """If `entry` sits inside a scrollable form panel, scroll that
        panel so the field clears the keyboard — the form moves up to
        meet the keyboard instead of the keyboard covering the field,
        same behaviour as most phone/kiosk keyboards. Returns True if it
        handled (or didn't need) scrolling, False if there's no
        scrollable ancestor to work with."""
        cv = self._find_ancestor_canvas(entry)
        if cv is None:
            return False
        try:
            gap = self.sc(18)
            entry_bottom = entry.winfo_rooty() + entry.winfo_height()
            overlap = (entry_bottom + gap) - kb_top
            if overlap <= 0:
                return True   # already clear of the keyboard, nothing to do

            bbox = cv.bbox("all")
            if not bbox:
                return True
            total_h = max(1, bbox[3] - bbox[1])
            visible_h = max(1, cv.winfo_height())
            top_frac  = cv.yview()[0]
            new_top   = min(top_frac * total_h + overlap,
                             max(0, total_h - visible_h))
            cv.yview_moveto(new_top / total_h)
            return True
        except Exception:
            return True

    def _show_keyboard(self):
        if self._kb_win is not None:
            self._kb_win.lift()
            return
        kb = tk.Toplevel(self)
        kb.overrideredirect(True)
        kb.attributes("-topmost", True)
        kb.configure(bg=self._KB_BG)
        # Moderate, screen-proportional height — big enough to be an easy
        # touch target, but not so tall it eats the whole screen.
        kh = max(self.sc(210), min(self.sc(270), int(self.SH * 0.30)))
        ky = self.SH - kh   # default: anchored to screen bottom

        if self._kb_target:
            try:
                # First choice: if the field lives in a scrollable form,
                # scroll the form itself so the field clears the keyboard.
                handled = self._kb_scroll_entry_into_view(self._kb_target, ky)
                if not handled:
                    # Fallback for non-scrollable dialogs/popups: slide the
                    # keyboard up so it doesn't sit on top of the field.
                    ey  = self._kb_target.winfo_rooty()   # entry top (screen-absolute)
                    eh  = self._kb_target.winfo_height()
                    gap = self.sc(16)
                    # Keyboard occupies [ky .. ky+kh].
                    # Entry is covered when its bottom edge is below the keyboard top.
                    if ey + eh > ky:
                        ky_above = ey - gap - kh
                        if ky_above >= 0:
                            ky = ky_above          # fits above — use it
                        # else: no room above either; keep keyboard at the bottom.
            except Exception:
                pass

        kb.geometry(f"{self.SW}x{kh}+0+{ky}")
        self._kb_win   = kb
        self._kb_shift = False
        self._kb_mode  = "letters"
        self._kb_body  = tk.Frame(kb, bg=self._KB_BG)
        self._kb_body.pack(fill="both", expand=True,
                           padx=self.sc(5), pady=self.sc(7))
        self._kb_render()

    # ── keyboard internals ────────────────────────────────────────────────────

    @staticmethod
    def _kb_flash(color):
        """Shift a hex color for press-feedback: darken light keys, lighten dark ones, so the tap flash is always visible."""
        r, g, b = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
        luma = (r * 299 + g * 587 + b * 114) / 1000
        if luma > 150:
            r, g, b = max(0, r - 35), max(0, g - 35), max(0, b - 35)
        else:
            r, g, b = min(255, r + 55), min(255, g + 55), min(255, b + 55)
        return f"#{r:02x}{g:02x}{b:02x}"

    def _kb_btn(self, parent, label, cmd, bg=None, fg=None,
                font_size=13, expand=False, ipadx=0):
        """Make one keyboard key with press-flash feedback."""
        bg = bg or self._KB_KEY
        fg = fg or self._KB_FG
        hi = self._kb_flash(bg)
        b  = tk.Button(parent, text=label, command=cmd,
                       font=("Helvetica", self.sf(font_size), "bold"),
                       bg=bg, fg=fg, relief="flat", bd=0, height=2,
                       highlightbackground="#b8c2cc", highlightthickness=1,
                       activebackground=hi, activeforeground=fg,
                       cursor="hand2", takefocus=0)
        b.bind("<ButtonPress-1>",   lambda e: b.configure(bg=hi))
        b.bind("<ButtonRelease-1>", lambda e: b.configure(bg=bg))
        b.pack(side="left", fill="x", expand=expand, padx=2,
               ipadx=self.sc(ipadx) if ipadx else 0)
        return b

    def _kb_char_row(self, chars, fn, stagger=False):
        """Pack a row of equal-width character keys that fill the full row."""
        rf = tk.Frame(self._kb_body, bg=self._KB_BG)
        rf.pack(fill="x", pady=2)
        if stagger:
            tk.Frame(rf, bg=self._KB_BG, width=self.sc(22)).pack(side="left")
        for ch in chars:
            self._kb_btn(rf, ch, lambda c=ch: fn(c), expand=True)
        if stagger:
            tk.Frame(rf, bg=self._KB_BG, width=self.sc(22)).pack(side="left")

    def _kb_type(self, ch):
        w = self._kb_target
        if not w:
            return
        try:
            w.insert(tk.INSERT, ch)
            w.focus_set()
            # Auto-release shift after one letter (phone-style)
            if self._kb_shift and ch.isalpha():
                self._kb_shift = False
                self._kb_render()
        except Exception:
            pass

    def _kb_backspace(self):
        w = self._kb_target
        if not w:
            return
        try:
            i = w.index(tk.INSERT)
            if i > 0:
                w.delete(i - 1, i)
            w.focus_set()
        except Exception:
            pass

    def _kb_case(self, c):
        return c.upper() if self._kb_shift else c

    def _kb_toggle_shift(self):
        self._kb_shift = not self._kb_shift
        self._kb_render()

    def _kb_set_mode(self, mode):
        self._kb_mode = mode
        self._kb_render()

    def _kb_render(self):
        """Redraws all rows for the current page and shift state."""
        for w in self._kb_body.winfo_children():
            w.destroy()
        BD = self._kb_body

        if self._kb_mode == "letters":
            # ── Row 1: Q W E R T Y U I O P ───────────────────────────────
            self._kb_char_row(
                [self._kb_case(c) for c in self._KB_ROW1_LETTERS],
                lambda c: self._kb_type(c)
            )
            # ── Row 2: A S D F G H J K L (staggered) ─────────────────────
            self._kb_char_row(
                [self._kb_case(c) for c in self._KB_ROW2_LETTERS],
                lambda c: self._kb_type(c),
                stagger=True
            )
            # ── Row 3: ⇧  Z X C V B N M  ⌫ ───────────────────────────────
            # Letters stay the same width as rows 1–2; Shift and Backspace
            # are visibly wider bookends (via ipadx) that soak up the extra
            # row width instead — the classic phone-keyboard row 3 look.
            r3 = tk.Frame(BD, bg=self._KB_BG); r3.pack(fill="x", pady=2)
            self._kb_btn(r3, "⇧", self._kb_toggle_shift,
                         bg=self._KB_SHIFT_ON if self._kb_shift else self._KB_SPEC,
                         fg=self._KB_FG_ON_ACCENT if self._kb_shift else self._KB_FG,
                         font_size=15, expand=True, ipadx=8)
            for ch in self._KB_ROW3_LETTERS:
                self._kb_btn(r3, self._kb_case(ch),
                             lambda c=ch: self._kb_type(self._kb_case(c)),
                             expand=True)
            self._kb_btn(r3, "⌫", self._kb_backspace,
                         bg=self._KB_SPEC, font_size=15, expand=True, ipadx=8)

        else:
            # ── Symbol pages ──────────────────────────────────────────────
            if self._kb_mode == "sym1":
                r1, r2 = self._KB_SYM1_ROW1, self._KB_SYM1_ROW2
            else:
                r1, r2 = self._KB_SYM2_ROW1, self._KB_SYM2_ROW2

            self._kb_char_row(list(r1), lambda c: self._kb_type(c))
            self._kb_char_row(list(r2), lambda c: self._kb_type(c))

            # ── Row 3: [page-toggle]  . , ? ! '  [⌫] ────────────────────
            r3 = tk.Frame(BD, bg=self._KB_BG); r3.pack(fill="x", pady=2)
            if self._kb_mode == "sym1":
                self._kb_btn(r3, "#+=", lambda: self._kb_set_mode("sym2"),
                             bg=self._KB_SPEC, font_size=11, expand=True, ipadx=8)
            else:
                self._kb_btn(r3, "123", lambda: self._kb_set_mode("sym1"),
                             bg=self._KB_SPEC, font_size=11, expand=True, ipadx=8)
            for ch in self._KB_SYM_ROW3:
                self._kb_btn(r3, ch, lambda c=ch: self._kb_type(c), expand=True)
            self._kb_btn(r3, "⌫", self._kb_backspace,
                         bg=self._KB_SPEC, font_size=15, expand=True, ipadx=8)

        # ── Bottom row (same for all pages) ──────────────────────────────
        # The space bar is the dominant key here, like a real phone
        # keyboard — it's the only one with expand=True, so it soaks up
        # all the leftover row width. The toggle and Done keys stay a
        # fixed, comfortable tap size instead of stretching to match it.
        br = tk.Frame(BD, bg=self._KB_BG); br.pack(fill="x", pady=(2, 0))
        if self._kb_mode == "letters":
            self._kb_btn(br, "?123", lambda: self._kb_set_mode("sym1"),
                         bg=self._KB_SPEC, font_size=11, ipadx=8)
        else:
            self._kb_btn(br, "ABC", lambda: self._kb_set_mode("letters"),
                         bg=self._KB_SPEC, font_size=11, ipadx=8)
        self._kb_btn(br, ",", lambda: self._kb_type(","),
                     bg=self._KB_SPEC)
        self._kb_btn(br, "space", lambda: self._kb_type(" "),
                     bg=self._KB_SPEC, expand=True)
        self._kb_btn(br, ".", lambda: self._kb_type("."),
                     bg=self._KB_SPEC)
        self._kb_btn(br, "Done ✓", self._hide_keyboard,
                     bg=self._KB_BLUE, fg=self._KB_FG_ON_ACCENT,
                     font_size=11, ipadx=12)

    def _ask_string(self, title, prompt, initial=""):
        """Touch-friendly replacement for tkinter.simpledialog.askstring."""
        result = {"value": None}
        pop = self._popup(title, 460, 240)
        tk.Frame(pop, bg=C["acc"], height=self.sc(6)).pack(fill="x")
        body = tk.Frame(pop, bg=C["bg"]); body.pack(expand=True, fill="both",
                                                      padx=self.sc(28), pady=self.sc(20))
        self.lbl(body, prompt, 12, bg=C["bg"], color=C["sub"],
                 wraplength=self.sc(390)).pack(anchor="w", pady=(0, self.sc(10)))
        ent = self.entry(body)
        ent.insert(0, initial)
        ent.pack(fill="x", ipady=self.sc(10), ipadx=self.sc(8))
        ent.focus_set()

        def ok():
            result["value"] = ent.get().strip()
            pop.destroy()

        def cancel():
            result["value"] = None
            pop.destroy()

        btnrow = tk.Frame(body, bg=C["bg"]); btnrow.pack(fill="x", pady=(self.sc(18), 0))
        self.btn(btnrow, "OK", ok, bg=C["grn"], size=12).pack(side="left", padx=(0, self.sc(8)))
        self.btn(btnrow, "Cancel", cancel, bg=C["surface"], fg=C["sub"], size=12).pack(side="left")
        ent.bind("<Return>", lambda e: ok())
        pop.protocol("WM_DELETE_WINDOW", cancel)
        pop.wait_window()
        self._hide_keyboard()
        return result["value"]

    # ── Scale helpers ─────────────────────────────────────────────────────────
    def sc(self, v):
        """Scale an integer pixel value by the screen scale factor."""
        return max(1, int(round(v * self.SF)))

    def sf(self, size):
        """Scale a font size. Minimum 9 to stay legible on small screens."""
        return max(9, int(round(size * self.SF)))

    def _popup(self, _title, w=480, h=300):
        """Centred dialog inside the main window instead of a Toplevel, since Toplevels can lose focus on a fullscreen kiosk."""
        # `_title` is accepted (and always passed by every caller) purely so
        # each call site still documents what the dialog is for, even
        # though there's no real OS window/titlebar to display it in.
        # Clamp to the actual window size (minus a small margin) so a
        # dialog can never extend past the visible screen — a fixed
        # logical size like 560x520 can otherwise exceed a small screen's
        # real dimensions once scaled, pushing it off top/bottom/edges.
        margin = self.sc(24)
        pw = min(self.sc(w), max(self.SW - margin, self.sc(240)))
        ph = min(self.sc(h), max(self.SH - margin, self.sc(160)))

        # A bordered card placed directly on the main window — no full-screen
        # backdrop behind it, so the rest of the screen stays exactly as it
        # was (an earlier version dimmed the whole window here, which on a
        # kiosk-sized display just looked like everything had gone black).
        dialog = tk.Frame(self, bg=C["bg"],
                          highlightbackground=C["acc"], highlightthickness=2)
        dialog.place(relx=.5, rely=.5, anchor="center", width=pw, height=ph)
        dialog.lift()

        # Calling code treats the return value like the old Toplevel: it
        # packs widgets into it and calls .destroy() / .wait_window() /
        # .protocol() on it. .destroy() and .wait_window() already work
        # correctly since this is a real widget; .protocol() no longer
        # means anything without a real OS window/close button, so it's
        # shimmed to a no-op so existing call sites don't break.
        dialog.protocol = lambda *a, **kw: None
        return dialog

    # ── Custom alert / confirm dialogs ──────────────────────────────────────
    # These replace tkinter.messagebox so every dialog in the kiosk matches
    # the app's own styling and touch-sized buttons instead of the small,
    # OS-themed popups messagebox produces.
    def _alert(self, kind, message, title=None):
        """Blocking info/warning/error dialog styled to match the kiosk UI."""
        icon_map  = {"info": "ℹ", "warning": "⚠", "error": "✕"}
        color_map = {"info": C["acc"], "warning": C["gld"], "error": C["red"]}
        title_map = {"info": "Notice", "warning": "Warning", "error": "Error"}
        color = color_map.get(kind, C["acc"])
        title = title or title_map.get(kind, "Notice")

        pop = self._popup(title, 420, 230)
        tk.Frame(pop, bg=color, height=self.sc(6)).pack(fill="x")
        body = tk.Frame(pop, bg=C["bg"])
        body.pack(expand=True, fill="both", padx=self.sc(26), pady=self.sc(20))

        head = tk.Frame(body, bg=C["bg"]); head.pack(fill="x")
        tk.Label(head, text=icon_map.get(kind, "ℹ"),
                 font=("Helvetica", self.sf(22), "bold"),
                 bg=C["bg"], fg=color).pack(side="left", padx=(0, self.sc(12)))
        tk.Label(head, text=title, font=("Helvetica", self.sf(15), "bold"),
                 bg=C["bg"], fg=C["txt"]).pack(side="left")

        self.lbl(body, message, 12, bg=C["bg"], color=C["sub"],
                 wraplength=self.sc(360), justify="left"
                 ).pack(anchor="w", pady=(self.sc(14), self.sc(18)))

        self.btn(body, "OK", pop.destroy, bg=color, size=12,
                 padx=self.sc(26), pady=self.sc(7)).pack()
        pop.protocol("WM_DELETE_WINDOW", pop.destroy)
        pop.wait_window()

    def _confirm(self, title, message, default_yes=False, danger=True):
        """Blocking Yes/No dialog matching the kiosk UI; danger=True (default) shows a red Yes for destructive actions."""
        result = {"value": default_yes}
        pop = self._popup(title or "Please Confirm", 440, 250)
        tk.Frame(pop, bg=C["gld"], height=self.sc(6)).pack(fill="x")
        body = tk.Frame(pop, bg=C["bg"])
        body.pack(expand=True, fill="both", padx=self.sc(26), pady=self.sc(20))

        head = tk.Frame(body, bg=C["bg"]); head.pack(fill="x")
        tk.Label(head, text="❓", font=("Helvetica", self.sf(20), "bold"),
                 bg=C["bg"], fg=C["gld"]).pack(side="left", padx=(0, self.sc(12)))
        if title:
            tk.Label(head, text=title, font=("Helvetica", self.sf(14), "bold"),
                     bg=C["bg"], fg=C["txt"]).pack(side="left")

        self.lbl(body, message, 12, bg=C["bg"], color=C["sub"],
                 wraplength=self.sc(380), justify="left"
                 ).pack(anchor="w", pady=(self.sc(14), self.sc(18)))

        def yes(): result["value"] = True;  pop.destroy()
        def no():  result["value"] = False; pop.destroy()

        row = tk.Frame(body, bg=C["bg"]); row.pack()
        self.btn(row, "Yes", yes, bg=C["red"] if danger else C["grn"], size=12,
                 padx=self.sc(22), pady=self.sc(7)).pack(side="left", padx=(0, self.sc(10)))
        self.btn(row, "No", no, bg=C["surface"], fg=C["sub"], size=12,
                 padx=self.sc(22), pady=self.sc(7)).pack(side="left")
        pop.protocol("WM_DELETE_WINDOW", no)
        pop.wait_window()
        return result["value"]

    # Small braille-pattern spinner frames — plain Unicode, not emoji, so
    # they render even on systems without a color emoji font (see the
    # emoji font check at startup).
    _SPINNER_FRAMES = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"]

    def _start_spinner(self, label, base_text, interval=90):
        """Animate a small spinner on `label` for in-progress feedback; returns a stop() function."""
        state = {"i": 0, "running": True}

        def tick():
            if not state["running"]:
                return
            try:
                if not label.winfo_exists():
                    return
            except Exception:
                return
            frame = self._SPINNER_FRAMES[state["i"] % len(self._SPINNER_FRAMES)]
            label.configure(text=f"{frame}  {base_text}")
            state["i"] += 1
            label.after(interval, tick)

        tick()
        def stop():
            state["running"] = False
        return stop

    def _bind_scroll_recursive(self, widget, canvas):
        """
        Bind drag/wheel-scroll handlers on `widget` and every descendant so
        touch-dragging or scrolling anywhere within a scrollable panel's
        content actually scrolls `canvas` — Tkinter does NOT propagate
        these events from a child widget up to an ancestor on its own, so
        without this, only a touch landing on bare, unoccupied canvas
        background would ever scroll (everything else is covered by
        Labels/Frames that swallow the event). On a touchscreen kiosk with
        no mouse wheel, that left no way to scroll at all in practice.
        add="+" everywhere so existing click handlers (e.g. a toggle's own
        tap-to-expand) keep working alongside this.
        """
        widget.bind("<ButtonPress-1>", lambda e: canvas.scan_mark(e.x, e.y), add="+")
        widget.bind("<B1-Motion>",     lambda e: canvas.scan_dragto(e.x, e.y, gain=1), add="+")
        widget.bind("<MouseWheel>",    lambda e: canvas.yview_scroll(int(-e.delta/120), "units"), add="+")
        widget.bind("<Button-4>",      lambda e: canvas.yview_scroll(-1, "units"), add="+")
        widget.bind("<Button-5>",      lambda e: canvas.yview_scroll(1,  "units"), add="+")
        for child in widget.winfo_children():
            self._bind_scroll_recursive(child, canvas)

    # ── Helpers ───────────────────────────────────────────────────────────────
    def s(self, k): return STRINGS[self.lang].get(k, k)

    def clr(self):
        self._qr_run = False
        if self._qr_cap: self._qr_cap.release(); self._qr_cap = None
        self._hide_keyboard()
        for w in self.winfo_children(): w.destroy()

    def _nav_bar(self):
        """Thin accent bar that sweeps across the top on every screen change."""
        bar = tk.Frame(self, bg=C["acc"], height=3)
        bar.place(x=0, y=0, width=0, height=3)
        bar.lift()
        self._nav_bar_step(bar, 0)

    def _nav_bar_step(self, bar, step):
        total = 18
        if step > total:
            try: bar.destroy()
            except Exception: pass
            return
        w = int(self.SW * step / total)
        try:
            bar.place(x=0, y=0, width=w, height=3)
            self.after(12, lambda: self._nav_bar_step(bar, step + 1))
        except Exception:
            pass

    @staticmethod
    def _dim(h):
        r = h.lstrip('#')
        r,g,b = int(r[0:2],16), int(r[2:4],16), int(r[4:6],16)
        return f'#{max(0,r-22):02x}{max(0,g-22):02x}{max(0,b-22):02x}'

    def lbl(self, p, text, size=13, bold=False, color=None, bg=None, **kw):
        return tk.Label(p, text=text,
                        font=("Helvetica", self.sf(size), "bold" if bold else "normal"),
                        bg=bg or C["surface"], fg=color or C["txt"], **kw)

    def btn(self, p, text, cmd, bg=None, fg="white", size=13, **kw):
        bg = bg or C["acc"]
        # Ensure minimum tap-target padding so buttons stay clickable on
        # small touchscreens regardless of SF.
        kw['padx'] = max(kw.get('padx', self.sc(10)), self.sc(8))
        kw['pady'] = max(kw.get('pady', self.sc(6)),  self.sc(5))
        b  = tk.Button(p, text=text, command=cmd,
                       font=("Helvetica", self.sf(size), "bold"),
                       bg=bg, fg=fg, relief="flat", bd=0,
                       activebackground=self._dim(bg), activeforeground=fg,
                       cursor="hand2", **kw)
        b.bind("<Enter>", lambda e: b.configure(bg=self._dim(bg)))
        b.bind("<Leave>", lambda e: b.configure(bg=bg))
        b.bind("<ButtonPress-1>", lambda e: b.configure(bg=self._dim(bg)))
        b.bind("<ButtonRelease-1>", lambda e: b.configure(bg=bg))
        return b

    def entry(self, p, **kw):
        return tk.Entry(p, font=("Helvetica", self.sf(14)), bg=C["s2"], fg=C["txt"],
                        relief="flat", bd=0, insertbackground=C["acc"], **kw)

    def divider(self, p, color=None, h=1, pady=(0, 8)):
        tk.Frame(p, bg=color or C["div"], height=h).pack(fill="x", pady=pady)

    def card(self, parent, accent=None, px=260, py=32, scrollable=False):
        if scrollable:
            outer = self._scroll_container(parent, bg=C["bg"])
            frame = tk.Frame(outer, bg=C["surface"],
                             highlightbackground=C["bdr"], highlightthickness=1)
            frame.pack(padx=self.sc(px), pady=self.sc(py), fill="x")
        else:
            outer = tk.Frame(parent, bg=C["bg"]); outer.pack(expand=True, fill="both")
            frame = tk.Frame(outer, bg=C["surface"],
                             highlightbackground=C["bdr"], highlightthickness=1)
            frame.pack(expand=True, padx=self.sc(px), pady=self.sc(py), fill="both")
        tk.Frame(frame, bg=accent or C["acc"], height=self.sc(6)).pack(fill="x")
        inner = tk.Frame(frame, bg=C["surface"]); inner.pack(padx=self.sc(46), pady=self.sc(30), fill="x")
        return inner

    def _scroll_container(self, parent, bg=None):
        """Generic scrollable region inside `parent` — pack content into the returned inner frame."""
        bg = bg or C["bg"]
        wrap = tk.Frame(parent, bg=bg)
        wrap.pack(expand=True, fill="both")

        canvas = tk.Canvas(wrap, bg=bg, highlightthickness=0)
        vsb    = tk.Scrollbar(wrap, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        outer  = tk.Frame(canvas, bg=bg)
        win_id = canvas.create_window((0, 0), window=outer, anchor="nw")

        def _on_frame(e):
            canvas.configure(scrollregion=canvas.bbox("all"))
            self._bind_scroll_recursive(outer, canvas)
        def _on_canvas(e): canvas.itemconfig(win_id, width=e.width)
        outer.bind("<Configure>",   _on_frame)
        canvas.bind("<Configure>",  _on_canvas)

        canvas.bind("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta / 120), "units"))
        canvas.bind("<Button-4>",   lambda e: canvas.yview_scroll(-1, "units"))
        canvas.bind("<Button-5>",   lambda e: canvas.yview_scroll(1,  "units"))
        canvas.bind("<ButtonPress-1>", lambda e: canvas.scan_mark(e.x, e.y))
        canvas.bind("<B1-Motion>",     lambda e: canvas.scan_dragto(e.x, e.y, gain=1))

        inner = tk.Frame(outer, bg=bg)
        inner.pack(padx=self.sc(20), pady=self.sc(16), fill="x")
        return inner

    def header(self, show_user=False, show_update=False, show_print=False):
        bar = tk.Frame(self, bg=C["hdr"], height=max(self.sc(66), 56))
        bar.pack(fill="x"); bar.pack_propagate(False)
        # Brand — triple-click opens admin login
        bl = tk.Frame(bar, bg=C["hdr"]); bl.pack(side="left", padx=(self.sc(18), 0))
        brand = tk.Label(bl, text="SENTRO GINHAWA", font=("Helvetica", self.sf(18), "bold"),
                         bg=C["hdr"], fg="white")
        brand.pack(side="left")
        brand.bind("<Triple-Button-1>", lambda e: self._admin_login())
        tk.Label(bl, text="   Smart Barangay Health Kiosk",
                 font=("Helvetica", self.sf(11)), bg=C["hdr"], fg="#93c5fd").pack(side="left")
        # Buttons
        R = tk.Frame(bar, bg=C["hdr"]); R.pack(side="right", padx=14)
        def hbtn(text, cmd, bg):
            b = tk.Button(R, text=text, command=cmd, font=("Helvetica", self.sf(11), "bold"),
                          bg=bg, fg="white", relief="flat", bd=0,
                          padx=max(self.sc(12), 10), pady=max(self.sc(5), 6),
                          cursor="hand2", activebackground=self._dim(bg),
                          activeforeground="white")
            b.bind("<Enter>", lambda e: b.configure(bg=self._dim(bg)))
            b.bind("<Leave>", lambda e: b.configure(bg=bg))
            b.pack(side="left", padx=3)
        hbtn(self.s("lang"), self.toggle_lang, C["hdr2"])
        if show_update:
            hbtn(self.s("b_cancel" if self.update_mode else "b_update"),
                 self._toggle_update, C["red"] if self.update_mode else C["grn"])
        if show_print:
            hbtn(self.s("b_print"), self._do_print, C["gld"])
            hbtn(self.s("b_email"), self._do_email, C["acc"])
        if show_user:
            hbtn(self.s("b_logout"), self.show_welcome, C["hdr2"])
        hbtn(self.s("b_exit"), sys.exit, "#991b1b")
        tk.Frame(self, bg=C["gld"], height=3).pack(fill="x")

    def toggle_lang(self):
        self.lang = "FIL" if self.lang == "EN" else "EN"
        getattr(self, f"show_{self._screen}")()

    # ── DB ────────────────────────────────────────────────────────────────────
    def db_load(self):
        with sqlite3.connect(DB) as c:
            cur = c.cursor()
            cur.execute('SELECT temp,bp,glucose,height,weight,bmi FROM health_records '
                        'WHERE name=? ORDER BY timestamp DESC LIMIT 1', (self.user,))
            row = cur.fetchone()
        keys = [m[0] for m in MODS]
        self.session = {k: (v or None) for k, v in zip(keys, row)} if row else dict(FRESH)

    def db_ts(self):
        with sqlite3.connect(DB) as c:
            cur = c.cursor()
            cur.execute('SELECT timestamp FROM health_records WHERE name=? '
                        'ORDER BY timestamp DESC LIMIT 1', (self.user,))
            row = cur.fetchone()
        return row[0] if row else None

    def calc_bmi(self):
        try:
            h = float(self.session["Height"]) / 100
            w = float(self.session["Weight"])
            b = w / (h * h)
            lbl = (self.s("under") if b < 18.5 else self.s("norm") if b < 25
                   else self.s("over") if b < 30 else self.s("obese"))
            self.session["BMI Calculation"] = f"{b:.1f}  ({lbl})"
        except Exception:
            self.session["BMI Calculation"] = None

    # ── QR scanner ────────────────────────────────────────────────────────────
    def _qr_start(self):
        self._qr_run = True
        threading.Thread(target=self._qr_loop, daemon=True).start()

    def _qr_loop(self):
        # Try camera indices 0-3 to find a working camera
        cap = None
        for idx in range(4):
            cap = cv2.VideoCapture(idx)
            if cap.isOpened():
                break
            cap.release()
            cap = None

        if cap is None:
            self.after(0, lambda: [self._alert("error", self.s("e_cam")),
                                    self.show_login()])
            return

        self._qr_cap = cap
        det  = cv2.QRCodeDetector()
        skip = 0

        while self._qr_run:
            ret, frame = self._qr_cap.read()
            if not ret:
                continue

            # ── QR detection on the raw (un-flipped) frame ────────────────
            # IMPORTANT: do NOT flip before detection — mirroring breaks QR.
            # Detect on the original color frame (BGR) for best accuracy.
            try:
                data, points, _ = det.detectAndDecode(frame)
            except Exception:
                data, points = "", None

            # ── Camera preview (unmirrored, with bounding box) ────────────
            skip += 1
            if skip % 2 == 0:   # update preview every 2nd frame
                try:
                    display = frame.copy()   # no flip — show as-is
                    # Draw bounding box around QR code if detected
                    if points is not None and len(points) > 0:
                        pts = points[0].astype(int)
                        for j in range(len(pts)):
                            pt1 = tuple(pts[j])
                            pt2 = tuple(pts[(j + 1) % len(pts)])
                            cv2.line(display, pt1, pt2, (0, 200, 80), 3)
                        # Corner dots
                        for pt in pts:
                            cv2.circle(display, tuple(pt), 6, (0, 200, 80), -1)
                        # Label above box
                        x_min = int(pts[:, 0].min())
                        y_min = int(pts[:, 1].min()) - 10
                        cv2.putText(display, "QR Detected", (x_min, max(y_min, 20)),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 200, 80), 2,
                                    cv2.LINE_AA)
                    rgb     = cv2.cvtColor(display, cv2.COLOR_BGR2RGB)
                    w       = getattr(self, "_cam_w", 560)
                    h       = getattr(self, "_cam_h", 380)
                    img     = Image.fromarray(rgb).resize((w, h), Image.BILINEAR)
                    photo   = ImageTk.PhotoImage(img)

                    def _show(p=photo):
                        try:
                            if self._cam_lbl and self._cam_lbl.winfo_exists():
                                self._cam_lbl.configure(image=p)
                                self._cam_lbl.image = p
                        except Exception:
                            pass

                    self.after(0, _show)
                except Exception:
                    pass

            # ── QR found → log in ─────────────────────────────────────────
            if data and data.strip():
                self._qr_run = False
                self._qr_cap.release()
                self._qr_cap = None
                name = data.strip()
                self.after(0, lambda n=name: self._qr_login(n))
                return

        if self._qr_cap:
            self._qr_cap.release()
            self._qr_cap = None

    def _qr_login(self, data):
        with sqlite3.connect(DB) as c:
            cur = c.cursor()
            cur.execute("SELECT gender, email, name FROM residents WHERE name=? COLLATE NOCASE",
                        (data.strip(),))
            row = cur.fetchone()
            if not row and firebase_bridge and firebase_bridge.enabled():
                # Resident registered in the mobile app: create the local row on first scan
                info = firebase_bridge.pull_resident(data.strip())
                if info:
                    c.execute("INSERT INTO residents (name,age,gender,email,birthdate) VALUES (?,?,?,?,?)",
                              (info["name"], info["age"], info["gender"], info["email"], info["birthdate"]))
                    row = (info["gender"], info["email"], info["name"])
        if row:
            def proceed():
                self.user, self.gender, self.email = row[2], row[0], (row[1] or "")
                # ── FIX: always start with a blank session on login ──
                self.session = dict(FRESH)
                self.show_dashboard()
            self._show_tnc(proceed)
        else:
            self._alert("error", self.s("qr_fail")); self.show_login()

    # ── TERMS & CONDITIONS ────────────────────────────────────────────────────
    def _show_tnc(self, on_agree):
        """Show a scrollable T&C popup; calls on_agree() on Agree, does nothing on Decline."""
        pop = self._popup(self.s("tnc_title"), 620, 520)

        # Header stripe
        tk.Frame(pop, bg=C["acc"], height=self.sc(6)).pack(fill="x")

        header = tk.Frame(pop, bg=C["hdr"]); header.pack(fill="x")
        tk.Label(header, text=self.s("tnc_title"),
                 font=("Helvetica", self.sf(15), "bold"),
                 bg=C["hdr"], fg="white").pack(side="left", padx=self.sc(20), pady=self.sc(10))
        tk.Label(header, text=self.s("tnc_sub"),
                 font=("Helvetica", self.sf(10)),
                 bg=C["hdr"], fg="#93c5fd").pack(side="left", padx=(0, self.sc(10)))

        # Scrollable text body
        body = tk.Frame(pop, bg=C["bg"]); body.pack(expand=True, fill="both",
                        padx=self.sc(18), pady=(self.sc(12), self.sc(8)))

        txt_frame = tk.Frame(body, bg=C["surface"],
                             highlightbackground=C["bdr"], highlightthickness=1)
        txt_frame.pack(expand=True, fill="both")

        vsb = tk.Scrollbar(txt_frame, orient="vertical")
        vsb.pack(side="right", fill="y")

        txt = tk.Text(txt_frame, wrap="word", font=("Helvetica", self.sf(10)),
                      bg=C["surface"], fg=C["txt"], relief="flat", bd=0,
                      padx=self.sc(16), pady=self.sc(12),
                      yscrollcommand=vsb.set, state="normal", cursor="arrow")
        txt.pack(expand=True, fill="both")
        vsb.config(command=txt.yview)

        txt.insert("1.0", self.s("tnc_body"))
        txt.config(state="disabled")   # read-only

        # Button row
        btn_row = tk.Frame(pop, bg=C["bg"]); btn_row.pack(fill="x",
                           padx=self.sc(18), pady=(0, self.sc(14)))

        def agree():
            pop.destroy()
            on_agree()

        self.btn(btn_row, self.s("tnc_agree"), agree,
                 bg=C["grn"], size=13,
                 padx=self.sc(20), pady=self.sc(8)).pack(side="left", padx=(0, self.sc(10)))
        self.btn(btn_row, self.s("tnc_decline"), pop.destroy,
                 bg=C["surface"], fg=C["red"], size=12,
                 padx=self.sc(14), pady=self.sc(8)).pack(side="left")

    # ── SCREEN: WELCOME ───────────────────────────────────────────────────────
    def show_welcome(self):
        self._screen = "welcome"
        self.clr()
        self.update_mode = False
        self.session = dict(FRESH)

        # ── Redesigned welcome dashboard (rounded card layout) ───────────
        import math
        import numpy as np
        import tkinter.font as tkfont
        from PIL import ImageDraw, ImageFilter

        W, H = self.SW, self.SH
        F = "Helvetica"
        NAVY = "#12305f"; BLUE = C["acc"]; GRAY = "#64748b"; LINE = "#c9d8ee"
        imgs = []; self._wl_imgs = imgs          # keep PhotoImage refs alive

        def t(en, fil):
            return fil if self.lang == "FIL" else en

        def rgb(h, a=255):
            h = h.lstrip("#")
            return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)

        def photo(im):
            p = ImageTk.PhotoImage(im); imgs.append(p); return p

        def rr(w, h, r, fill, outline=None, ow=1):
            """Anti-aliased rounded rectangle (RGBA)."""
            w, h = max(2, int(w)), max(2, int(h)); ss = 3
            im = Image.new("RGBA", (w * ss, h * ss), tuple(fill[:3]) + (0,))
            ImageDraw.Draw(im).rounded_rectangle(
                [0, 0, w * ss - 1, h * ss - 1], radius=int(r * ss),
                fill=fill, outline=outline, width=ow * ss)
            return im.resize((w, h), Image.LANCZOS)

        def icon(kind, size, color, lw=0.09):
            """Small anti-aliased line icons (no emoji font needed)."""
            size = max(8, int(size)); ss = 4; S = size * ss
            c = rgb(color)[:3]; col = c + (255,)
            im = Image.new("RGBA", (S, S), c + (0,)); d = ImageDraw.Draw(im)
            w = max(2, int(S * lw))
            P = lambda x, y: (x * S, y * S)
            if kind == "globe":
                d.ellipse([S*.08, S*.08, S*.92, S*.92], outline=col, width=w)
                d.ellipse([S*.32, S*.08, S*.68, S*.92], outline=col, width=w)
                d.line([P(.08, .5), P(.92, .5)], fill=col, width=w)
            elif kind == "exit":
                d.line([P(.45, .12), P(.12, .12), P(.12, .88), P(.45, .88)],
                       fill=col, width=w, joint="curve")
                d.line([P(.35, .5), P(.88, .5)], fill=col, width=w)
                d.line([P(.66, .28), P(.88, .5), P(.66, .72)],
                       fill=col, width=w, joint="curve")
            elif kind == "qr":
                for cx, cy, sx, sy in ((.14, .14, 1, 1), (.86, .14, -1, 1),
                                       (.14, .86, 1, -1), (.86, .86, -1, -1)):
                    d.line([P(cx + sx*.26, cy), P(cx, cy), P(cx, cy + sy*.26)],
                           fill=col, width=w, joint="curve")
                d.rectangle([P(.38, .38), P(.62, .62)], fill=col)
            elif kind == "chevron":
                d.line([P(.32, .15), P(.68, .5), P(.32, .85)],
                       fill=col, width=w, joint="curve")
            elif kind == "shield":
                pts = [P(.5, .06), P(.88, .2), P(.88, .5), P(.5, .95),
                       P(.12, .5), P(.12, .2)]
                d.line(pts + [pts[0]], fill=col, width=w, joint="curve")
                d.line([P(.32, .5), P(.46, .64), P(.70, .36)],
                       fill=col, width=w, joint="curve")
            elif kind == "heart":
                pts = []
                for i in range(0, 361, 3):
                    a = math.radians(i)
                    x = 16 * math.sin(a) ** 3
                    y = (13*math.cos(a) - 5*math.cos(2*a)
                         - 2*math.cos(3*a) - math.cos(4*a))
                    pts.append((S * (0.5 + x / 38), S * (0.47 - y / 38)))
                d.line(pts, fill=col, width=w, joint="curve")
                d.line([P(.2, .5), P(.38, .5), P(.46, .3), P(.56, .68),
                        P(.63, .5), P(.8, .5)], fill=col, width=w, joint="curve")
            return im.resize((size, size), Image.LANCZOS)

        def gradient(w, h, c1, c2):
            yy = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
            xx = np.linspace(0, 1, w, dtype=np.float32)[None, :, None]
            tt = np.clip(0.65 * yy + 0.35 * xx, 0, 1)
            a = np.array(c1, np.float32); b = np.array(c2, np.float32)
            return Image.fromarray((a * (1 - tt) + b * tt).astype(np.uint8), "RGB")

        cv = tk.Canvas(self, width=W, height=H, highlightthickness=0, bd=0, bg="#e6eef9")
        cv.pack(expand=True, fill="both")

        # ── Page background ──────────────────────────────────────────────
        cv.create_image(0, 0, anchor="nw",
                        image=photo(gradient(W, H, (243, 247, 253), (210, 224, 243))))

        # ── Geometry ─────────────────────────────────────────────────────
        m = self.sc(34); barH = self.sc(80)
        x0, x1 = m, W - m
        y0, y1 = barH, H - self.sc(30)
        cw, ch = x1 - x0, y1 - y0
        R = self.sc(26)
        lw = int(cw * 0.42)

        # ── Card shadow + white card ─────────────────────────────────────
        pad = self.sc(30)
        sh = Image.new("RGBA", (cw + pad * 2, ch + pad * 2), (18, 48, 95, 0))
        ImageDraw.Draw(sh).rounded_rectangle(
            [pad, pad, pad + cw, pad + ch], radius=R, fill=(18, 48, 95, 70))
        sh = sh.filter(ImageFilter.GaussianBlur(self.sc(14)))
        cv.create_image(x0 - pad, y0 - pad + self.sc(8), anchor="nw", image=photo(sh))
        cv.create_image(x0, y0, anchor="nw",
                        image=photo(rr(cw, ch, R, (255, 255, 255, 255))))

        # ── Left branding panel (gradient + rings + badge + glass card) ──
        cx, cy = lw // 2, int(ch * 0.34)
        r = int(min(lw * 0.15, ch * 0.11))
        gh = self.sc(92); gx0 = int(lw * 0.07); gx1 = lw - gx0
        gy1 = ch - self.sc(28); gy0 = gy1 - gh

        yy, xx = np.mgrid[0:ch, 0:lw].astype(np.float32)
        tv = (yy / ch)[..., None]
        base = (np.array([22, 68, 128], np.float32) * (1 - tv)
                + np.array([10, 38, 84], np.float32) * tv)
        glow = (np.clip(1 - np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / (lw * .8), 0, 1) ** 2
                * 0.55)[..., None]
        base = base * (1 - glow) + np.array([60, 124, 204], np.float32) * glow
        panel = Image.fromarray(base.astype(np.uint8), "RGB").convert("RGBA")

        ss = 3
        ov = Image.new("RGBA", (lw * ss, ch * ss), (255, 255, 255, 0))
        od = ImageDraw.Draw(ov)
        for mult, al in ((1.9, 46), (3.0, 32), (4.2, 20)):
            rad = r * mult * ss
            od.ellipse([cx*ss - rad, cy*ss - rad, cx*ss + rad, cy*ss + rad],
                       outline=(255, 255, 255, al), width=2 * ss)
        od.ellipse([(cx - r) * ss, (cy - r) * ss, (cx + r) * ss, (cy + r) * ss],
                   fill=(255, 255, 255, 255))
        od.rounded_rectangle([gx0 * ss, gy0 * ss, gx1 * ss, gy1 * ss], radius=self.sc(16) * ss,
                             fill=(255, 255, 255, 36), outline=(255, 255, 255, 80), width=ss)
        panel.alpha_composite(ov.resize((lw, ch), Image.LANCZOS))
        hi = int(r * 1.15)
        panel.alpha_composite(icon("heart", hi, "#dc2626", lw=0.08), (cx - hi // 2, cy - hi // 2))

        mask = Image.new("L", (lw * ss, ch * ss), 0)
        ImageDraw.Draw(mask).rounded_rectangle(
            [0, 0, lw * ss + R * 2 * ss, ch * ss - 1], radius=R * ss, fill=255)
        panel.putalpha(mask.resize((lw, ch), Image.LANCZOS))
        cv.create_image(x0, y0, anchor="nw", image=photo(panel))
        cv.create_rectangle(x0 + lw, y0, x0 + lw + 3, y1, fill="#f59e0b", width=0)

        cv.create_text(x0 + cx, y0 + cy + r + self.sc(34), text="Sentro Ginhawa",
                       font=(F, self.sf(19), "bold"), fill="white")
        cv.create_text(x0 + cx, y0 + cy + r + self.sc(62), text=self.s("wsub"),
                       font=(F, self.sf(10), "bold"), fill="#8ec5ff",
                       width=lw - self.sc(40), justify="center")
        gtx = x0 + gx0 + self.sc(16); gtw = gx1 - gx0 - self.sc(32)
        sI = self.sc(13)
        cv.create_image(gtx, y0 + gy0 + self.sc(14), anchor="nw",
                        image=photo(icon("shield", sI, "#fbbf24", lw=0.1)))
        cv.create_text(gtx + sI + self.sc(6), y0 + gy0 + self.sc(14) + sI // 2, anchor="w",
                       text="Libreng serbisyong pangkalusugan",
                       font=(F, self.sf(9), "bold"), fill="#fbbf24", width=gtw - sI)
        cv.create_text(gtx, y0 + gy0 + self.sc(38), anchor="nw",
                       text="Kalusugan, mas malapit sa iyo.",
                       font=(F, self.sf(13), "bold"), fill="white", width=gtw)
        cv.create_text(gtx, y0 + gy0 + self.sc(64), anchor="nw",
                       text=t("No appointment needed", "Walang kailangang appointment"),
                       font=(F, self.sf(9)), fill="#b7d3f5", width=gtw)

        # ── Top bar ──────────────────────────────────────────────────────
        bc = int(barH * 0.5)
        ts = self.sc(42)
        tile = rr(ts, ts, self.sc(12), (255, 255, 255, 255), outline=(214, 224, 240, 255))
        cv.create_image(x0, bc - ts // 2, anchor="nw", image=photo(tile), tags="brand")
        hs = int(ts * 0.62)
        cv.create_image(x0 + (ts - hs) // 2, bc - hs // 2, anchor="nw",
                        image=photo(icon("heart", hs, "#dc2626", lw=0.08)), tags="brand")
        bx = x0 + ts + self.sc(10)
        cv.create_text(bx, bc - self.sc(2), anchor="sw", text="Sentro Ginhawa",
                       font=(F, self.sf(12), "bold"), fill=NAVY, tags="brand")
        cv.create_text(bx, bc, anchor="nw", text=self.s("wsub"),
                       font=(F, self.sf(9)), fill=GRAY, tags="brand")
        cv.tag_bind("brand", "<Triple-Button-1>", lambda e: self._admin_login())

        def hit(tag, img_id, normal, press, cmd):
            def down(e):  cv.itemconfig(img_id, image=press)
            def leave(e): cv.itemconfig(img_id, image=normal)
            def up(e):
                cv.itemconfig(img_id, image=normal); cmd()
            cv.tag_bind(tag, "<Enter>", down);  cv.tag_bind(tag, "<Leave>", leave)
            cv.tag_bind(tag, "<ButtonPress-1>", down)
            cv.tag_bind(tag, "<ButtonRelease-1>", up)

        # Centre nav pill
        nf = tkfont.Font(family=F, size=self.sf(10), weight="bold")
        tabs = [(t("Welcome", "Pagbati"), None),
                (t("Register", "Mag-rehistro"), self.show_register),
                ("Admin", self._admin_login)]
        tpad = self.sc(16); th_ = self.sc(34); pp = self.sc(5)
        tws = [nf.measure(n) + tpad * 2 for n, _ in tabs]
        pw = sum(tws) + pp * 2; ph = th_ + pp * 2
        px = (W - pw) // 2
        cv.create_image(px, bc - ph // 2, anchor="nw",
                        image=photo(rr(pw, ph, ph // 2, (255, 255, 255, 215),
                                       outline=(214, 224, 240, 255))))
        tx = px + pp
        for i, ((name, cmd), tw_) in enumerate(zip(tabs, tws)):
            ty = bc - th_ // 2
            if cmd is None:
                cv.create_image(tx, ty, anchor="nw", image=photo(rr(tw_, th_, th_ // 2, rgb(NAVY))))
                cv.create_text(tx + tw_ // 2, bc, text=name, font=nf, fill="white")
            else:
                n_ = photo(rr(tw_, th_, th_ // 2, (255, 255, 255, 0)))
                p_ = photo(rr(tw_, th_, th_ // 2, rgb("#e6eef9")))
                iid = cv.create_image(tx, ty, anchor="nw", image=n_, tags=f"tab{i}")
                cv.create_text(tx + tw_ // 2, bc, text=name, font=nf, fill="#475569", tags=f"tab{i}")
                hit(f"tab{i}", iid, n_, p_, cmd)
            tx += tw_

        # Right-side pills (language + exit)
        def pill(right, label, ic, fill, outline, fg, press_fill, cmd, tag):
            ph2 = self.sc(36); isz = self.sc(15); gap = self.sc(8); pd = self.sc(14)
            tw2 = nf.measure(label); w_ = pd * 2 + isz + gap + tw2
            left = right - w_; top = bc - ph2 // 2
            n_ = photo(rr(w_, ph2, ph2 // 2, rgb(fill), outline=rgb(outline)))
            p_ = photo(rr(w_, ph2, ph2 // 2, rgb(press_fill), outline=rgb(outline)))
            iid = cv.create_image(left, top, anchor="nw", image=n_, tags=tag)
            cv.create_image(left + pd, bc - isz // 2, anchor="nw",
                            image=photo(icon(ic, isz, fg)), tags=tag)
            cv.create_text(left + pd + isz + gap, bc, anchor="w", text=label,
                           font=nf, fill=fg, tags=tag)
            hit(tag, iid, n_, p_, cmd)
            return left

        lft = pill(x1, self.s("b_exit"), "exit", "#fde8e8", "#f6c6c6", "#b91c1c",
                   "#fbd0d0", sys.exit, "pexit")
        pill(lft - self.sc(10), self.s("lang"), "globe", "#ffffff", "#cfdcee", NAVY,
             "#e6eef9", self.toggle_lang, "plang")

        # ── Right content (rebuilt smaller if the screen is short) ───────
        rx0 = x0 + lw + 3
        rw = x1 - rx0
        colw = min(int(rw * 0.80), self.sc(540))
        cx0 = rx0 + (rw - colw) // 2

        def build_right(k):
            y = 0
            def txt(x, yy_, text, size, bold=False, fill=NAVY, anchor="nw", tags=("rc",), **kw):
                return cv.create_text(x, yy_, text=text, anchor=anchor,
                                      font=(F, self.sf(size * k), "bold" if bold else "normal"),
                                      fill=fill, tags=tags, **kw)
            i = txt(cx0, y, t("WELCOME TO SENTRO GINHAWA", "MALIGAYANG PAGDATING SA SENTRO GINHAWA"),
                    9, True, BLUE, width=colw)
            y = cv.bbox(i)[3] + self.sc(12 * k)
            i = txt(cx0, y, t("Your health journey\nstarts here.", "Simula na ng iyong\nhealth journey."),
                    30, True, NAVY, width=colw)
            y = cv.bbox(i)[3] + self.sc(12 * k)
            i = txt(cx0, y, t("Check your vital signs, understand your results, and connect with "
                              "your barangay health center\u2014all in a few guided steps.",
                              "Suriin ang iyong vital signs, unawain ang resulta, at kumonekta sa "
                              "health center ng barangay\u2014sa ilang gabay na hakbang lang."),
                    11, False, "#52627a", width=colw)
            y = cv.bbox(i)[3] + self.sc(24 * k)

            # Primary: Scan QR
            bh = max(self.sc(60), int(self.sc(70) * k))
            n_ = photo(rr(colw, bh, self.sc(14), rgb(BLUE)))
            p_ = photo(rr(colw, bh, self.sc(14), rgb(self._dim(BLUE))))
            iid = cv.create_image(cx0, y, anchor="nw", image=n_, tags=("rc", "bqr"))
            tsz = int(bh * 0.6)
            cv.create_image(cx0 + self.sc(14), y + (bh - tsz) // 2, anchor="nw",
                            image=photo(rr(tsz, tsz, self.sc(10), (255, 255, 255, 40))),
                            tags=("rc", "bqr"))
            isz = int(tsz * 0.58)
            cv.create_image(cx0 + self.sc(14) + (tsz - isz) // 2, y + (bh - isz) // 2, anchor="nw",
                            image=photo(icon("qr", isz, "#ffffff", lw=0.08)), tags=("rc", "bqr"))
            tx_ = cx0 + self.sc(14) + tsz + self.sc(14)
            chs = self.sc(14)
            twid = colw - (tx_ - cx0) - chs - self.sc(26)
            txt(tx_, y + bh // 2 + self.sc(2), t("Scan your QR code", "I-scan ang iyong QR code"),
                13, True, "white", "sw", ("rc", "bqr"), width=twid)
            txt(tx_, y + bh // 2 + self.sc(4), t("Fastest way to access your health record",
                                                 "Pinakamabilis na access sa iyong health record"),
                9, False, "#dbeafe", "nw", ("rc", "bqr"), width=twid)
            cv.create_image(cx0 + colw - chs - self.sc(18), y + (bh - chs) // 2, anchor="nw",
                            image=photo(icon("chevron", chs, "#ffffff", lw=0.12)), tags=("rc", "bqr"))
            hit("bqr", iid, n_, p_, lambda: self.show_qr_login(back=self.show_welcome))
            y += bh + self.sc(12 * k)

            # Secondary: existing account
            bh2 = max(self.sc(48), int(self.sc(54) * k))
            n_ = photo(rr(colw, bh2, self.sc(14), (255, 255, 255, 255), outline=rgb("#c3d3ea"), ow=2))
            p_ = photo(rr(colw, bh2, self.sc(14), rgb(C["acc_lt"]), outline=rgb("#c3d3ea"), ow=2))
            iid = cv.create_image(cx0, y, anchor="nw", image=n_, tags=("rc", "bex"))
            txt(cx0 + colw // 2, y + bh2 // 2,
                t("I already have an account", "Mayroon na akong account") + "  \u203a",
                12, True, NAVY, "center", ("rc", "bex"))
            hit("bex", iid, n_, p_, self.show_login)
            y += bh2 + self.sc(20 * k)

            # Register link
            reg = txt(cx0 + colw // 2, y, t("Register as a new resident", "Mag-rehistro bilang bagong residente"),
                      11, True, GRAY, "n", ("rc", "breg"))
            cv.tag_bind("breg", "<Enter>", lambda e: cv.itemconfig(reg, fill=BLUE))
            cv.tag_bind("breg", "<Leave>", lambda e: cv.itemconfig(reg, fill=GRAY))
            cv.tag_bind("breg", "<ButtonRelease-1>", lambda e: self.show_register())
            y = cv.bbox(reg)[3] + self.sc(28 * k)

            # Health worker access
            hf = tkfont.Font(family=F, size=self.sf(9 * k), weight="bold")
            label = t("Health worker access", "Pag-access ng health worker")
            hs_ = self.sc(13); gap = self.sc(6)
            total = hs_ + gap + hf.measure(label)
            sx = cx0 + (colw - total) // 2
            cv.create_image(sx, y, anchor="nw", image=photo(icon("shield", hs_, BLUE, lw=0.1)),
                            tags=("rc", "bhw"))
            cv.create_text(sx + hs_ + gap, y + hs_ // 2, anchor="w", text=label, font=hf,
                           fill=BLUE, tags=("rc", "bhw"))
            cv.tag_bind("bhw", "<ButtonRelease-1>", lambda e: self._admin_login())

        k = 1.0
        for _ in range(4):
            build_right(k)
            bb = cv.bbox("rc")
            if (bb[3] - bb[1]) <= ch - self.sc(40) or k < 0.6:
                break
            cv.delete("rc"); k *= 0.88
        bb = cv.bbox("rc")
        cv.move("rc", 0, y0 + (ch - (bb[3] - bb[1])) // 2 - bb[1])

        self._nav_bar()

    # ── SCREEN: LOGIN ─────────────────────────────────────────────────────────
    def show_login(self, mode=None):
        """Modern split-panel resident login inspired by the approved mockup."""
        self._screen = "login"
        self.clr()
        self._login_mode = mode or getattr(self, "_login_mode", "name")

        # Palette intentionally scoped to this screen so other screens remain unchanged.
        page = "#eaf1fb"
        navy = "#123765"
        navy_dark = "#0d2b50"
        blue = "#2162ad"
        pale = "#f4f8fe"
        line = "#d6e2f2"
        muted = "#6b7f9b"
        white = "#ffffff"

        self.configure(bg=page)
        top = tk.Frame(self, bg=page, height=self.sc(58))
        top.pack(fill="x", padx=self.sc(22), pady=(self.sc(8), self.sc(4)))
        top.pack_propagate(False)

        brand = tk.Frame(top, bg=page)
        brand.pack(side="left", fill="y")
        # Draw a crisp outline heart in a fixed-size canvas instead of a font glyph,
        # which can look different across Windows fonts and resolutions.
        brand_mark = tk.Canvas(brand, width=self.sc(38), height=self.sc(38),
                               bg=white, highlightthickness=0)
        brand_mark.pack(side="left", padx=(0, self.sc(8)))
        heart_pts = [self.sc(v) for v in (19, 29, 10, 21, 5, 15, 5, 10, 9, 6,
                                          14, 6, 19, 12, 24, 6, 32, 6, 33, 13,
                                          30, 19, 19, 32)]
        brand_mark.create_line(*heart_pts, fill="#ff4058", width=max(2, self.sc(2)),
                               smooth=True, splinesteps=18, capstyle="round", joinstyle="round")
        brand_text = tk.Frame(brand, bg=page)
        brand_text.pack(side="left", anchor="center")
        tk.Label(brand_text, text="Sentro Ginhawa", font=("Helvetica", self.sf(12), "bold"),
                 fg=navy, bg=page).pack(anchor="w")
        tk.Label(brand_text, text="Smart Barangay Health Kiosk", font=("Helvetica", self.sf(8)),
                 fg=muted, bg=page).pack(anchor="w")

        nav = tk.Frame(top, bg=white, highlightbackground=line, highlightthickness=1)
        nav.pack(side="left", expand=True, padx=self.sc(45), pady=self.sc(3))
        for label, active in (("Welcome", False), ("Log in", True), ("Register", False)):
            tk.Button(nav, text=label, command=(self.show_welcome if label == "Welcome" else
                     (lambda: self.show_register()) if label == "Register" else lambda: None),
                     font=("Helvetica", self.sf(9), "bold" if active else "normal"),
                     bg=navy if active else white, fg=white if active else navy,
                     relief="flat", bd=0, cursor="hand2", padx=self.sc(15), pady=self.sc(5)
                     ).pack(side="left", padx=self.sc(2), pady=self.sc(2))

        right_top = tk.Frame(top, bg=page)
        right_top.pack(side="right")
        tk.Button(right_top, text=self.s("lang"), command=self.toggle_lang,
                  font=("Helvetica", self.sf(9)), bg=white, fg=navy,
                  relief="flat", bd=0, cursor="hand2", padx=self.sc(10), pady=self.sc(6)
                  ).pack(side="left", padx=(0, self.sc(8)))
        tk.Button(right_top, text=self.s("b_exit"), command=sys.exit,
                  font=("Helvetica", self.sf(9)), bg="#fff5f5", fg="#dc2626",
                  relief="flat", bd=0, cursor="hand2", padx=self.sc(10), pady=self.sc(6)
                  ).pack(side="left")

        # Main white card with a navy information panel and a clean login form.
        outer = tk.Frame(self, bg=white, highlightbackground="#dbe5f2", highlightthickness=0)
        outer.pack(fill="both", expand=True, padx=self.sc(22), pady=(0, self.sc(16)))
        outer.grid_rowconfigure(0, weight=1)
        outer.grid_columnconfigure(0, weight=40, uniform="login")
        outer.grid_columnconfigure(1, weight=60, uniform="login")

        left = tk.Frame(outer, bg=navy)
        left.grid(row=0, column=0, sticky="nsew")
        # Responsive logo artwork: redraw using the actual canvas size so the
        # rings and heart stay centered at different window sizes/resolutions.
        art = tk.Canvas(left, bg=navy, highlightthickness=0, bd=0)
        art.place(relx=0.5, rely=0.43, anchor="center", relwidth=0.98, relheight=0.70)

        def draw_login_art(event=None):
            art.delete("all")
            width = max(1, art.winfo_width())
            height = max(1, art.winfo_height())
            cx, cy = width / 2, height / 2
            radius = min(width * 0.43, height * 0.43)
            for factor, color in ((1.00, "#244b7b"), (0.72, "#2b5688"), (0.45, "#356293")):
                r = radius * factor
                art.create_oval(cx-r, cy-r, cx+r, cy+r, outline=color, width=1)

            # White circular badge with a clean, centered red heart.
            badge_r = max(26, radius * 0.34)
            art.create_oval(cx-badge_r, cy-badge_r, cx+badge_r, cy+badge_r,
                            fill=white, outline=white)
            # Heart outline in normalized coordinates; scale proportionally.
            scale = badge_r / 42
            points = [(-23, -3), (-23, -11), (-18, -17), (-11, -18),
                      (-5, -15), (0, -8), (5, -15), (12, -18),
                      (19, -15), (23, -9), (23, -2), (19, 5),
                      (12, 13), (0, 25), (-12, 13), (-19, 5), (-23, -3)]
            coords = []
            for x, y in points:
                coords.extend((cx + x * scale, cy + y * scale))
            art.create_line(*coords, fill="#ff4058", width=max(2, int(scale * 4)),
                            smooth=True, splinesteps=24, capstyle="round", joinstyle="round")

        art.bind("<Configure>", draw_login_art)

        tk.Label(left, text="Sentro Ginhawa", font=("Helvetica", self.sf(18), "bold"),
                 fg=white, bg=navy).place(relx=0.5, rely=0.69, anchor="center")
        tk.Label(left, text="Smart Barangay Health Kiosk", font=("Helvetica", self.sf(9)),
                 fg="#d7e7ff", bg=navy).place(relx=0.5, rely=0.735, anchor="center")
        note = tk.Frame(left, bg="#24466f", highlightbackground="#46658b", highlightthickness=1)
        note.place(relx=0.05, rely=0.88, relwidth=0.90, anchor="nw")
        tk.Label(note, text="✦  " + ("Libreng serbisyong pangkalusugan" if self.lang == "FIL" else "Community health for everyone"),
                 font=("Helvetica", self.sf(9), "bold"), fg="#fde68a", bg="#24466f").pack(anchor="w", padx=self.sc(12), pady=(self.sc(8), 2))
        tk.Label(note, text=("Kalusugan, mas malapit sa iyo." if self.lang == "FIL" else "Your health, closer to home."),
                 font=("Helvetica", self.sf(10), "bold"), fg=white, bg="#24466f").pack(anchor="w", padx=self.sc(12))
        tk.Label(note, text=self.s("wtag"), font=("Helvetica", self.sf(8)), fg="#d7e7ff",
                 bg="#24466f").pack(anchor="w", padx=self.sc(12), pady=(2, self.sc(8)))

        right = tk.Frame(outer, bg=white)
        right.grid(row=0, column=1, sticky="nsew", padx=self.sc(62), pady=self.sc(34))
        right.grid_columnconfigure(0, weight=1)
        tk.Label(right, text="WELCOME BACK", font=("Helvetica", self.sf(8), "bold"),
                 fg=blue, bg=white).grid(row=0, column=0, sticky="w", pady=(self.sc(4), self.sc(5)))
        tk.Label(right, text=self.s("ltitle"), font=("Helvetica", self.sf(25), "bold"),
                 fg=navy_dark, bg=white).grid(row=1, column=0, sticky="w")
        hint_key = "lhint" if self._login_mode == "name" else "lhint_email"
        tk.Label(right, text=("Enter your registered details to securely access your health record." if self.lang == "EN" else self.s(hint_key)),
                 font=("Helvetica", self.sf(9)), fg=muted, bg=white, wraplength=self.sc(450),
                 justify="left").grid(row=2, column=0, sticky="w", pady=(self.sc(5), self.sc(18)))

        tabs = tk.Frame(right, bg="#edf3fb")
        tabs.grid(row=3, column=0, sticky="ew", pady=(0, self.sc(10)))
        tabs.grid_columnconfigure((0, 1), weight=1)
        for i, (label, m) in enumerate((("By Name", "name"), ("By Email", "email"))):
            active = self._login_mode == m
            tk.Button(tabs, text=label, command=lambda mm=m: self.show_login(mode=mm),
                      font=("Helvetica", self.sf(9), "bold" if active else "normal"),
                      bg=white if active else "#edf3fb", fg=blue if active else muted,
                      relief="flat", bd=0, cursor="hand2", pady=self.sc(7)
                      ).grid(row=0, column=i, sticky="ew", padx=self.sc(2), pady=self.sc(2))

        def field_label(text, optional=False):
            label = text + (" (optional)" if optional else "")
            return label

        def entry_field(row, label, optional=False):
            tk.Label(right, text=field_label(label, optional), font=("Helvetica", self.sf(9), "bold"),
                     fg=navy_dark, bg=white).grid(row=row, column=0, sticky="w", pady=(self.sc(5), self.sc(3)))
            wrap = tk.Frame(right, bg=line, padx=1, pady=1)
            wrap.grid(row=row+1, column=0, sticky="ew", pady=(0, self.sc(4)))
            ent = tk.Entry(wrap, font=("Helvetica", self.sf(11)), bg=pale, fg="#94a3b8",
                           relief="flat", bd=0, insertbackground=blue)
            ent.pack(fill="x", ipady=self.sc(8), padx=self.sc(8), pady=self.sc(1))
            ent.bind("<FocusIn>", lambda e, w=wrap: w.configure(bg=blue))
            ent.bind("<FocusOut>", lambda e, w=wrap: w.configure(bg=line))
            return ent

        if self._login_mode == "name":
            # Paired name fields retain the existing login validation and database logic.
            namebox = tk.Frame(right, bg=white)
            namebox.grid(row=4, column=0, sticky="ew")
            namebox.grid_columnconfigure((0, 1), weight=1, uniform="names")
            def name_input(parent, label, col):
                tk.Label(parent, text=label, font=("Helvetica", self.sf(9), "bold"),
                         fg=navy_dark, bg=white).grid(row=0, column=col, sticky="w", pady=(self.sc(4), self.sc(3)))
                wrap = tk.Frame(parent, bg=line, padx=0, pady=0)
                wrap.grid(row=1, column=col, sticky="ew", padx=(0 if col == 0 else self.sc(8), 0), pady=(0, self.sc(4)))
                ent = tk.Entry(wrap, font=("Helvetica", self.sf(10)), bg=pale, fg=navy_dark,
                               relief="flat", bd=0, insertbackground=blue)
                ent.pack(fill="x", ipady=self.sc(8), padx=self.sc(8), pady=self.sc(1))
                ent.bind("<FocusIn>", lambda e, w=wrap: w.configure(bg=blue))
                ent.bind("<FocusOut>", lambda e, w=wrap: w.configure(bg=line))
                return ent
            self._ll = name_input(namebox, self.s("l_login_last"), 0)
            self._lf = name_input(namebox, self.s("l_login_first"), 1)
            self._lm = entry_field(6, self.s("l_login_mid"), optional=True)
            self._ll.bind("<Return>", lambda e: self._lf.focus())
            self._lf.bind("<Return>", lambda e: self._lm.focus())
            self._lm.bind("<Return>", lambda e: self._do_login())
            login_cmd = self._do_login
            self._ll.focus()
        else:
            self._le = entry_field(4, self.s("l_login_email"))
            ph_email = self.s("lph_email")
            self._le.insert(0, ph_email)
            self._le.bind("<FocusIn>", lambda e: (self._le.delete(0, "end"), self._le.config(fg=navy_dark)) if self._le.get() == ph_email else None)
            self._le.bind("<Return>", lambda e: self._do_login_email())
            login_cmd = self._do_login_email
            self._le.focus()

        button_row = tk.Frame(right, bg=white)
        button_row.grid(row=9 if self._login_mode == "name" else 7, column=0, sticky="ew", pady=(self.sc(10), self.sc(8)))
        button_row.grid_columnconfigure(0, weight=1)
        tk.Button(button_row, text=self.s("b_login"), command=login_cmd,
                  font=("Helvetica", self.sf(10), "bold"), bg=blue, fg=white,
                  activebackground=navy, activeforeground=white, relief="flat", bd=0,
                  cursor="hand2", pady=self.sc(10)).grid(row=0, column=0, sticky="ew")
        tk.Label(right, text="────────────  or continue with  ────────────",
                 font=("Helvetica", self.sf(8)), fg="#9aaac0", bg=white).grid(
                     row=(10 if self._login_mode == "name" else 8), column=0, sticky="ew", pady=(0, self.sc(8)))
        qr_label = self.s("b_qr").replace("📷  ", "").replace("📷", "").replace("▣  ", "").replace("▣", "").strip()
        tk.Button(right, text=qr_label, command=lambda: self.show_qr_login(back=self.show_login),
                  font=("Helvetica", self.sf(9), "bold"), bg=white, fg=blue,
                  activebackground=pale, relief="solid", bd=1, highlightthickness=0,
                  cursor="hand2", pady=self.sc(8)).grid(row=(11 if self._login_mode == "name" else 9), column=0, sticky="ew")
        tk.Button(right, text=self.s("b_back"), command=self.show_welcome,
                  font=("Helvetica", self.sf(9)), bg=white, fg=muted,
                  relief="flat", bd=0, cursor="hand2").grid(
                      row=(12 if self._login_mode == "name" else 10), column=0, sticky="w", pady=(self.sc(10), 0))
        tk.Label(right, text="Your information is protected and used only for barangay health services.",
                 font=("Helvetica", self.sf(7)), fg="#9aaac0", bg=white).grid(
                     row=(13 if self._login_mode == "name" else 11), column=0, sticky="ew", pady=(self.sc(14), 0))

    def _complete_login(self, stored_name, gender, email):
        """Shared final step for any login method: show T&C, then enter the dashboard."""
        def proceed():
            self.user, self.gender, self.email = stored_name, gender, (email or "")
            # ── FIX: always start with a blank session on login ──
            self.session = dict(FRESH)
            self.show_welcome_interstitial(is_new=False)
        self._show_tnc(proceed)

    def _do_login(self):
        last   = self._ll.get().strip()
        first  = self._lf.get().strip()
        middle = self._lm.get().strip()
        if not last or not first:
            self._alert("warning", self.s("e_name")); return
        # Normalize: LASTNAME uppercase, first/middle as typed but title-cased
        name = f"{last.upper()}, {first.strip().title()}"
        if middle:
            name += f" {middle.strip().title()}"
        with sqlite3.connect(DB) as c:
            cur = c.cursor()
        # Case-insensitive search using COLLATE NOCASE
            cur.execute("SELECT name, gender, email FROM residents "
                    "WHERE name=? COLLATE NOCASE", (name,))
            row = cur.fetchone()
        if not row:
            self._alert("error", self.s("e_nf")); return

        # Use the stored name (exact casing) for the session
        stored_name = row[0]
        self._complete_login(stored_name, row[1], row[2])

    def _do_login_email(self):
        ph_email = self.s("lph_email")
        email = self._le.get().strip()
        if not email or email == ph_email:
            self._alert("warning", self.s("e_email_empty")); return
        with sqlite3.connect(DB) as c:
            cur = c.cursor()
            # Case-insensitive match; blank emails on file never match a query
            cur.execute("SELECT name, gender, email FROM residents "
                        "WHERE email=? COLLATE NOCASE AND email IS NOT NULL AND email!=''",
                        (email,))
            row = cur.fetchone()
        if not row:
            self._alert("error", self.s("e_email_nf")); return

        self._complete_login(row[0], row[1], row[2])

    # ── SCREEN: QR LOGIN ──────────────────────────────────────────────────────
    def show_qr_login(self, back=None):
        if back is not None: self._qr_back = back
        self._screen = "qr_login"; self.clr(); self.header()
        inner = self.card(self, px=230, py=24)

        self.lbl(inner, self.s("qtitle"), 20, True).pack(pady=(0, 5))
        self.lbl(inner, self.s("qhint"), 12, color=C["sub"]).pack(pady=(0, 14))

        # Fixed-size camera preview — width/height must be set before the
        # background thread tries to resize frames to fit the label.
        CAM_W, CAM_H = self.sc(560), self.sc(380)
        cam_wrap = tk.Frame(inner, bg=C["acc_lt"],
                            highlightbackground=C["acc"], highlightthickness=2,
                            width=CAM_W + 8, height=CAM_H + 8)
        cam_wrap.pack(pady=(0, self.sc(10)))
        cam_wrap.pack_propagate(False)
        self._cam_lbl = tk.Label(cam_wrap, text="Starting camera…",
                                 font=("Helvetica", self.sf(13)),
                                 bg=C["acc_lt"], fg=C["sub"],
                                 width=CAM_W, height=CAM_H)
        self._cam_lbl.place(x=4, y=4, width=CAM_W, height=CAM_H)
        self._cam_w = CAM_W
        self._cam_h = CAM_H

        self.lbl(inner, self.s("qwait"), 12, color=C["acc"]).pack(pady=(0, 14))
        self.btn(inner, self.s("b_back"),
                 lambda: (self.clr(), getattr(self, "_qr_back", self.show_login)()),
                 bg=C["surface"], fg=C["mut"], size=11).pack()
        self._qr_start()

    # ── SCREEN: REGISTER ──────────────────────────────────────────────────────
    def show_register(self):
        self._screen = "register"; self.clr(); self._nav_bar(); self.header()

        # Scrollable so the form can shift into view above the on-screen
        # keyboard instead of having its lower fields buried under it.
        scroll_area = self._scroll_container(self, bg=C["bg"])
        frame = tk.Frame(scroll_area, bg=C["surface"],
                         highlightbackground=C["bdr"], highlightthickness=1)
        frame.pack(padx=self.sc(160), pady=self.sc(8), fill="x")
        tk.Frame(frame, bg=C["grn"], height=self.sc(6)).pack(fill="x")
        inner = tk.Frame(frame, bg=C["surface"])
        inner.pack(padx=self.sc(36), pady=self.sc(10), fill="x")

        # Title
        self.lbl(inner, self.s("rtitle"), 15, True).pack(anchor="w")
        self.lbl(inner, self.s("rsub"), 10, color=C["sub"]).pack(anchor="w", pady=(2, 8))

        S = C["surface"]
        def field_lbl(parent, text, optional=False):
            row = tk.Frame(parent, bg=S); row.pack(anchor="w", pady=(self.sc(6), 0))
            tk.Label(row, text=text, font=("Helvetica", self.sf(10), "bold"),
                     bg=S, fg=C["acc"]).pack(side="left")
            if optional:
                tk.Label(row, text=f"  {self.s('mid_opt')}",
                         font=("Helvetica", self.sf(9), "italic"),
                         bg=S, fg=C["mut"]).pack(side="left")

        def compact_entry(parent):
            wrap = tk.Frame(parent, bg=C["bdr"], padx=1, pady=1)
            wrap.pack(fill="x", pady=(4, 0))
            e = tk.Entry(wrap, font=("Helvetica", self.sf(12)), bg=C["s2"],
                         fg=C["txt"], relief="flat", bd=0, insertbackground=C["acc"])
            e.pack(fill="x", ipady=self.sc(7), ipadx=self.sc(6))
            e.bind("<FocusIn>",  lambda ev: wrap.configure(bg=C["acc"]))
            e.bind("<FocusOut>", lambda ev: wrap.configure(bg=C["bdr"]))
            return e

        def thin_div():
            tk.Frame(inner, bg=C["div"], height=1).pack(fill="x", pady=(5, 4))

        # ── Row 1: Last Name + First Name side by side ────────────────────
        name_row = tk.Frame(inner, bg=S); name_row.pack(fill="x")

        col_l = tk.Frame(name_row, bg=S)
        col_l.pack(side="left", fill="x", expand=True, padx=(0, self.sc(6)))
        field_lbl(col_l, self.s("l_lastname"))
        _rl_wrap = tk.Frame(col_l, bg=C["bdr"], padx=1, pady=1)
        _rl_wrap.pack(fill="x", pady=(4, 0))
        self._rl = tk.Entry(_rl_wrap, font=("Helvetica", self.sf(12)), bg=C["s2"],
                            fg=C["txt"], relief="flat", bd=0, insertbackground=C["acc"])
        self._rl.pack(fill="x", ipady=self.sc(7), ipadx=self.sc(6))
        self._rl.bind("<FocusIn>",  lambda e: _rl_wrap.configure(bg=C["acc"]))
        self._rl.bind("<FocusOut>", lambda e: _rl_wrap.configure(bg=C["bdr"]))

        col_r = tk.Frame(name_row, bg=S)
        col_r.pack(side="left", fill="x", expand=True)
        field_lbl(col_r, self.s("l_firstname"))
        _rf_wrap = tk.Frame(col_r, bg=C["bdr"], padx=1, pady=1)
        _rf_wrap.pack(fill="x", pady=(4, 0))
        self._rf = tk.Entry(_rf_wrap, font=("Helvetica", self.sf(12)), bg=C["s2"],
                            fg=C["txt"], relief="flat", bd=0, insertbackground=C["acc"])
        self._rf.pack(fill="x", ipady=self.sc(7), ipadx=self.sc(6))
        self._rf.bind("<FocusIn>",  lambda e: _rf_wrap.configure(bg=C["acc"]))
        self._rf.bind("<FocusOut>", lambda e: _rf_wrap.configure(bg=C["bdr"]))

        thin_div()

        # ── Row 2: Middle Name (optional, full width) ─────────────────────
        field_lbl(inner, self.s("l_middlename"), optional=True)
        self._rm = compact_entry(inner)
        thin_div()

        # ── Row 3: Date of Birth (dropdown method from first project) ──────
        field_lbl(inner, self.s("l_birthdate"))
        bd_frame = tk.Frame(inner, bg=C["s2"],
                            highlightbackground=C["bdr"], highlightthickness=1)
        bd_frame.pack(fill="x", pady=(3, 0), ipady=self.sc(2))

        # Inihanda ang listahan ng mga buwan, araw, at taon
        MONTHS = MONTH_NAMES
        cur_year = datetime.now().year
        years = list(range(cur_year, 1919, -1))
        days = list(range(1, 32))

        self._bd_month = tk.StringVar(value="January")
        self._bd_day = tk.IntVar(value=1)
        self._bd_year = tk.IntVar(value=cur_year)

        # ── MONTH DROPDOWN ───────────────────────────────────────────────────
        tk.Label(bd_frame, text="Month", font=("Helvetica", self.sf(8)), bg=C["s2"], fg=C["mut"]
                    ).pack(side="left", padx=(self.sc(8), 0))
        month_cb = ttk.Combobox(bd_frame, textvariable=self._bd_month, values=MONTHS, state="readonly", width=10,
                                font=("Helvetica", self.sf(11)))
        month_cb.pack(side="left", padx=self.sc(2))
        month_cb.bind("<<ComboboxSelected>>", lambda e: self._update_age_lbl())

        tk.Label(bd_frame, text="│", font=("Helvetica", self.sf(12)), bg=C["s2"], fg=C["bdr"]).pack(side="left")

        # ── DAY DROPDOWN ─────────────────────────────────────────────────────
        tk.Label(bd_frame, text="Day", font=("Helvetica", self.sf(8)), bg=C["s2"], fg=C["mut"]
                    ).pack(side="left", padx=(self.sc(4), 0))
        day_cb = ttk.Combobox(bd_frame, textvariable=self._bd_day, values=days, state="readonly", width=4,
                                font=("Helvetica", self.sf(11)))
        day_cb.pack(side="left", padx=self.sc(2))
        day_cb.bind("<<ComboboxSelected>>", lambda e: self._update_age_lbl())

        tk.Label(bd_frame, text="│", font=("Helvetica", self.sf(12)), bg=C["s2"], fg=C["bdr"]).pack(side="left")

        # ── YEAR DROPDOWN ────────────────────────────────────────────────────
        tk.Label(bd_frame, text="Year", font=("Helvetica", self.sf(8)), bg=C["s2"], fg=C["mut"]
                    ).pack(side="left", padx=(self.sc(4), 0))
        year_cb = ttk.Combobox(bd_frame, textvariable=self._bd_year, values=years, state="readonly", width=6,
                                font=("Helvetica", self.sf(11)))
        year_cb.pack(side="left", padx=self.sc(2))
        year_cb.bind("<<ComboboxSelected>>", lambda e: self._update_age_lbl())

        # Age Badge Tracker
        age_badge = tk.Frame(bd_frame, bg=C["s2"], padx=self.sc(6), pady=self.sc(2))
        age_badge.pack(side="left", padx=(self.sc(10), self.sc(6)))
        self._age_lbl = tk.Label(age_badge, text="", font=("Helvetica", self.sf(10), "bold"),
                                    bg=C["s2"], fg=C["txt"])
        self._age_lbl.pack()
        self._update_age_lbl()
        thin_div()

        # ── Row 4: Email (optional, full width) ───────────────────────────
        field_lbl(inner, self.s("l_email"), optional=True)
        self._re = compact_entry(inner)
        ph_email = self.s("email_ph")
        self._re.insert(0, ph_email); self._re.config(fg=C["mut"])
        self._re.bind("<FocusIn>",  lambda e: (
            self._re.delete(0, "end"), self._re.config(fg=C["txt"])
        ) if self._re.get() == ph_email else None)
        self._re.bind("<FocusOut>", lambda e: (
            self._re.insert(0, ph_email), self._re.config(fg=C["mut"])
        ) if not self._re.get() else None)
        thin_div()

        # ── Row 5: Gender ─────────────────────────────────────────────────
        tk.Label(inner, text=self.s("l_gender"),
                 font=("Helvetica", self.sf(10), "bold"),
                 bg=S, fg=C["sub"]).pack(anchor="w")
        gf = tk.Frame(inner, bg=S); gf.pack(anchor="w", pady=(4, 8))
        self._gv = tk.StringVar(value=""); self._gbtns = {}

        def pick(v):
            self._gv.set(v)
            for val, b in self._gbtns.items():
                b.configure(bg=C["acc"] if val == v else C["s2"],
                            fg="white"  if val == v else C["sub"])

        for val, key in [("Male", "male"), ("Female", "female")]:
            b = tk.Button(gf, text=self.s(key),
                          font=("Helvetica", self.sf(12), "bold"),
                          bg=C["s2"], fg=C["sub"], relief="flat", bd=0,
                          width=10, height=1, cursor="hand2",
                          command=lambda v=val: pick(v))
            b.pack(side="left", padx=(0, self.sc(8))); self._gbtns[val] = b
        # No default pick — the resident must actively choose a gender
        # instead of the form assuming "Male" for them.

        # ── Actions ───────────────────────────────────────────────────────
        self.btn(inner, self.s("b_reg"), self._do_register,
                 bg=C["grn"], height=1).pack(fill="x", pady=(2, 6))
        self.btn(inner, self.s("b_back"), self.show_welcome,
                 bg=S, fg=C["mut"], size=10).pack(anchor="w")

    def _update_age_lbl(self):
        age = self._calc_age_from_spinboxes()
        if age is not None and hasattr(self, "_age_lbl") and self._age_lbl.winfo_exists():
            self._age_lbl.configure(text=f"Age: {age}")

    def _calc_age_from_spinboxes(self):
        try:
            m = MONTH_NAMES.index(self._bd_month.get()) + 1
            d = int(self._bd_day.get()); y = int(self._bd_year.get())
            bday = datetime(y, m, d); today = datetime.now()
            age = today.year - bday.year - ((today.month, today.day) < (bday.month, bday.day))
            return age if age >= 0 else None
        except Exception: return None

    def _do_register(self):
        last   = self._rl.get().strip()
        first  = self._rf.get().strip()
        middle = self._rm.get().strip()
        gen    = self._gv.get()

        if not last or not first:
            self._alert("warning", self.s("e_name")); return

        if not gen:
            self._alert("warning", self.s("e_gender")); return

        # Compose full name: "LASTNAME, Firstname Middlename"
        name = f"{last.upper()}, {first}"
        if middle:
            name += f" {middle}"

        # Age and birthdate from spinboxes
        age = self._calc_age_from_spinboxes()
        try:
            m = MONTH_NAMES.index(self._bd_month.get()) + 1
            d = int(self._bd_day.get())
            y = int(self._bd_year.get())
            birthdate = f"{y:04d}-{m:02d}-{d:02d}"
        except Exception:
            birthdate = ""

        # Collect email — ignore placeholder text
        raw_email = self._re.get().strip()
        ph_email  = self.s("email_ph")
        email = raw_email if raw_email and raw_email != ph_email else ""

        with sqlite3.connect(DB) as c:
            cur = c.cursor()
            cur.execute("SELECT id FROM residents WHERE name=?", (name,))
            existing = cur.fetchone()
        if existing:
            self._alert("error", self.s("e_already_exists").format(name=name))
            return

        def proceed():
            with sqlite3.connect(DB) as c2:
                c2.execute("INSERT INTO residents (name,age,gender,email,birthdate) VALUES (?,?,?,?,?)",
                          (name, str(age) if age is not None else "", gen, email, birthdate))
            self.user, self.gender, self.email = name, gen, email
            self.session = dict(FRESH); self.show_welcome_interstitial(is_new=True)

        self._show_tnc(proceed)

    # ── ADVISER REC: Welcome / Interstitial Screen (full-height kiosk layout) ───
    def show_welcome_interstitial(self, is_new=None):
        if is_new is None: is_new = getattr(self, "_wi_new", False)
        self._wi_new = is_new
        self._screen = "welcome_interstitial"
        self.clr()
        self._nav_bar()
        self.header(show_user=True)

        user_name = format_display_name(self.user)

        # Main container fills ALL remaining height; rows share it by weight
        col = tk.Frame(self, bg=C["bg"])
        col.pack(fill="both", expand=True, padx=self.sc(50), pady=self.sc(24))
        col.grid_columnconfigure(0, weight=1)
        col.grid_rowconfigure(0, weight=2, minsize=max(self.sc(170), int(self.SH * 0.22)))   # hero
        col.grid_rowconfigure(1, weight=3, minsize=max(self.sc(250), int(self.SH * 0.36)))   # action cards

        # ── HERO CARD ────────────────────────────────────────────────────────
        hero = tk.Frame(col, bg=C["surface"], highlightbackground=C["bdr"], highlightthickness=1)
        hero.grid(row=0, column=0, sticky="nsew", pady=(0, self.sc(20)))

        hero_inner = tk.Frame(hero, bg=C["surface"])
        hero_inner.pack(fill="both", expand=True, padx=self.sc(32), pady=self.sc(24))

        tk.Label(hero_inner, text="🏥", font=("Helvetica", self.sf(52)), bg=C["acc_lt"],
                 padx=self.sc(14), pady=self.sc(8)
                 ).pack(side="left", padx=(0, self.sc(26)))

        # New residents: personal QR + Print QR Card on the right of the hero
        if is_new:
            qr_box = tk.Frame(hero_inner, bg=C["surface"])
            qr_box.pack(side="right", padx=(self.sc(20), 0))
            try:
                ph = ImageTk.PhotoImage(qr_pil(self.user, self.sc(150)))
                ql = tk.Label(qr_box, image=ph, bg=C["surface"]); ql.image = ph
                ql.pack()
            except Exception as e:
                tk.Label(qr_box, text=str(e), bg=C["surface"], fg=C["red"]).pack()
            self.btn(qr_box, self.s("wi_print_qr"), self._print_qr_card,
                     bg=C["gld"], size=11, pady=self.sc(10)).pack(pady=(self.sc(8), 0))

        txt_box = tk.Frame(hero_inner, bg=C["surface"])
        txt_box.pack(side="left", fill="both", expand=True)
        # inner spacer frames vertically centre the text block in the hero
        tk.Frame(txt_box, bg=C["surface"]).pack(expand=True)
        tk.Label(txt_box, text=self.s("wi_welcome").format(name=user_name),
                 font=("Helvetica", self.sf(24), "bold"),
                 bg=C["surface"], fg=C["hdr"], anchor="w", justify="left",
                 wraplength=max(self.sc(300), self.SW - self.sc(520))
                 ).pack(anchor="w")
        tk.Label(txt_box, text=self.s("wi_reg_success") if is_new else self.s("wi_prompt"),
                 font=("Helvetica", self.sf(13)), bg=C["surface"], fg=C["sub"],
                 wraplength=max(self.sc(300), self.SW - self.sc(520)), justify="left"
                 ).pack(anchor="w", pady=(self.sc(8), 0))
        tk.Frame(txt_box, bg=C["surface"]).pack(expand=True)

        # ── ACTION CARDS (2 columns, stretch to fill the remaining height) ───
        cards = tk.Frame(col, bg=C["bg"])
        cards.grid(row=1, column=0, sticky="nsew")
        cards.grid_rowconfigure(0, weight=1)
        cards.grid_columnconfigure(0, weight=1, uniform="wi_cards")
        cards.grid_columnconfigure(1, weight=1, uniform="wi_cards")
        card_wrap = max(self.sc(260), (self.SW - self.sc(100)) // 2 - self.sc(90))

        def make_card(colno, border, thick, title_k, desc_k, btn_k, cmd, btn_bg, padx):
            card = tk.Frame(cards, bg=C["surface"], highlightbackground=border, highlightthickness=thick)
            card.grid(row=0, column=colno, sticky="nsew", padx=padx)
            inner = tk.Frame(card, bg=C["surface"])
            inner.pack(fill="both", expand=True, padx=self.sc(28), pady=self.sc(26))
            # Button is packed to the bottom FIRST so it is always pinned there
            self.btn(inner, self.s(btn_k), cmd, bg=btn_bg, fg="white", size=15,
                     pady=self.sc(18)).pack(side="bottom", fill="x")
            tk.Label(inner, text=self.s(title_k), font=("Helvetica", self.sf(20), "bold"),
                     bg=C["surface"], fg=C["hdr"], anchor="w", justify="left",
                     wraplength=card_wrap).pack(anchor="w")
            tk.Label(inner, text=self.s(desc_k), font=("Helvetica", self.sf(13)),
                     bg=C["surface"], fg=C["sub"], wraplength=card_wrap, justify="left"
                     ).pack(anchor="w", pady=(self.sc(10), self.sc(10)))

        make_card(0, C["grn"], 3, "wi_guided_title", "wi_guided_desc", "wi_guided_btn",
                  lambda: self.show_guided_check(0), C["grn"], (0, self.sc(12)))
        make_card(1, C["acc"], 2, "wi_dash_title", "wi_dash_desc", "wi_dash_btn",
                  self.show_dashboard, C["acc"], (self.sc(12), 0))

    def _print_qr_card(self):
        """Render the resident's QR + name onto a small card PDF and send it to the printer/viewer."""
        try:
            from PIL import ImageDraw, ImageFont
            import textwrap
            W, H = 640, 400
            card = Image.new("RGB", (W, H), "white")
            d = ImageDraw.Draw(card)
            d.rectangle([0, 0, W - 1, H - 1], outline="#1a56a0", width=6)
            card.paste(qr_pil(self.user, 300), (30, 50))
            def font(sz):
                try:    return ImageFont.truetype("DejaVuSans-Bold.ttf", sz)
                except Exception: return ImageFont.load_default()
            d.text((360, 60), "SENTRO GINHAWA", fill="#1a3a6b", font=font(30))
            y = 120
            for line in textwrap.wrap(format_display_name(self.user), 18):
                d.text((360, y), line, fill="#0f172a", font=font(26)); y += 36
            d.text((360, y + 14), self.s("wi_qr_card_line"),
                   fill="#475569", font=font(18))
            fd, path = tempfile.mkstemp(suffix=".pdf"); os.close(fd)
            card.save(path, "PDF", resolution=150)
            open_pdf(path)
            self._alert("info", self.s("wi_qr_sent"))
        except Exception as e:
            self._alert("error", str(e))

    # ── ADVISER REC: Guided Health Check wizard ───────────────────────────────
    # (icon, step number, [db keys], optional)  — all text comes from STRINGS
    _WIZ_STEPS = [
        ("📏", 1, ["Height"],           False),
        ("⚖",  2, ["Weight"],           False),
        ("🌡", 3, ["Body Temperature"],  False),
        ("💓", 4, ["Blood Pressure"],    False),
        ("🩸", 5, ["Blood Glucose"],     True),
    ]

    # ── Kiosk visual helpers: status ring + pulse while a sensor is reading ──
    @staticmethod
    def _blend(c1, c2, t):
        a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
        b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
        return "#%02x%02x%02x" % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

    def _ring_idle(self, cv, size, color, icon):
        """Static ring (grey = waiting, green/amber/red = reading status)."""
        try:
            if not cv.winfo_exists(): return
        except Exception: return
        cv.delete("all")
        p = self.sc(6)
        cv.create_oval(p, p, size - p, size - p, outline=color, width=self.sc(5))
        cv.create_text(size // 2, size // 2, text=icon, font=("Helvetica", self.sf(20)))

    def _ring_pulse(self, cv, size, icon):
        """Pulsing ring shown while the sensor is being read; returns stop()."""
        import math
        st = {"t": 0.0, "on": True}
        def tick():
            if not st["on"]: return
            try:
                if not cv.winfo_exists(): return
            except Exception: return
            ph = (math.sin(st["t"]) + 1) / 2
            cv.delete("all")
            p = self.sc(3) + int(ph * self.sc(5))
            cv.create_oval(p, p, size - p, size - p, width=self.sc(5),
                           outline=self._blend(C["acc_lt"], C["acc"], ph))
            cv.create_text(size // 2, size // 2, text=icon, font=("Helvetica", self.sf(20)))
            st["t"] += 0.45
            cv.after(60, tick)
        tick()
        def stop(): st["on"] = False
        return stop

    def show_guided_check(self, step=None):
        if step is None: step = getattr(self, "_wiz_step", 0)
        self._wiz_step = step
        self._screen = "guided_check"; self.clr(); self._nav_bar()
        self.header(show_user=True)
        if step >= len(self._WIZ_STEPS):
            self._show_wizard_summary(); return

        icon, n, keys, optional = self._WIZ_STEPS[step]
        title = self.s(f"wiz_step{n}_title")
        instr = self.s(f"wiz_step{n}_desc")
        tutorial_steps = [self.s(f"wiz_s{n}_t{i}") for i in (1, 2, 3)]
        mods = {m[0]: m for m in MODS}

        # Content stays near the top so the on-screen keyboard never covers it
        col = tk.Frame(self, bg=C["bg"]); col.pack(fill="x", padx=self.sc(50), pady=(self.sc(14), 0))

        # ── Step Indicator Bar ────────────────────────────────────────────────
        prog = tk.Frame(col, bg=C["bg"]); prog.pack(anchor="w", pady=(0, self.sc(8)))
        for i in range(5):
            color = C["grn"] if i < step else (C["acc"] if i == step else C["bdr"])
            tk.Frame(prog, bg=color, width=self.sc(60), height=self.sc(8)).pack(side="left", padx=2)

        tk.Label(col, text=f"{icon}  {title}", font=("Helvetica", self.sf(18), "bold"),
                 bg=C["bg"], fg=C["hdr"]).pack(anchor="w")
        tk.Label(col, text=instr, font=("Helvetica", self.sf(12)), bg=C["bg"], fg=C["sub"],
                 wraplength=self.SW - self.sc(140), justify="left"
                 ).pack(anchor="w", pady=(self.sc(2), self.sc(10)))

        # ── Simple Tutorial / Guide Box ───────────────────────────────────────
        guide_box = tk.Frame(col, bg=C["acc_lt"], highlightbackground=C["acc"], highlightthickness=1)
        guide_box.pack(fill="x", pady=(0, self.sc(12)))
        guide_inner = tk.Frame(guide_box, bg=C["acc_lt"])
        guide_inner.pack(fill="x", padx=self.sc(16), pady=self.sc(10))
        tk.Label(guide_inner, text=self.s("wiz_howto"),
                 font=("Helvetica", self.sf(12), "bold"),
                 bg=C["acc_lt"], fg=C["hdr"]).pack(anchor="w", pady=(0, self.sc(4)))
        for t_step in tutorial_steps:
            tk.Label(guide_inner, text=f"  {t_step}", font=("Helvetica", self.sf(11)),
                     bg=C["acc_lt"], fg=C["txt"], anchor="w").pack(fill="x", pady=2)

        # ── Sensor Reading Controls ───────────────────────────────────────────
        ents = {}
        err = tk.Label(col, text="", font=("Helvetica", self.sf(11), "bold"), bg=C["bg"], fg=C["red"])

        for key in keys:
            _, sk, uk, ic, sensor_id = mods[key]
            unit = self.s(uk) if uk else ""
            RS = self.sc(64)
            r = tk.Frame(col, bg=C["surface"], highlightbackground=C["bdr"], highlightthickness=1)
            r.pack(fill="x", pady=self.sc(3))

            ring = tk.Canvas(r, width=RS, height=RS, bg=C["surface"], highlightthickness=0)
            ring.pack(side="left", padx=(self.sc(14), self.sc(10)), pady=self.sc(8))
            self._ring_idle(ring, RS, C["bdr"], ic)

            # The entry doubles as a BIG live readout (readable from a step back)
            sv = tk.StringVar()
            e = self.entry(r, width=7, justify="center", textvariable=sv)
            e.configure(font=("Helvetica", self.sf(30), "bold"))
            e.pack(side="left", ipady=self.sc(4))
            e._sv = sv            # keep the StringVar alive (Tk deletes it on garbage collection)
            ents[key] = e

            tk.Label(r, text=unit, font=("Helvetica", self.sf(13), "bold"), bg=C["surface"],
                     fg=C["sub"]).pack(side="left", padx=(self.sc(8), self.sc(10)))

            info = tk.Frame(r, bg=C["surface"]); info.pack(side="left", padx=self.sc(6))
            pill = tk.Label(info, text="", font=("Helvetica", self.sf(11), "bold"),
                            bg=C["surface"], fg="white", padx=self.sc(8), pady=self.sc(3),
                            wraplength=self.sc(170))
            pill.pack(anchor="w")
            st = tk.Label(info, text="", font=("Helvetica", self.sf(11), "bold"),
                          bg=C["surface"], fg=C["acc"])
            st.pack(anchor="w", pady=(self.sc(3), 0))

            ctl = {"stop": None}
            def refresh(*_, k=key, ent=e, pl=pill, rg=ring, ico=ic, rs=RS, ctl=ctl):
                """Status chip + ring colour follow whatever is in the box (sensor or typed)."""
                raw = ent.get().strip(); stat = None
                if raw and (k != "Blood Pressure" or "/" in raw):
                    s_ = self._metric_status(k, raw)
                    if s_[0] != "Unknown": stat = s_
                if stat: pl.configure(text=stat[0], bg=stat[1])
                else:    pl.configure(text="", bg=C["surface"])
                if ctl["stop"] is None:
                    self._ring_idle(rg, rs, stat[1] if stat else C["bdr"], ico)
            sv.trace_add("write", refresh)
            if self.session.get(key): e.insert(0, self.session[key])

            rb = self.btn(r, self.s("btn_read_sensor"), lambda: None, bg=C["acc"], size=13,
                          pady=self.sc(12))
            rb.pack(side="right", padx=self.sc(12), pady=self.sc(8))

            def do_read(k=key, sid=sensor_id, ent=e, lab=st, u=unit, rg=ring, ico=ic,
                        rs=RS, btn=rb, pl=pill, ctl=ctl):
                if ctl["stop"] is not None: return          # already reading
                btn.configure(state="disabled")
                stop_spin = self._start_spinner(lab, self.s("sensor_wait"))
                stop_ring = self._ring_pulse(rg, rs, ico)
                ctl["stop"] = True
                lab.configure(fg=C["acc"])
                def run():
                    v, _ = read_sensor(sid)
                    def done():
                        if not lab.winfo_exists(): return
                        stop_spin(); stop_ring(); ctl["stop"] = None
                        btn.configure(state="normal")
                        if v:
                            ent.delete(0, tk.END); ent.insert(0, v)   # → refresh() paints chip + ring
                            lab.configure(text="✓", fg=C["grn"])
                        else:
                            lab.configure(text=self.s("wiz_read_fail"), fg=C["red"])
                            self._ring_idle(rg, rs, C["red"], ico)
                    self.after(0, done)
                threading.Thread(target=run, daemon=True).start()
            rb.configure(command=do_read)
            refresh()

        # Special action for Blood Glucose step
        if keys == ["Blood Glucose"]:
            lan_row = tk.Frame(col, bg=C["bg"])
            lan_row.pack(fill="x", pady=(self.sc(6), 0))
            lan = tk.Label(lan_row, text="", font=("Helvetica", self.sf(11), "bold"), bg=C["bg"], fg=C["acc"])

            def do_lancet():
                stop = self._start_spinner(lan, self.s("lancet_wait"))
                def run():
                    ok, _ = dispense_lancet()
                    def done():
                        if not lan.winfo_exists(): return
                        stop()
                        lan.configure(text=f"✓  {self.s('lancet_ok')}" if ok else self.s("lancet_fail"),
                                      fg=C["grn"] if ok else C["red"])
                    self.after(0, done)
                threading.Thread(target=run, daemon=True).start()

            self.btn(lan_row, self.s("btn_lancet"), do_lancet, bg=C["red"], size=12,
                     pady=self.sc(10)).pack(side="left", padx=(0, self.sc(8)))
            lan.pack(side="left")

        err.pack(anchor="w", pady=(self.sc(4), 0))

        # ── Navigation Buttons ────────────────────────────────────────────────
        def go_next():
            vals = {}
            for k, e in ents.items():
                raw = e.get().strip()
                if not raw:
                    if optional: continue
                    err.configure(text=self.s("wiz_err_empty")); return
                if k != "Blood Pressure":
                    try: float(raw)
                    except ValueError:
                        err.configure(text=self.s("wiz_err_num")); return
                vals[k] = raw
            self.session.update(vals); self.calc_bmi()
            self._hide_keyboard(); self.show_guided_check(step + 1)

        def go_skip():
            self._hide_keyboard()
            self.show_guided_check(step + 1)

        def go_back():
            self._hide_keyboard()
            if step == 0: self.show_welcome_interstitial()
            else:         self.show_guided_check(step - 1)

        nav = tk.Frame(col, bg=C["bg"]); nav.pack(fill="x", pady=(self.sc(12), 0))
        self.btn(nav, self.s("btn_back_arrow"), go_back, bg=C["surface"], fg=C["sub"], size=12,
                 pady=self.sc(12)).pack(side="left")
        self.btn(nav, self.s("btn_next_step"), go_next, bg=C["grn"], size=14,
                 pady=self.sc(12)).pack(side="right")
        self.btn(nav, self.s("btn_skip_test"), go_skip, bg=C["s2"], fg=C["acc"], size=12,
                 pady=self.sc(12)).pack(side="right", padx=self.sc(10))

    # ── ADVISER REC: Summary Screen with Dynamic, Language-aware Tips ─────────
    def _get_health_recommendations(self):
        """Friendly tips in the active language, most important first. Uses the SAME cut-offs
        as _metric_status() so chips, detail screen and tips never contradict each other."""
        tips = []   # (priority, text) — 2 = needs attention, 1 = keep an eye, 0 = fine

        bg_val = self.session.get("Blood Glucose")
        if bg_val:
            try:
                v = float(bg_val)
                if v < 70:      tips.append((2, self.s("wiz_tip_low_glucose")))
                elif v <= 99:   tips.append((0, self.s("wiz_tip_norm_glucose")))
                elif v <= 125:  tips.append((1, self.s("wiz_tip_pre_glucose")))
                else:           tips.append((2, self.s("wiz_tip_high_glucose")))
            except ValueError: pass

        bp_val = self.session.get("Blood Pressure")
        if bp_val and "/" in bp_val:
            try:
                sys_v = float(bp_val.split("/")[0])
                if sys_v < 90:        tips.append((2, self.s("wiz_tip_low_bp")))
                elif sys_v < 120:     tips.append((0, self.s("wiz_tip_norm_bp")))
                elif sys_v < 140:     tips.append((1, self.s("wiz_tip_high_bp")))
                else:                 tips.append((2, self.s("wiz_tip_high_bp2")))
            except ValueError: pass

        temp_val = self.session.get("Body Temperature")
        if temp_val:
            try:
                if float(temp_val) > 37.2: tips.append((2, self.s("wiz_tip_fever")))
            except ValueError: pass

        if not tips:
            return [self.s("wiz_tip_default")]
        tips.sort(key=lambda t: -t[0])          # stable: keeps glucose/BP/temp order within a level
        return [t for _, t in tips]

    def _show_wizard_summary(self):
        self.calc_bmi()
        TIPS_BG = "#F0FDF4"

        col = tk.Frame(self, bg=C["bg"])
        col.pack(fill="both", expand=True, padx=self.sc(50), pady=(self.sc(14), self.sc(16)))

        # Action bar is packed to the BOTTOM first so it is always pinned there
        def finish(print_too):
            if self._save() and print_too:
                self._do_print()

        nav = tk.Frame(col, bg=C["bg"])
        nav.pack(side="bottom", fill="x", pady=(self.sc(14), 0))
        self.btn(nav, self.s("btn_back_arrow"), lambda: self.show_guided_check(len(self._WIZ_STEPS) - 1),
                 bg=C["surface"], fg=C["sub"], size=13, pady=self.sc(16)).pack(side="left")
        self.btn(nav, self.s("btn_save_print"), lambda: finish(True),
                 bg=C["grn"], fg="white", size=14, pady=self.sc(16)).pack(side="right")
        self.btn(nav, self.s("btn_save_only"), lambda: finish(False),
                 bg=C["acc"], fg="white", size=13, pady=self.sc(16)).pack(side="right", padx=self.sc(12))

        # Progress + title share one row (saves height on small kiosk screens)
        head = tk.Frame(col, bg=C["bg"]); head.pack(fill="x", pady=(0, self.sc(4)))
        prog = tk.Frame(head, bg=C["bg"]); prog.pack(side="left")
        for _ in range(5):
            tk.Frame(prog, bg=C["grn"], width=self.sc(34), height=self.sc(8)).pack(side="left", padx=2)
        tk.Label(head, text=self.s("wiz_summary_title"),
                 font=("Helvetica", self.sf(18), "bold"), bg=C["bg"], fg=C["hdr"]
                 ).pack(side="left", padx=(self.sc(14), 0))

        # Scrollable body: grid + tips. Drag/scroll if a screen is too short to show it all.
        body = self._scroll_container(col, bg=C["bg"])
        body.pack_configure(padx=0, pady=self.sc(2))

        # ── RESULTS: 3 × 2 cards, each with a status bar + status pill ───────
        grid = tk.Frame(body, bg=C["bg"]); grid.pack(fill="x")
        for c_ in range(3):
            grid.grid_columnconfigure(c_, weight=1, uniform="sum_cols")
        for i, (key, sk, uk, ic, _sid) in enumerate(MODS):
            val = self.session.get(key)
            unit_str = self.s(uk) if uk else ""
            txt = f"{val} {unit_str}".strip() if val else self.s("wiz_skipped")
            stat = self._metric_status(key, val) if val else None
            if stat and stat[0] == "Unknown": stat = None

            r, c = divmod(i, 3)
            cell = tk.Frame(grid, bg=C["surface"], highlightbackground=C["bdr"], highlightthickness=1)
            cell.grid(row=r, column=c, sticky="nsew", padx=self.sc(5), pady=self.sc(5))
            tk.Frame(cell, bg=stat[1] if stat else C["bdr"], width=self.sc(8)).pack(side="left", fill="y")
            left = tk.Frame(cell, bg=C["surface"])
            left.pack(side="left", fill="both", expand=True, padx=(self.sc(10), self.sc(6)), pady=self.sc(7))
            tk.Label(left, text=f"{ic}  {self.s(sk)}", font=("Helvetica", self.sf(11)),
                     bg=C["surface"], fg=C["sub"]).pack(anchor="w")
            tk.Label(left, text=txt, font=("Helvetica", self.sf(19 if val else 13), "bold"),
                     bg=C["surface"], fg=C["txt"] if val else C["mut"]).pack(anchor="w")
            if stat:
                tk.Label(left, text=stat[0], font=("Helvetica", self.sf(9), "bold"),
                         bg=stat[1], fg="white", padx=self.sc(7), pady=self.sc(2),
                         wraplength=self.sc(150), justify="left").pack(anchor="w", pady=(self.sc(3), 0))

        # ── HEALTH TIPS (most important first) ───────────────────────────────
        TIPS_BG = "#F0FDF4"
        tips_card = tk.Frame(body, bg=TIPS_BG, highlightbackground=C["grn"], highlightthickness=1)
        tips_card.pack(fill="x", pady=(self.sc(8), self.sc(4)), padx=self.sc(5))
        tips_inner = tk.Frame(tips_card, bg=TIPS_BG)
        tips_inner.pack(fill="x", padx=self.sc(16), pady=self.sc(10))
        tk.Label(tips_inner, text=self.s("wiz_tips_title"),
                 font=("Helvetica", self.sf(13), "bold"), bg=TIPS_BG, fg=C["hdr"]
                 ).pack(anchor="w", pady=(0, self.sc(4)))
        for tip in self._get_health_recommendations():
            tk.Label(tips_inner, text=tip, font=("Helvetica", self.sf(12)),
                     bg=TIPS_BG, fg=C["txt"], anchor="w", justify="left",
                     wraplength=self.SW - self.sc(190)
                     ).pack(fill="x", pady=self.sc(2))
        tk.Label(tips_inner, text=self.s("wiz_disclaimer"), font=("Helvetica", self.sf(10), "italic"),
                 bg=TIPS_BG, fg=C["sub"]).pack(anchor="w", pady=(self.sc(4), 0))

    # ── SCREEN: DASHBOARD ────────────────────────────────────────────────────
    def _toggle_update(self):
        self.update_mode = not self.update_mode
        if not self.update_mode: self.db_load()
        self.calc_bmi(); self.show_dashboard()

    def show_dashboard(self):
        self._screen = "dashboard"; self.clr(); self.calc_bmi()
        self.header(show_user=True, show_update=True, show_print=True)

        # Identity strip
        strip = tk.Frame(self, bg=C["strip"], height=max(self.sc(56), 48))
        strip.pack(fill="x"); strip.pack_propagate(False)
        gc = "#1e40af" if self.gender == "Male" else "#9d174d"

        display_name = format_display_name(self.user)
        tk.Label(strip, text=f"  👤  {display_name}  •  {self.gender}",
                 font=("Helvetica", self.sf(13), "bold"),
                 bg=C["strip"], fg=gc).pack(side="left", padx=self.sc(16))
        if self.update_mode:
            tk.Label(strip, text=f"  {self.s('umode')}",
                     font=("Helvetica", self.sf(11), "bold"),
                     bg=C["gld_lt"], fg=C["gld"]).pack(side="right", padx=self.sc(10))
        self.btn(strip, self.s("b_myqr"), self._show_qr,
                 bg=C["acc_lt"], fg=C["acc"], size=11,
                 padx=self.sc(12), pady=self.sc(6)).pack(side="right", padx=12)
        self.btn(strip, self.s("b_history"), self._show_history,
                 bg=C["acc_lt"], fg=C["acc"], size=11,
                 padx=self.sc(12), pady=self.sc(6)).pack(side="right", padx=(0, 0))

        # ── Adviser rec: call-to-action banner when nothing is recorded yet ──
        if not self.update_mode and all(self.session.get(k) is None for k, *_ in MODS):
            ban = tk.Frame(self, bg=C["gld_lt"], highlightbackground=C["gld"],
                           highlightthickness=1)
            ban.pack(fill="x", padx=16, pady=(8, 0))
            # one compact line so the card grid keeps its height on 800×480 kiosks
            tk.Label(ban, text=self.s("dash_cta_title"),
                     font=("Helvetica", self.sf(12), "bold"),
                     bg=C["gld_lt"], fg=C["gld"]).pack(side="left", padx=(self.sc(12), self.sc(8)), pady=self.sc(5))
            tk.Label(ban, text=self.s("dash_cta_body"),
                     font=("Helvetica", self.sf(11)), bg=C["gld_lt"], fg=C["sub"],
                     wraplength=self.SW - self.sc(330), justify="left"
                     ).pack(side="left", pady=self.sc(5))

        # Bottom bar — packed BEFORE grid
        bot = tk.Frame(self, bg=C["grn_lt"], height=max(self.sc(84), 70))
        bot.pack(fill="x", side="bottom"); bot.pack_propagate(False)
        if self.update_mode:
            self.btn(bot, self.s("b_save"), self._save,
                     bg=C["grn"], size=14
                     ).place(relx=.5, rely=.5, anchor="center",
                             width=self.sc(520), height=max(self.sc(60), 54))
        else:
            ts  = self.db_ts()
            msg = f"{self.s('last')} {ts}" if ts else self.s("norec")
            tk.Label(bot, text=msg, font=("Helvetica", self.sf(11)), wraplength=self.sc(200),
                     justify="right", bg=C["grn_lt"], fg=C["sub"]).place(relx=0.99, rely=0.5, anchor="e")
            # Adviser rec: high-visibility primary action, bottom centre
            self.btn(bot, self.s("btn_start_screening"), lambda: self.show_guided_check(0),
                     bg=C["grn"], size=15
                     ).place(relx=.5, rely=.5, anchor="center",
                             width=self.sc(300), height=max(self.sc(60), 54))

        # ── Back to menu button (always visible in bottom-left) ───────────

        self.btn(bot,  self.s("btn_back_menu"), self.show_welcome,
                 bg=C["hdr"], fg="white", size=12,
                 padx=self.sc(18), pady=self.sc(12)
                 ).place(relx=0.0, rely=0.5, anchor="w", x=self.sc(12))

        # Card grid
        grid = tk.Frame(self, bg=C["bg"])
        grid.pack(expand=True, fill="both", padx=self.sc(20), pady=(self.sc(6), self.sc(4)))

        for i, (key, sk, uk, icon, sensor_id) in enumerate(MODS):
            r, col   = divmod(i, 3)
            val      = self.session.get(key)
            done     = val is not None
            is_bmi   = key == "BMI Calculation"
            in_upd   = self.update_mode and not is_bmi

            # Status chips reuse _metric_status() — the same triage the detail
            # screen uses — so a Fever or high-BP card no longer looks "green/done".
            status = self._metric_status(key, val) if (done and not in_upd) else None
            if status and status[0] == "Unknown": status = None

            empty = (not done) and (not is_bmi) and (not in_upd)
            bg_c  = (C["upd"] if in_upd else C["surface"] if status else
                     C["done"] if done else (C["s2"] if empty else C["surface"]))
            bdr_c = (C["upd_b"] if in_upd else status[1] if status else
                     C["done_b"] if done else (C["acc"] if empty else C["bdr"]))
            strip_c = (status[1] if status else C["gld"] if in_upd else
                       C["acc"] if empty else C["done_b"] if done else C["bdr"])

            card = tk.Frame(grid, bg=bg_c,
                            highlightbackground=bdr_c, highlightthickness=2)
            card.grid(row=r, column=col, padx=self.sc(10), pady=self.sc(4), sticky="nsew")
            grid.grid_columnconfigure(col, weight=1)
            # A minimum row height keeps cards from looking cramped, but no
            # hard cap — if translated text needs to wrap onto more lines,
            # the row grows to fit it instead of clipping the content.
            grid.grid_rowconfigure(r, weight=1, minsize=max(self.sc(110), int(self.SH * 0.20)))

            tk.Frame(card, bg=strip_c, height=self.sc(7)).pack(fill="x")   # status accent strip
            inn = tk.Frame(card, bg=bg_c)
            inn.pack(fill="both", expand=True, padx=self.sc(18), pady=self.sc(8))

            # Icon + badge row — badge gets its own reserved space on the
            # right so a longer translated badge (e.g. Filipino "Pindutin
            # para I-edit" vs English "Tap to Edit") can't visually collide
            # with the icon on the left.
            top = tk.Frame(inn, bg=bg_c); top.pack(fill="x")
            tk.Label(top, text=icon, font=("Helvetica", self.sf(22 if self.SH < 600 else 28)), bg=bg_c).pack(side="left")
            if status:
                badge_txt, badge_bg = status
            else:
                badge_txt = (self.s("edit_b") if in_upd else
                             self.s("done_b") if done and not is_bmi else
                             self.s("dash_auto") if is_bmi and done else None)
                badge_bg  = (C["gld"] if in_upd or (is_bmi and done) else
                             C["grn"] if done else None)
            if badge_txt:
                badge_wrap = tk.Frame(top, bg=bg_c)
                badge_wrap.pack(side="right", fill="x")
                tk.Label(badge_wrap, text=badge_txt, font=("Helvetica", self.sf(10), "bold"),
                         bg=badge_bg, fg="white", padx=self.sc(9), pady=self.sc(3),
                         wraplength=self.sc(170), justify="right"
                         ).pack(side="right", anchor="e")

            tk.Label(inn, text=self.s(sk), font=("Helvetica", self.sf(14), "bold"),
                     bg=bg_c, fg=C["txt"], wraplength=self.sc(190), justify="left"
                     ).pack(anchor="w", pady=(self.sc(2), 1), fill="x")

            unit  = self.s(uk) if uk else ""
            if is_bmi and done:
                # The status (Normal/Overweight/...) already shows in the
                # badge above, so just show the plain number here.
                disp = str(val).split()[0] if val else self.s("notyet")
            else:
                disp = (f"{val} {unit}".strip() if done else
                        (self.s("dash_tap_measure") if empty else self.s("notyet")))
            fgv = (C["txt"] if status else
                   C["grn"] if done and not is_bmi else
                   C["gld"] if done and is_bmi else (C["acc"] if empty else C["mut"]))
            tk.Label(inn, text=disp, font=("Helvetica", self.sf(20 if done else 14), "bold"),
                     bg=bg_c, fg=fgv, wraplength=self.sc(190), justify="left"
                     ).pack(anchor="w", fill="x")

            if is_bmi and not done and self.SH >= 600:      # hint hidden on short screens
                tk.Label(inn, text=self.s("bmi_hint"),
                         font=("Helvetica", self.sf(9), "italic"),
                         bg=bg_c, fg=C["mut"], wraplength=self.sc(195)).pack(anchor="w", pady=(self.sc(4), 0))

            if in_upd:
                edit_btn = self.btn(card, "  EDIT  ",
                         lambda k=key, s=sk, u=uk, ic=icon, sid=sensor_id:
                             self.show_metric_detail(k, s, u, ic, sid, edit_mode=True),
                         size=11, padx=max(self.sc(10), 10), pady=max(self.sc(5), 6))
                edit_btn.place(relx=1.0, rely=1.0, anchor="se", x=-8, y=-8)

                # Also make the whole card tappable — a much more forgiving
                # touch target than just the small corner button.
                card.configure(cursor="hand2")
                def _go_edit(e, k=key, s=sk, u=uk, ic=icon, sid=sensor_id):
                    self.show_metric_detail(k, s, u, ic, sid, edit_mode=True)
                for _w in card.winfo_children() + [card]:
                    if _w is edit_btn:
                        continue
                    _w.bind("<Button-1>", _go_edit, add="+")
                for _w in inn.winfo_children() + [inn]:
                    _w.bind("<Button-1>", _go_edit, add="+")
            else:
                # Tap card → full-screen detail view
                card.configure(cursor="hand2")
                def _go(e, k=key, s=sk, u=uk, ic=icon, sid=sensor_id):
                    self.show_metric_detail(k, s, u, ic, sid)
                for _w in card.winfo_children() + [card]:
                    _w.bind("<Button-1>", _go, add="+")
                # Also bind labels created after inn was packed
                for _w in inn.winfo_children() + [inn]:
                    _w.bind("<Button-1>", _go, add="+")

    # ── Full-screen metric detail view ────────────────────────────────────────
    def show_metric_detail(self, key, sk, uk, icon, sensor_id, edit_mode=False):
        if edit_mode:
            self._show_full_screen_edit(key, sk, uk, icon, sensor_id)
            return

        self.clr(); self._nav_bar()
        val  = self.session.get(key)
        unit = self.s(uk) if uk else ""
        name = self.s(sk)
        is_bmi = key == "BMI Calculation"

        # ── Header ────────────────────────────────────────────────────────
        bar = tk.Frame(self, bg=C["hdr"], height=max(self.sc(72), 60))
        bar.pack(fill="x"); bar.pack_propagate(False)

        self.btn(bar, "⬅  Back", self.show_dashboard,
                 bg=C["hdr2"], size=11).pack(side="left", padx=(self.sc(10), 0),
                                             pady=self.sc(10))
        tk.Label(bar, text=f"{icon}  {name}",
                 font=("Helvetica", self.sf(18), "bold"),
                 bg=C["hdr"], fg="white").pack(side="left", padx=self.sc(18))

        self.btn(bar, self.s("b_exit"), sys.exit,
                 bg="#991b1b", size=11).pack(side="right", padx=self.sc(14),
                                             pady=self.sc(10))
        if not is_bmi:
            self.btn(bar, "✎  Edit Reading",
                     lambda: self.show_metric_detail(key, sk, uk, icon, sensor_id,
                                                     edit_mode=True),
                     bg=C["grn"], size=11).pack(side="right", padx=self.sc(14),
                                                pady=self.sc(10))
        tk.Frame(self, bg=C["gld"], height=4).pack(fill="x")

        # ── Footer nav — "Next" lets the user step forward through every
        # metric in turn instead of having to return to the dashboard and
        # tap each card individually. Packed BEFORE body (side="bottom")
        # so it reserves its strip first and body fills the remaining space.
        foot = tk.Frame(self, bg=C["surface"], height=max(self.sc(58), 50))
        foot.pack(fill="x", side="bottom"); foot.pack_propagate(False)
        tk.Frame(foot, bg=C["bdr"], height=1).pack(fill="x", side="top")
        idx = next(i for i, m in enumerate(MODS) if m[0] == key)
        nxt_key, nxt_sk, nxt_uk, nxt_icon, nxt_sid = MODS[(idx + 1) % len(MODS)]
        self.btn(foot, f"Next: {nxt_icon}  {self.s(nxt_sk)}  ➡",
                 lambda: self.show_metric_detail(nxt_key, nxt_sk, nxt_uk, nxt_icon, nxt_sid),
                 bg=C["acc"], size=12, padx=self.sc(18), pady=self.sc(8)
                 ).place(relx=1.0, rely=0.5, anchor="e", x=-self.sc(14))

        # ── Body ──────────────────────────────────────────────────────────
        body = tk.Frame(self, bg=C["bg"]); body.pack(expand=True, fill="both")

        # ── LEFT: hero panel ──────────────────────────────────────────────
        left = tk.Frame(body, bg=C["hdr"], width=self.sc(340))
        left.pack(side="left", fill="y"); left.pack_propagate(False)

        tk.Frame(left, bg=C["hdr"], height=self.sc(36)).pack()
        tk.Label(left, text=icon, font=("Helvetica", self.sf(54)),
                 bg=C["hdr"], fg="white").pack()
        tk.Label(left, text=name, font=("Helvetica", self.sf(13), "bold"),
                 bg=C["hdr"], fg="#93c5fd").pack(pady=(self.sc(6), 0))

        tk.Frame(left, bg=C["hdr2"], height=1).pack(fill="x",
                 padx=self.sc(24), pady=self.sc(18))

        if val:
            disp_val = str(val).split("  (")[0] if is_bmi else str(val)
            status_txt, status_bg = self._metric_status(key, val)
        else:
            disp_val  = "—"
            status_txt, status_bg = "Not yet recorded", C["mut"]

        tk.Label(left, text=disp_val,
                 font=("Helvetica", self.sf(46), "bold"),
                 bg=C["hdr"], fg="white").pack()
        if unit:
            tk.Label(left, text=unit, font=("Helvetica", self.sf(15)),
                     bg=C["hdr"], fg="#93c5fd").pack()

        tk.Frame(left, bg=C["hdr"], height=self.sc(18)).pack()
        badge = tk.Frame(left, bg=status_bg)
        badge.pack(padx=self.sc(32), fill="x")
        tk.Label(badge, text=status_txt,
                 font=("Helvetica", self.sf(12), "bold"),
                 bg=status_bg, fg="white", pady=self.sc(6)).pack()

        tk.Frame(left, bg=C["hdr"]).pack(expand=True)
        ts = self.db_ts()
        if ts:
            tk.Label(left, text="Last recorded",
                     font=("Helvetica", self.sf(9)),
                     bg=C["hdr"], fg=C["mut"]).pack()
            tk.Label(left, text=ts,
                     font=("Helvetica", self.sf(10), "bold"),
                     bg=C["hdr"], fg="#93c5fd").pack(pady=(self.sc(2), self.sc(20)))

        # ── RIGHT: info panel ─────────────────────────────────────────────
        right = tk.Frame(body, bg=C["bg"]); right.pack(side="left", fill="both", expand=True)

        # Lancet dispenser — only relevant to blood glucose, since that's
        # the one reading that needs a finger prick before it can be taken.
        # Lives on the preview screen (not the edit screen) since it's a
        # prep step you'd want before deciding to take/edit a reading.
        if key == "Blood Glucose":
            lancet_row = tk.Frame(right, bg=C["bg"])
            lancet_row.pack(fill="x", padx=self.sc(28), pady=(self.sc(20), 0))
            lancet_lbl = tk.Label(lancet_row, text="",
                                  font=("Helvetica", self.sf(10), "bold"),
                                  bg=C["bg"], fg=C["acc"])

            def do_lancet():
                stop_spin = self._start_spinner(lancet_lbl, self.s("lancet_wait"))
                lancet_lbl.configure(fg=C["acc"])
                def run():
                    ok, _ = dispense_lancet()
                    def done():
                        stop_spin()
                        if ok:
                            lancet_lbl.configure(text=f"✓  {self.s('lancet_ok')}", fg=C["grn"])
                        else:
                            lancet_lbl.configure(text=self.s("lancet_fail"), fg=C["red"])
                    self.after(0, done)
                threading.Thread(target=run, daemon=True).start()

            self.btn(lancet_row, self.s("btn_lancet"), do_lancet,
                     bg=C["red"], size=12).pack(anchor="w")
            lancet_lbl.pack(anchor="w", pady=(self.sc(6), 0))

        self._show_metric_info(right, key, uk, val)

    # ── Full-screen edit ──────────────────────────────────────────────────────
    def _show_full_screen_edit(self, key, sk, uk, icon, sensor_id):
        """Full-screen editing view with content kept in the top half so the on-screen keyboard never covers it."""
        self.clr(); self._nav_bar()
        val  = self.session.get(key)
        unit = self.s(uk) if uk else ""
        name = self.s(sk)

        # ── Header ────────────────────────────────────────────────────────
        bar = tk.Frame(self, bg=C["hdr"], height=max(self.sc(72), 60))
        bar.pack(fill="x"); bar.pack_propagate(False)

        self.btn(bar, "⬅  Cancel",
                 lambda: self.show_metric_detail(key, sk, uk, icon, sensor_id),
                 bg=C["hdr2"], size=11).pack(side="left", padx=(self.sc(10), 0),
                                             pady=self.sc(10))
        tk.Label(bar, text=f"{icon}  Edit  {name}",
                 font=("Helvetica", self.sf(17), "bold"),
                 bg=C["hdr"], fg="white").pack(side="left", padx=self.sc(16))
        self.btn(bar, self.s("b_exit"), sys.exit,
                 bg="#991b1b", size=11).pack(side="right", padx=self.sc(14),
                                             pady=self.sc(10))
        tk.Frame(self, bg=C["gld"], height=4).pack(fill="x")

        # ── Body — everything packed near the TOP so keyboard can't reach it ──
        body = tk.Frame(self, bg=C["bg"]); body.pack(fill="both", expand=True)

        # Horizontally-centered column, anchored to top
        col = tk.Frame(body, bg=C["bg"])
        col.pack(anchor="n", padx=self.sc(60), pady=self.sc(28), fill="x")

        # Current value summary
        top_row = tk.Frame(col, bg=C["bg"]); top_row.pack(fill="x", pady=(0, self.sc(18)))
        tk.Label(top_row, text=icon, font=("Helvetica", self.sf(30)),
                 bg=C["bg"]).pack(side="left", padx=(0, self.sc(14)))
        info_col = tk.Frame(top_row, bg=C["bg"]); info_col.pack(side="left")
        tk.Label(info_col, text=name,
                 font=("Helvetica", self.sf(15), "bold"),
                 bg=C["bg"], fg=C["txt"]).pack(anchor="w")
        if val:
            raw_v = str(val).split("  (")[0]
            st, sbg = self._metric_status(key, val)
            tk.Label(info_col, text=f"Current: {raw_v} {unit}".strip(),
                     font=("Helvetica", self.sf(12)),
                     bg=C["bg"], fg=C["sub"]).pack(anchor="w")
            status_row = tk.Frame(info_col, bg=C["bg"])
            status_row.pack(anchor="w", pady=(self.sc(3), 0))
            tk.Frame(status_row, bg=sbg,
                     width=self.sc(10), height=self.sc(10)).pack(side="left",
                                                                  padx=(0, self.sc(5)))
            tk.Label(status_row, text=st,
                     font=("Helvetica", self.sf(10), "bold"),
                     bg=C["bg"], fg=sbg).pack(side="left")
        else:
            tk.Label(info_col, text="No reading recorded yet",
                     font=("Helvetica", self.sf(12)),
                     bg=C["bg"], fg=C["mut"]).pack(anchor="w")

        # Prompt label
        prompt = "Enter new value" + (f"  ({unit})" if unit else "") + ":"
        tk.Label(col, text=prompt,
                 font=("Helvetica", self.sf(12), "bold"),
                 bg=C["bg"], fg=C["sub"]).pack(anchor="w", pady=(0, self.sc(6)))
        if key == "Blood Pressure":
            tk.Label(col, text="Format: systolic / diastolic  — e.g.  120/80",
                     font=("Helvetica", self.sf(10), "italic"),
                     bg=C["bg"], fg=C["mut"]).pack(anchor="w", pady=(0, self.sc(6)))

        # Entry field
        wrap = tk.Frame(col, bg=C["acc"], padx=2, pady=2)
        wrap.pack(fill="x")
        ent = tk.Entry(wrap, font=("Helvetica", self.sf(24), "bold"),
                       bg=C["s2"], fg=C["txt"], relief="flat", bd=0,
                       insertbackground=C["acc"])
        ent.pack(fill="x", ipady=self.sc(14), ipadx=self.sc(12))
        ent.bind("<FocusIn>",  lambda e: wrap.configure(bg=C["acc"]))
        ent.bind("<FocusOut>", lambda e: wrap.configure(bg=C["bdr"]))
        if val:
            ent.insert(0, str(val).split("  (")[0])
            ent.selection_range(0, tk.END)
        ent.focus_set()

        # Inline error
        err_lbl = tk.Label(col, text="",
                           font=("Helvetica", self.sf(10)),
                           bg=C["bg"], fg=C["red"])
        err_lbl.pack(anchor="w", pady=(self.sc(5), 0))

        # Normal range hint chip
        desc = self._metric_desc(key)
        if desc and desc.get("ranges"):
            nrm = next((r for r in desc["ranges"] if r[1] == C["grn"]), None)
            if nrm:
                chip = tk.Frame(col, bg=C["grn_lt"])
                chip.pack(fill="x", pady=(self.sc(8), 0))
                tk.Label(chip, text=f"✓  Normal range:  {nrm[2]}",
                         font=("Helvetica", self.sf(10), "bold"),
                         bg=C["grn_lt"], fg=C["grn"],
                         pady=self.sc(5)).pack(anchor="w", padx=self.sc(10))

        # Action buttons
        tk.Frame(col, bg=C["bg"], height=self.sc(16)).pack()
        btn_row = tk.Frame(col, bg=C["bg"]); btn_row.pack(fill="x")

        def do_save():
            raw = ent.get().strip()
            if not raw:
                err_lbl.configure(text="Please enter a value."); return
            if key != "Blood Pressure":
                try: float(raw)
                except ValueError:
                    err_lbl.configure(text="Please enter a valid number."); return
            self.session[key] = raw
            self.calc_bmi()
            self._hide_keyboard()
            self.show_metric_detail(key, sk, uk, icon, sensor_id)

        self.btn(btn_row, "💾  Save", do_save,
                 bg=C["grn"], size=14).pack(side="left", padx=(0, self.sc(12)))
        self.btn(btn_row, "✕  Cancel",
                 lambda: self.show_metric_detail(key, sk, uk, icon, sensor_id),
                 bg=C["surface"], fg=C["sub"], size=13).pack(side="left")

        # Sensor section
        if sensor_id:
            tk.Frame(col, bg=C["bdr"], height=1).pack(fill="x", pady=self.sc(16))
            sensor_lbl = tk.Label(col, text="",
                                  font=("Helvetica", self.sf(10), "bold"),
                                  bg=C["bg"], fg=C["acc"])

            def do_sensor():
                stop_spin = self._start_spinner(sensor_lbl, self.s("sensor_wait"))
                sensor_lbl.configure(fg=C["acc"])
                ent.configure(state="disabled")
                def run():
                    v, _ = read_sensor(sensor_id)
                    def done():
                        stop_spin()
                        ent.configure(state="normal")
                        if v:
                            ent.delete(0, tk.END); ent.insert(0, v)
                            sensor_lbl.configure(
                                text=f"✓  Sensor read: {v} {unit}".strip(),
                                fg=C["grn"])
                            # Auto-save the reading right away — no need for
                            # the user to also tap Save after a sensor read.
                            do_save()
                        else:
                            sensor_lbl.configure(
                                text="Sensor read failed — enter manually.",
                                fg=C["red"])
                    self.after(0, done)
                threading.Thread(target=run, daemon=True).start()

            self.btn(col, "🔌  Read from Sensor", do_sensor,
                     bg=C["acc"], size=12).pack(anchor="w")
            sensor_lbl.pack(anchor="w", pady=(self.sc(6), 0))

        ent.bind("<Return>", lambda e: do_save())

    def _show_metric_info(self, parent, key, uk, val):
        """Scrollable info + history panel for the metric detail view."""
        canvas = tk.Canvas(parent, bg=C["bg"], highlightthickness=0)
        vsb    = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        content = tk.Frame(canvas, bg=C["bg"])
        cwin = canvas.create_window((0, 0), window=content, anchor="nw")

        def sync_scrollregion():
            # Compute the needed height directly from the content frame's
            # own requested size rather than trusting the canvas's internal
            # tracking of the embedded window item (which can lag behind
            # after a burst of pack()/pack_forget() calls, like expanding
            # the "past readings" toggle) or a Configure event's possibly
            # stale e.height. This is what the toggle in
            # _draw_metric_history calls directly after it changes content.
            content.update_idletasks()
            w = max(canvas.winfo_width(), 1)
            h = content.winfo_reqheight()
            canvas.itemconfig(cwin, width=w)
            canvas.configure(scrollregion=(0, 0, w, h + self.sc(120)))
            # Re-apply touch/drag-scroll to any newly added widgets too
            # (e.g. rows revealed by the "past readings" toggle) — see
            # _bind_scroll_recursive for why this is needed at all.
            self._bind_scroll_recursive(content, canvas)

        # Expose for _draw_metric_history's expand/collapse toggle to call
        # directly — it can't reach this closure otherwise.
        self._mi_sync_scrollregion = sync_scrollregion

        content.bind("<Configure>", lambda e: sync_scrollregion())
        canvas.bind("<Configure>",  lambda e: sync_scrollregion())

        canvas.bind("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta/120), "units"))
        canvas.bind("<Button-4>",   lambda e: canvas.yview_scroll(-1, "units"))
        canvas.bind("<Button-5>",   lambda e: canvas.yview_scroll(1,  "units"))
        canvas.bind("<ButtonPress-1>", lambda e: canvas.scan_mark(e.x, e.y))
        canvas.bind("<B1-Motion>",     lambda e: canvas.scan_dragto(e.x, e.y, gain=1))

        P = self.sc(28)

        if val and self._metric_has_range(key):
            tk.Frame(content, bg=C["bg"], height=self.sc(4)).pack()
            tk.Label(content, text="READING LEVEL",
                     font=("Helvetica", self.sf(10), "bold"),
                     bg=C["bg"], fg=C["sub"]).pack(anchor="w", padx=P, pady=(P, self.sc(6)))
            self._draw_metric_range_bar(content, key, val, P)

        desc = self._metric_desc(key)
        if desc:
            tk.Frame(content, bg=C["bdr"], height=1).pack(fill="x", padx=P, pady=self.sc(18))
            tk.Label(content, text="ABOUT THIS MEASUREMENT",
                     font=("Helvetica", self.sf(10), "bold"),
                     bg=C["bg"], fg=C["sub"]).pack(anchor="w", padx=P, pady=(0, self.sc(8)))
            tk.Label(content, text=desc["text"],
                     font=("Helvetica", self.sf(12)),
                     bg=C["bg"], fg=C["txt"],
                     wraplength=self.sc(520), justify="left").pack(anchor="w", padx=P)
            if desc.get("ranges"):
                tk.Frame(content, bg=C["bg"], height=self.sc(12)).pack()
                for label, rcolor, rtext in desc["ranges"]:
                    row = tk.Frame(content, bg=C["bg"]); row.pack(anchor="w", padx=P, pady=2)
                    tk.Frame(row, bg=rcolor, width=self.sc(12),
                             height=self.sc(12)).pack(side="left", padx=(0, self.sc(8)))
                    tk.Label(row, text=f"{label}:  {rtext}",
                             font=("Helvetica", self.sf(11)),
                             bg=C["bg"], fg=C["txt"]).pack(side="left")

        tk.Frame(content, bg=C["bdr"], height=1).pack(fill="x", padx=P, pady=self.sc(18))
        tk.Label(content, text="RECENT READINGS",
                 font=("Helvetica", self.sf(10), "bold"),
                 bg=C["bg"], fg=C["sub"]).pack(anchor="w", padx=P, pady=(0, self.sc(10)))
        self._draw_metric_history(content, key, uk, P)

        # Large bottom spacer so the last row is never clipped at the edge
        tk.Frame(content, bg=C["bg"], height=self.sc(120)).pack()

    # ── Detail helpers ─────────────────────────────────────────────────────────

    _STATUS_FIL = {
        "⚠  Dangerously Low": "⚠  Mapanganib na Mababa", "Below Normal": "Mas Mababa sa Normal",
        "✓  Normal": "✓  Normal", "Low Fever": "Bahagyang Lagnat", "Fever": "May Lagnat",
        "⚠  Low (Hypotension)": "⚠  Mababa (Hypotension)", "Elevated": "Medyo Mataas",
        "High  –  Stage 1": "Mataas  –  Stage 1", "High  –  Stage 2": "Mataas  –  Stage 2",
        "⚠  Low (Hypoglycemia)": "⚠  Mababa (Hypoglycemia)",
        "Prediabetes Range": "Saklaw ng Prediabetes", "Diabetes Range": "Saklaw ng Diabetes",
        "✓  Recorded": "✓  Naitala",
    }

    def _metric_status(self, key, val):
        """(status_label, colour) in the active language — chips, detail screen and history all use this."""
        label, color = self._metric_status_en(key, val)
        if self.lang == "FIL":
            label = self._STATUS_FIL.get(label, label)
        return label, color

    def _metric_status_en(self, key, val):
        """Return (status_label, bg_color) for a metric value."""
        try:
            if key == "Body Temperature":
                v = float(val)
                if v < 35.0:  return "⚠  Dangerously Low", "#1e40af"
                if v < 36.1:  return "Below Normal",        "#0369a1"
                if v <= 37.2: return "✓  Normal",           C["grn"]
                if v <= 38.0: return "Low Fever",            C["gld"]
                return "Fever",                              C["red"]

            if key == "Blood Pressure":
                sys_v = float(str(val).split("/")[0])
                if sys_v < 90:  return "⚠  Low (Hypotension)", "#0369a1"
                if sys_v < 120: return "✓  Normal",             C["grn"]
                if sys_v < 130: return "Elevated",               C["gld"]
                if sys_v < 140: return "High  –  Stage 1",      "#ea580c"
                return "High  –  Stage 2",                       C["red"]

            if key == "Blood Glucose":
                v = float(val)
                if v < 70:  return "⚠  Low (Hypoglycemia)", "#0369a1"
                if v <= 99: return "✓  Normal",              C["grn"]
                if v <= 125:return "Prediabetes Range",       C["gld"]
                return "Diabetes Range",                      C["red"]

            if key == "BMI Calculation":
                v = float(str(val).split()[0])
                if v < 18.5: return self.s("under"), "#0369a1"
                if v < 25.0: return f"✓  {self.s('norm')}", C["grn"]
                if v < 30.0: return self.s("over"),  C["gld"]
                return self.s("obese"),               C["red"]

            if key in ("Height", "Weight"):
                return "✓  Recorded", C["grn"]
        except Exception:
            pass
        return "Unknown", C["mut"]

    def _metric_has_range(self, key):
        return key in ("Body Temperature", "Blood Glucose", "BMI Calculation", "Blood Pressure")

    def _draw_metric_range_bar(self, parent, key, val, padx):
        """Draw a color-zoned horizontal bar with a value marker."""
        ZONES = {
            "Body Temperature": {
                "min": 34.5, "max": 40.5, "unit": "°C",
                "zones": [
                    (34.5, 36.1, "#0369a1", "Low"),
                    (36.1, 37.2, C["grn"],  "Normal"),
                    (37.2, 38.0, C["gld"],  "Fever"),
                    (38.0, 40.5, C["red"],  "High Fever"),
                ]},
            "Blood Glucose": {
                "min": 40, "max": 200, "unit": "mg/dL",
                "zones": [
                    (40,  70,  "#0369a1", "Low"),
                    (70,  100, C["grn"],  "Normal"),
                    (100, 126, C["gld"],  "Prediabetes"),
                    (126, 200, C["red"],  "Diabetes"),
                ]},
            "BMI Calculation": {
                "min": 10, "max": 40, "unit": "BMI",
                "zones": [
                    (10,   18.5, "#0369a1", "Under"),
                    (18.5, 25,   C["grn"],  "Normal"),
                    (25,   30,   C["gld"],  "Over"),
                    (30,   40,   C["red"],  "Obese"),
                ]},
            "Blood Pressure": {
                "min": 60, "max": 180, "unit": "mmHg",
                "zones": [
                    (60,  90,  "#0369a1", "Low"),
                    (90,  120, C["grn"],  "Normal"),
                    (120, 130, C["gld"],  "Elevated"),
                    (130, 140, "#ea580c", "High 1"),
                    (140, 180, C["red"],  "High 2"),
                ]},
        }
        info = ZONES.get(key)
        if not info:
            return
        try:
            if key == "BMI Calculation":
                v = float(str(val).split()[0])
            elif key == "Blood Pressure":
                v = float(str(val).split("/")[0])
            else:
                v = float(val)
        except Exception:
            return

        BH  = self.sc(22)   # bar height
        TH  = self.sc(24)   # label row height below bar
        PTH = self.sc(12)   # pointer triangle height

        c = tk.Canvas(parent, bg=C["bg"], height=BH + PTH + TH,
                      highlightthickness=0)
        c.pack(fill="x", padx=padx, pady=(0, self.sc(6)))

        mn, mx = info["min"], info["max"]
        zones  = info["zones"]

        def draw(event=None):
            c.delete("all")
            W = c.winfo_width()
            if W < 20:
                return

            # Color zone rectangles
            for z0, z1, zc, _ in zones:
                x0 = (z0 - mn) / (mx - mn) * W
                x1 = (z1 - mn) / (mx - mn) * W
                c.create_rectangle(x0, 0, x1, BH, fill=zc, outline="")

            # Value marker line
            px = max(2, min(W - 2, (v - mn) / (mx - mn) * W))
            c.create_line(px, 0, px, BH, fill="white", width=3)

            # Pointer triangle below bar
            tp = self.sc(7)
            c.create_polygon(px - tp, BH + 2, px + tp, BH + 2, px, BH + PTH,
                             fill="white", outline="")

            # Zone labels
            for z0, z1, _, zlbl in zones:
                cx = ((z0 + z1) / 2 - mn) / (mx - mn) * W
                c.create_text(cx, BH + PTH + self.sc(4),
                              text=zlbl, font=("Helvetica", self.sf(8), "bold"),
                              fill=C["sub"], anchor="n")

        c.bind("<Configure>", lambda e: draw())
        parent.after(60, draw)

    def _metric_desc(self, key):
        """Return description dict for a metric."""
        grn, gld, red, blu = C["grn"], C["gld"], C["red"], "#0369a1"
        descs = {
            "Body Temperature": {
                "text": (
                    "Body temperature is a measure of your body's ability to generate and "
                    "release heat. A normal temperature indicates the body is maintaining "
                    "proper thermoregulation."
                ),
                "ranges": [
                    ("Below Normal", blu, "Below 36.1°C"),
                    ("Normal",       grn, "36.1°C – 37.2°C"),
                    ("Low Fever",    gld, "37.2°C – 38.0°C"),
                    ("Fever",        red, "Above 38.0°C"),
                ],
            },
            "Blood Pressure": {
                "text": (
                    "Blood pressure is the force of blood pushing against the walls of your "
                    "arteries. It is measured as two numbers: systolic (pressure when the "
                    "heart beats) over diastolic (pressure when the heart rests between beats)."
                ),
                "ranges": [
                    ("Low",         blu,     "Below 90/60 mmHg"),
                    ("Normal",      grn,     "Below 120/80 mmHg"),
                    ("Elevated",    gld,     "120–129 / below 80 mmHg"),
                    ("High Stg 1",  "#ea580c","130–139 / 80–89 mmHg"),
                    ("High Stg 2",  red,     "140+ / 90+ mmHg"),
                ],
            },
            "Blood Glucose": {
                "text": (
                    "Blood glucose measures the amount of glucose (sugar) in your bloodstream. "
                    "These readings are typically taken after fasting for at least 8 hours, "
                    "since eating raises glucose levels temporarily."
                ),
                "ranges": [
                    ("Low",          blu, "Below 70 mg/dL"),
                    ("Normal",       grn, "70 – 99 mg/dL"),
                    ("Prediabetes",  gld, "100 – 125 mg/dL"),
                    ("Diabetes",     red, "126 mg/dL and above"),
                ],
            },
            "Height": {
                "text": (
                    "Height is recorded in centimeters (cm) and used together with weight to "
                    "calculate your Body Mass Index (BMI). Accurate height measurement helps "
                    "track growth and assess healthy weight ranges for your body size."
                ),
                "ranges": None,
            },
            "Weight": {
                "text": (
                    "Weight is recorded in kilograms (kg) and used together with height to "
                    "calculate BMI. Weight alone doesn't determine health — body composition, "
                    "age, and other factors also matter. Track weight over time for meaningful trends."
                ),
                "ranges": None,
            },
            "BMI Calculation": {
                "text": (
                    "Body Mass Index (BMI) is a measure calculated from your height and weight. "
                    "It provides a simple screening tool for weight categories that may lead to "
                    "health problems, but it is not a diagnostic tool."
                ),
                "ranges": [
                    ("Underweight", blu, "Below 18.5"),
                    ("Normal",      grn, "18.5 – 24.9"),
                    ("Overweight",  gld, "25.0 – 29.9"),
                    ("Obese",       red, "30.0 and above"),
                ],
            },
        }
        return descs.get(key)

    def _draw_metric_history(self, parent, key, uk, padx):
        """Latest reading always visible; past readings in a collapsible block."""
        col_map = {
            "Body Temperature": "temp",
            "Blood Pressure":   "bp",
            "Blood Glucose":    "glucose",
            "Height":           "height",
            "Weight":           "weight",
            "BMI Calculation":  "bmi",
        }
        db_col = col_map.get(key)
        if not db_col:
            return

        with sqlite3.connect(DB) as con:
            cur = con.cursor()
            cur.execute(
                f"SELECT {db_col}, timestamp FROM health_records "
                f"WHERE name=? AND {db_col} IS NOT NULL "
                f"ORDER BY timestamp DESC LIMIT 3",
                (self.user,)
            )
            rows = cur.fetchall()

        if not rows:
            tk.Label(parent, text="No past readings on record.",
                     font=("Helvetica", self.sf(12)),
                     bg=C["bg"], fg=C["mut"]).pack(anchor="w", padx=padx)
            return

        unit = self.s(uk) if uk else ""

        def build_row(val_r, ts_r, badge=None):
            """Build a row frame inside parent WITHOUT packing it."""
            _, sbg = self._metric_status(key, val_r)
            row = tk.Frame(parent, bg=C["surface"],
                           highlightbackground=C["bdr"], highlightthickness=1)
            tk.Frame(row, bg=sbg, width=self.sc(6)).pack(side="left", fill="y")
            inner = tk.Frame(row, bg=C["surface"])
            inner.pack(side="left", fill="both", expand=True,
                       padx=self.sc(12), pady=self.sc(10))
            tk.Label(inner, text=ts_r,
                     font=("Helvetica", self.sf(10)),
                     bg=C["surface"], fg=C["sub"]).pack(side="left")
            if badge:
                tk.Label(inner, text=badge,
                         font=("Helvetica", self.sf(9), "bold"),
                         bg=C["grn_lt"], fg=C["grn"],
                         padx=self.sc(6)).pack(side="left", padx=(self.sc(8), 0))
            tk.Label(inner,
                     text=f"{val_r}  {unit}".strip(),
                     font=("Helvetica", self.sf(13), "bold"),
                     bg=C["surface"], fg=C["txt"]).pack(side="right")
            return row

        # ── Latest reading — always shown ─────────────────────────────────
        latest = build_row(rows[0][0], rows[0][1], badge="Latest")
        latest.pack(fill="x", padx=padx, pady=(0, 3))

        if len(rows) < 2:
            return

        # ── Past readings — pre-built but NOT packed yet ──────────────────
        past = rows[1:]
        past_widgets = [build_row(v, t) for v, t in past]

        expanded = [False]

        # Toggle bar
        toggle = tk.Frame(parent, bg=C["acc_lt"], cursor="hand2")
        toggle.pack(fill="x", padx=padx, pady=(4, 0))
        lbl = tk.Label(toggle,
                       text=f"▼   Show {len(past)} past reading{'s' if len(past)!=1 else ''}",
                       font=("Helvetica", self.sf(11), "bold"),
                       bg=C["acc_lt"], fg=C["acc"], pady=self.sc(8))
        lbl.pack()

        def do_toggle(e=None):
            if expanded[0]:
                for w in past_widgets:
                    w.pack_forget()
                lbl.configure(
                    text=f"▼   Show {len(past)} past reading{'s' if len(past)!=1 else ''}")
                expanded[0] = False
            else:
                # Pack each row individually before the toggle bar
                for w in past_widgets:
                    w.pack(fill="x", padx=padx, pady=3, before=toggle)
                lbl.configure(text="▲   Hide past readings")
                expanded[0] = True

            # Force the scrollable area to immediately match the new
            # content size. Relying only on the canvas's own <Configure>
            # tracking of the embedded window item can lag behind a burst
            # of pack()/pack_forget() calls like this — calling the same
            # direct, explicit sync used elsewhere guarantees the newly
            # revealed (or hidden) rows are scrollable into view right away.
            sync = getattr(self, "_mi_sync_scrollregion", None)
            if sync:
                sync()

        toggle.bind("<Button-1>", do_toggle)
        lbl.bind("<Button-1>",    do_toggle)

    # ── Save ──────────────────────────────────────────────────────────────────
    def _save(self):
        self.calc_bmi()
        s = self.session; now = datetime.now().strftime("%Y-%m-%d %H:%M")
        try:
            with sqlite3.connect(DB) as c:
                c.execute('INSERT INTO health_records '
                          '(name,temp,bp,glucose,height,weight,bmi,timestamp) VALUES (?,?,?,?,?,?,?,?)',
                          (self.user, s["Body Temperature"], s["Blood Pressure"],
                           s["Blood Glucose"], s["Height"], s["Weight"],
                           s["BMI Calculation"], now))
            if firebase_bridge:
                firebase_bridge.push_record(self.user, {
                    "temp": s["Body Temperature"], "bp": s["Blood Pressure"],
                    "glucose": s["Blood Glucose"], "height": s["Height"],
                    "weight": s["Weight"], "bmi": s["BMI Calculation"], "timestamp": now})
            self._alert("info", self.s("ok"))
            self.update_mode = False; self.db_load(); self.show_dashboard()
            return True
        except Exception as e:
            self._alert("error", self.s("e_db") + str(e))
            return False

    # ── Print ─────────────────────────────────────────────────────────────────
    def _do_print(self):
        ts   = self.db_ts() or datetime.now().strftime("%Y-%m-%d %H:%M")
        path = make_pdf(self.user, self.gender, self.session, ts)
        try:
            open_pdf(path)
            self._alert("info", self.s("p_ok"))
        except Exception as e:
            self._alert("error", str(e))

    # ── Email ─────────────────────────────────────────────────────────────────
    def _do_email(self):
        # Check SMTP is configured
        if not EMAIL_SENDER or not EMAIL_PASSWORD:
            self._alert("warning", self.s("email_cfg")); return

        # Determine recipient — use saved email or let user type one
        to_addr = self.email.strip()
        if not to_addr:
            # Prompt the user to enter an email ad hoc
            to_addr = self._ask_string(
                self.s("b_email"),
                "Enter email address to send the record to:"
            )
            if not to_addr or not to_addr.strip():
                return
            to_addr = to_addr.strip()

        # Show a sending popup
        pop = self._popup(self.s("b_email"), 360, 160)
        pop.configure(bg=C["bg"])
        tk.Frame(pop, bg=C["acc"], height=self.sc(6)).pack(fill="x")
        body = tk.Frame(pop, bg=C["bg"]); body.pack(expand=True)
        tk.Label(body, text="📧", font=("Helvetica", self.sf(28)),
                 bg=C["bg"]).pack(pady=(self.sc(10), self.sc(4)))
        status_lbl = tk.Label(body, text=self.s("email_sending"),
                              font=("Helvetica", self.sf(12)),
                              bg=C["bg"], fg=C["sub"])
        status_lbl.pack()

        ts = self.db_ts() or datetime.now().strftime("%Y-%m-%d %H:%M")
        result = [None, None]
        stop_spin = self._start_spinner(status_lbl, self.s("email_sending"))

        def do_send():
            ok, err = send_email_report(to_addr, self.user, self.gender, self.session, ts)
            result[0], result[1] = ok, err
            self.after(0, on_done)

        def on_done():
            stop_spin()
            pop.destroy()
            if result[0]:
                self._alert("info", self.s("email_ok").format(email=to_addr))
            else:
                if result[1] == "not_configured":
                    self._alert("warning", self.s("email_cfg"))
                else:
                    self._alert("error", self.s("email_fail").format(err=result[1]))

        threading.Thread(target=do_send, daemon=True).start()

    # ── QR card popup ─────────────────────────────────────────────────────────
    def _show_qr(self):
        pop = self._popup(f"QR Code  —  {format_display_name(self.user)}", 310, 420)
        pop.configure(bg=C["surface"])
        tk.Frame(pop, bg=C["acc"], height=self.sc(6)).pack(fill="x")
        tk.Label(pop, text=self.s("b_myqr"), font=("Helvetica", self.sf(14), "bold"),
                 bg=C["surface"], fg=C["txt"]).pack(pady=(self.sc(18), self.sc(4)))
        tk.Label(pop, text="Show this at the kiosk to log in instantly.",
                 font=("Helvetica", self.sf(11)), bg=C["surface"], fg=C["sub"]).pack()
        qr_size = self.sc(220)
        try:
            ph  = ImageTk.PhotoImage(qr_pil(self.user, qr_size))
            lbl = tk.Label(pop, image=ph, bg=C["surface"])
            lbl.image = ph; lbl.pack(pady=self.sc(12))
        except Exception as e:
            tk.Label(pop, text=str(e), bg=C["surface"], fg=C["red"]).pack(pady=self.sc(12))
        tk.Label(pop, text=format_display_name(self.user), font=("Helvetica", self.sf(12), "bold"),
                 bg=C["surface"], fg=C["acc"]).pack()
        self.btn(pop, "Close", pop.destroy,
                 size=12, padx=self.sc(20), pady=self.sc(5)).pack(pady=self.sc(14))

    # ── Health record history popup ─────────────────────────────────────────

    def _show_history(self):
        display_name = format_display_name(self.user)
        pop = self._popup(f"{self.s('hist_title')}  —  {display_name}", 560, 520)
        pop.configure(bg=C["s2"])
        # Header bar
        hdr = tk.Frame(pop, bg=C["hdr"]);
        hdr.pack(fill="x")
        hin = tk.Frame(hdr, bg=C["hdr"]);
        hin.pack(fill="x", padx=self.sc(20), pady=self.sc(12))
        tk.Label(hin, text=f"📜  {self.s('hist_title')}", font=("Helvetica", self.sf(13), "bold"),
                    bg=C["hdr"], fg="white").pack(anchor="w")
        tk.Label(hin, text=display_name, font=("Helvetica", self.sf(10)),
                    bg=C["hdr"], fg="#93c5fd").pack(anchor="w", pady=(2, 0))

        # Scrollable list of records
        body = self._scroll_container(pop, bg=C["s2"])

        with sqlite3.connect(DB) as c:
            cur = c.cursor()
            cur.execute('SELECT temp,bp,glucose,height,weight,bmi,timestamp FROM health_records '
                        'WHERE name=? ORDER BY timestamp DESC', (self.user,))
            rows = cur.fetchall()

        if not rows:
            tk.Label(body, text=self.s("hist_norec"), font=("Helvetica", self.sf(11)),
                        bg=C["s2"], fg=C["mut"]).pack(pady=self.sc(30))
        else:
            for i, row in enumerate(rows):
                vals, ts = row[:6], row[6]
                rec = tk.Frame(body, bg=C["surface"],
                                highlightbackground=C["bdr"], highlightthickness=1)
                rec.pack(fill="x", pady=(0, self.sc(10)))

                rh = tk.Frame(rec, bg=C["strip"]);
                rh.pack(fill="x")
                tk.Label(rh, text=f"📅  {ts}", font=("Helvetica", self.sf(11), "bold"),
                            bg=C["strip"], fg=C["txt"]).pack(side="left", padx=self.sc(12), pady=self.sc(6))
                if i == 0:
                    tk.Label(rh, text=self.s("hist_latest"), font=("Helvetica", self.sf(9), "bold"),
                                bg=C["grn_lt"], fg=C["grn"], padx=self.sc(8), pady=1
                                ).pack(side="right", padx=self.sc(12), pady=self.sc(6))

                gf = tk.Frame(rec, bg=C["surface"]);
                gf.pack(fill="x", padx=self.sc(12), pady=self.sc(10))
                COLS = 3
                for ci, (key, sk, uk, icon, _sid) in enumerate(MODS):
                    val = vals[ci]
                    is_bmi = key == "BMI Calculation"
                    # Soft pastel BMI theme for the cell background/text —
                    # the displayed label still uses our own translated
                    # under/norm/over/obese strings (bilingual-aware),
                    # just colored via the theme rather than plain gold.
                    theme = get_bmi_theme(val) if (is_bmi and val) else None
                    if is_bmi and val:
                        try:
                            b = float(val)
                            lbl = (self.s("under") if b < 18.5 else self.s("norm") if b < 25
                            else self.s("over") if b < 30 else self.s("obese"))
                            disp = f"{val}  ({lbl})"
                        except Exception:
                            disp = val
                    else:
                        unit = self.s(uk) if uk else ""
                        disp = f"{val}  {unit}".strip() if val else "—"
                    cell_bg = theme["bg"] if theme else C["s2"]
                    fgv = (theme["fg"] if theme else
                           (C["gld"] if is_bmi else C["grn"]) if val else C["mut"])
                    r, cidx = divmod(ci, COLS)
                    cell = tk.Frame(gf, bg=cell_bg, padx=8, pady=4)
                    cell.grid(row=r, column=cidx, padx=3, pady=2, sticky="ew")
                    gf.grid_columnconfigure(cidx, weight=1)
                    tk.Label(cell, text=f"{icon}  {self.s(sk)}", font=("Helvetica", self.sf(8)),
                                bg=cell_bg, fg=C["sub"]).pack(anchor="w")
                    tk.Label(cell, text=disp, font=("Helvetica", self.sf(11), "bold"),
                                bg=cell_bg, fg=fgv).pack(anchor="w")

        self.btn(pop, "Close", pop.destroy,
                    bg=C["red"], size=12, padx=self.sc(20), pady=self.sc(5)
                    ).pack(side="bottom", pady=self.sc(12))

    # ══════════════════════════════════════════════════════════════════════════
    # ── ADMIN PANEL ───────────────────────────────────────────────────────────
    # Access : triple-click the "SENTRO GINHAWA" title in the header.
    # Password: Badinger   ← change ADMIN_PASSWORD to whatever you like
    # ══════════════════════════════════════════════════════════════════════════
    ADMIN_PASSWORD = "SentroG"

    def _admin_login(self):
        pop = self._popup("Admin Login", 420, 250)
        pop.focus_set()
        tk.Frame(pop, bg=C["hdr"], height=self.sc(6)).pack(fill="x")
        body = tk.Frame(pop, bg=C["bg"]); body.pack(expand=True, padx=self.sc(40), pady=self.sc(20))
        tk.Label(body, text="\U0001f512  Admin Access", font=("Helvetica", self.sf(16), "bold"),
                 bg=C["bg"], fg=C["hdr"]).pack(anchor="w")
        tk.Label(body, text="Enter the administrator password to continue.",
                 font=("Helvetica", self.sf(11)), bg=C["bg"], fg=C["sub"]).pack(anchor="w", pady=(self.sc(4),self.sc(14)))
        pw_var = tk.StringVar()
        pw_ent = tk.Entry(body, textvariable=pw_var, show="•",
                          font=("Helvetica", self.sf(14)), bg=C["s2"], fg=C["txt"],
                          relief="flat", bd=0, insertbackground=C["acc"])
        pw_ent.pack(fill="x", ipady=self.sc(10), ipadx=self.sc(8)); pw_ent.focus()
        err = tk.Label(body, text="", font=("Helvetica", self.sf(10)), bg=C["bg"], fg=C["red"])
        err.pack(anchor="w", pady=(self.sc(4), 0))
        def attempt(event=None):
            if pw_var.get() == self.ADMIN_PASSWORD:
                pop.destroy(); self.show_admin()
            else:
                err.configure(text="Incorrect password. Please try again."); pw_var.set("")
        pw_ent.bind("<Return>", attempt)
        row = tk.Frame(body, bg=C["bg"]); row.pack(fill="x", pady=(self.sc(10), 0))
        self.btn(row, "Enter \u2192", attempt, bg=C["hdr"],
                 size=12, padx=self.sc(16), pady=self.sc(6)).pack(side="left", padx=(0, self.sc(10)))
        self.btn(row, "Cancel", pop.destroy,
                 bg=C["surface"], fg=C["sub"], size=11).pack(side="left")

    def show_admin(self):
        self._screen = "admin"; self.clr()

        # Header
        bar = tk.Frame(self, bg=C["hdr"], height=self.sc(66))
        bar.pack(fill="x"); bar.pack_propagate(False)
        bl = tk.Frame(bar, bg=C["hdr"]); bl.pack(side="left", padx=(self.sc(18), 0))
        tk.Label(bl, text="\U0001f6e1  ADMIN PANEL", font=("Helvetica", self.sf(18), "bold"),
                 bg=C["hdr"], fg="white").pack(side="left")
        tk.Label(bl, text="   Resident & Health Record Management",
                 font=("Helvetica", self.sf(11)), bg=C["hdr"], fg="#93c5fd").pack(side="left")
        R = tk.Frame(bar, bg=C["hdr"]); R.pack(side="right", padx=self.sc(14))
        def hbtn(text, cmd, bg):
            self.btn(R, text, cmd, bg=bg, size=11,
                     padx=max(self.sc(12), 10), pady=max(self.sc(5), 6)
                     ).pack(side="left", padx=3)
        hbtn("\u2190 Exit Admin", self.show_welcome, C["hdr2"])
        hbtn(self.s("b_exit"), sys.exit, "#991b1b")
        tk.Frame(self, bg=C["red"], height=3).pack(fill="x")

        body = tk.Frame(self, bg=C["bg"]); body.pack(expand=True, fill="both")

        # LEFT — resident list
        left = tk.Frame(body, bg=C["surface"], width=self.sc(300))
        left.pack(side="left", fill="y"); left.pack_propagate(False)
        tk.Frame(left, bg=C["hdr"], height=4).pack(fill="x")
        sf = tk.Frame(left, bg=C["surface"]); sf.pack(fill="x", padx=10, pady=(10, 4))
        tk.Label(sf, text="Search:", font=("Helvetica", 10, "bold"),
                 bg=C["surface"], fg=C["sub"]).pack(side="left")
        search_var = tk.StringVar()
        tk.Entry(sf, textvariable=search_var, font=("Helvetica", 11),
                 bg=C["s2"], fg=C["txt"], relief="flat", bd=0
                 ).pack(side="left", fill="x", expand=True, ipady=5, ipadx=6, padx=(6,0))

        # ── Multi-select toolbar ──────────────────────────────────────────
        sel_bar = tk.Frame(left, bg=C["gld_lt"]); sel_bar.pack(fill="x", padx=6, pady=(2,0))
        sel_count_lbl = tk.Label(sel_bar, text="0 selected", font=("Helvetica", 9),
                                  bg=C["gld_lt"], fg=C["gld"])
        sel_count_lbl.pack(side="left", padx=6)
        selected_ids = {}  # resident id -> BooleanVar

        def update_sel_bar():
            n = sum(1 for v in selected_ids.values() if v.get())
            sel_count_lbl.configure(text=f"{n} selected")
            bulk_del_btn.configure(
                state="normal" if n > 0 else "disabled",
                bg=C["red"] if n > 0 else C["mut"])

        def bulk_delete():
            ids_to_del = [rid for rid, v in selected_ids.items() if v.get()]
            if not ids_to_del: return
            names_to_del = []
            with sqlite3.connect(DB) as conn_b:
                cur_b = conn_b.cursor()
                for rid in ids_to_del:
                    cur_b.execute("SELECT name FROM residents WHERE id=?", (rid,))
                    row_b = cur_b.fetchone()
                    if row_b: names_to_del.append(row_b[0])
            if not self._confirm(
                "Delete Selected Residents",
                f"Permanently delete {len(ids_to_del)} resident(s) and ALL their health records?\n\n"
                + "\n".join(f"  {n}" for n in names_to_del) + "\n\nThis cannot be undone."):
                return
            with sqlite3.connect(DB) as conn_b2:
                for rid, name in zip(ids_to_del, names_to_del):
                    conn_b2.execute("DELETE FROM residents WHERE id=?", (rid,))
                    conn_b2.execute("DELETE FROM health_records WHERE name=?", (name,))
            load_residents(search_var.get()); show_placeholder()

        def select_all_toggle():
            any_unchecked = any(not v.get() for v in selected_ids.values())
            for v in selected_ids.values():
                v.set(any_unchecked)
            update_sel_bar()

        btn_row_sel = tk.Frame(sel_bar, bg=C["gld_lt"]); btn_row_sel.pack(side="right")
        self.btn(btn_row_sel, "All", select_all_toggle,
                 bg=C["gld"], size=9, padx=6, pady=1).pack(side="left", padx=(0,3))
        bulk_del_btn = self.btn(btn_row_sel, "\U0001f5d1 Delete",
                                bulk_delete, bg=C["mut"], size=9, padx=6, pady=1)
        bulk_del_btn.configure(state="disabled")
        bulk_del_btn.pack(side="left", padx=(0,4))

        tk.Label(left, text="RESIDENTS", font=("Helvetica", 10, "bold"),
                 bg=C["surface"], fg=C["sub"]).pack(anchor="w", padx=12, pady=(6,2))
        tk.Frame(left, bg=C["bdr"], height=1).pack(fill="x")
        lf = tk.Frame(left, bg=C["surface"]); lf.pack(fill="both", expand=True)
        vsb1 = tk.Scrollbar(lf); vsb1.pack(side="right", fill="y")
        lc = tk.Canvas(lf, bg=C["surface"], yscrollcommand=vsb1.set, highlightthickness=0)
        lc.pack(side="left", fill="both", expand=True)
        vsb1.config(command=lc.yview)
        il = tk.Frame(lc, bg=C["surface"])
        lc.create_window((0, 0), window=il, anchor="nw")
        def _on_il_configure(e):
            lc.configure(scrollregion=lc.bbox("all"))
            # Without this, touch-dragging on an actual resident row does
            # nothing — only a drag on bare, empty canvas would scroll.
            self._bind_scroll_recursive(il, lc)
        il.bind("<Configure>", _on_il_configure)
        lc.bind("<MouseWheel>", lambda e: lc.yview_scroll(int(-e.delta/120), "units"))
        lc.bind("<Button-4>",   lambda e: lc.yview_scroll(-1, "units"))
        lc.bind("<Button-5>",   lambda e: lc.yview_scroll(1,  "units"))
        lc.bind("<ButtonPress-1>", lambda e: lc.scan_mark(e.x, e.y))
        lc.bind("<B1-Motion>",     lambda e: lc.scan_dragto(e.x, e.y, gain=1))

        # RIGHT — detail
        right = tk.Frame(body, bg=C["bg"]); right.pack(side="left", fill="both", expand=True)
        self._admin_right = right

        def show_placeholder():
            for w in right.winfo_children(): w.destroy()
            tk.Label(right, text="\U0001f448  Select a resident to view details",
                     font=("Helvetica", 14), bg=C["bg"], fg=C["mut"]
                     ).place(relx=.5, rely=.5, anchor="center")
        show_placeholder()

        def load_residents(ft=""):
            for w in il.winfo_children(): w.destroy()
            selected_ids.clear()
            with sqlite3.connect(DB) as conn:
                cur = conn.cursor()
                cur.execute("SELECT id,name,age,gender FROM residents ORDER BY name")
                rows = cur.fetchall()
            if ft: rows = [r for r in rows if ft.lower() in r[1].lower()]
            if not rows:
                tk.Label(il, text="No residents found.", font=("Helvetica", 11),
                         bg=C["surface"], fg=C["mut"]).pack(padx=12, pady=20)
                update_sel_bar(); return
            for rid, rname, rage, rgender in rows:
                chk_var = tk.BooleanVar(value=False)
                selected_ids[rid] = chk_var
                rf = tk.Frame(il, bg=C["surface"],
                              highlightbackground=C["bdr"], highlightthickness=1)
                rf.pack(fill="x", padx=6, pady=3)
                gc = "#1e40af" if rgender == "Male" else "#9d174d"
                icon = "\U0001f466" if rgender == "Male" else "\U0001f467"
                # Checkbox on left
                chk = tk.Checkbutton(rf, variable=chk_var, bg=C["surface"],
                                     activebackground=C["surface"],
                                     command=update_sel_bar)
                chk.pack(side="left", padx=(4,0))
                tk.Label(rf, text=icon, font=("Helvetica", self.sf(18)),
                         bg=C["surface"]).pack(side="left", padx=(2,0), pady=self.sc(6))
                info = tk.Frame(rf, bg=C["surface"])
                info.pack(side="left", fill="x", expand=True, padx=self.sc(8), pady=self.sc(6))
                tk.Label(info, text=rname, font=("Helvetica", self.sf(12), "bold"),
                         bg=C["surface"], fg=gc, anchor="w").pack(fill="x")
                tk.Label(info, text=f"Age {rage or '—'}  •  {rgender}",
                         font=("Helvetica", self.sf(10)), bg=C["surface"],
                         fg=C["sub"], anchor="w").pack(fill="x")
                def cb(e, i=rid, n=rname, g=rgender, a=rage):
                    show_detail(i, n, g, a)
                for widget in [info] + list(info.winfo_children()):
                    widget.bind("<Button-1>", cb)
            update_sel_bar()

        search_var.trace_add("write", lambda *_: load_residents(search_var.get()))

        def show_detail(rid, rname, rgender, rage):
            panel = self._admin_right
            for w in panel.winfo_children(): w.destroy()
            tk.Frame(panel, bg=C["hdr"], height=4).pack(fill="x")

            # Profile header
            ph = tk.Frame(panel, bg=C["surface"]); ph.pack(fill="x", padx=16, pady=(12,0))
            gc = "#1e40af" if rgender == "Male" else "#9d174d"
            icon = "\U0001f466" if rgender == "Male" else "\U0001f467"
            tk.Label(ph, text=icon, font=("Helvetica", self.sf(32)),
                     bg=C["surface"]).pack(side="left", padx=(0,self.sc(12)))
            pi = tk.Frame(ph, bg=C["surface"]); pi.pack(side="left", fill="x", expand=True)
            tk.Label(pi, text=rname, font=("Helvetica", self.sf(16), "bold"),
                     bg=C["surface"], fg=gc).pack(anchor="w")
            tk.Label(pi, text=f"Age: {rage or '—'}   •   Gender: {rgender}",
                     font=("Helvetica", self.sf(11)), bg=C["surface"], fg=C["sub"]).pack(anchor="w")
            ab = tk.Frame(ph, bg=C["surface"]); ab.pack(side="right")
            self.btn(ab, "\u270e  Edit Profile",
                     lambda: edit_profile(rid, rname, rage, rgender),
                     bg=C["gld"], size=11, padx=10, pady=4).pack(pady=2)
            self.btn(ab, "\U0001f5d1  Delete Resident",
                     lambda: delete_resident(rid, rname),
                     bg=C["red"], size=11, padx=10, pady=4).pack(pady=2)

            tk.Frame(panel, bg=C["bdr"], height=1).pack(fill="x", padx=16, pady=(10,0))
            tk.Label(panel, text="HEALTH RECORDS", font=("Helvetica", 10, "bold"),
                     bg=C["bg"], fg=C["sub"]).pack(anchor="w", padx=16, pady=(8,4))

            ro = tk.Frame(panel, bg=C["bg"]); ro.pack(fill="both", expand=True, padx=16, pady=(0,12))
            vsb2 = tk.Scrollbar(ro); vsb2.pack(side="right", fill="y")
            rc = tk.Canvas(ro, bg=C["bg"], yscrollcommand=vsb2.set, highlightthickness=0)
            rc.pack(side="left", fill="both", expand=True)
            vsb2.config(command=rc.yview)
            ri = tk.Frame(rc, bg=C["bg"])
            rc.create_window((0, 0), window=ri, anchor="nw")
            def _on_ri_configure(e):
                rc.configure(scrollregion=rc.bbox("all"))
                # Without this, touch-dragging on an actual record card
                # does nothing — only a drag on bare, empty canvas would
                # scroll, which is easy to miss on a touchscreen.
                self._bind_scroll_recursive(ri, rc)
            ri.bind("<Configure>", _on_ri_configure)
            rc.bind("<MouseWheel>", lambda e: rc.yview_scroll(int(-e.delta/120), "units"))
            rc.bind("<Button-4>",   lambda e: rc.yview_scroll(-1, "units"))
            rc.bind("<Button-5>",   lambda e: rc.yview_scroll(1,  "units"))
            rc.bind("<ButtonPress-1>", lambda e: rc.scan_mark(e.x, e.y))
            rc.bind("<B1-Motion>",     lambda e: rc.scan_dragto(e.x, e.y, gain=1))

            def load_records():
                for w in ri.winfo_children(): w.destroy()
                with sqlite3.connect(DB) as conn2:
                    cur2 = conn2.cursor()
                    cur2.execute(
                        "SELECT id,temp,bp,glucose,height,weight,bmi,timestamp "
                        "FROM health_records WHERE name=? ORDER BY timestamp DESC", (rname,))
                    recs = cur2.fetchall()
                if not recs:
                    tk.Label(ri, text="No health records yet.",
                             font=("Helvetica", 12), bg=C["bg"], fg=C["mut"]).pack(pady=20)
                    return
                flabels = ["Temp (°C)", "BP (mmHg)", "Glucose\n(mg/dL)",
                           "Height (cm)", "Weight (kg)", "BMI"]
                for hid, *mvals, ts in recs:
                    card = tk.Frame(ri, bg=C["surface"],
                                    highlightbackground=C["bdr"], highlightthickness=1)
                    card.pack(fill="x", pady=5)
                    tr = tk.Frame(card, bg=C["surface"]); tr.pack(fill="x", padx=self.sc(12), pady=(self.sc(8),self.sc(4)))
                    tk.Label(tr, text=f"\U0001f4c5  {ts}",
                             font=("Helvetica", self.sf(11), "bold"),
                             bg=C["surface"], fg=C["hdr"]).pack(side="left")
                    self.btn(tr, "\U0001f5d1 Delete",
                             lambda h=hid: delete_record(h),
                             bg=C["red"], size=10, padx=8, pady=2).pack(side="right")
                    self.btn(tr, "\u270e Edit",
                             lambda h=hid, v=list(mvals), t=ts: edit_record(h, v, t),
                             bg=C["gld"], size=10, padx=8, pady=2
                             ).pack(side="right", padx=(0,6))
                    gf3 = tk.Frame(card, bg=C["surface"]); gf3.pack(fill="x", padx=self.sc(12), pady=(0,self.sc(10)))
                    for ci, (lbl, val) in enumerate(zip(flabels, mvals)):
                        # Soft pastel BMI theme for this cell specifically —
                        # the admin panel is English-only already, so the
                        # theme's own status text fits without translation.
                        if lbl == "BMI" and val:
                            theme = get_bmi_theme(val)
                            cell_bg, fg = theme["bg"], theme["fg"]
                            disp = f"{str(val).split()[0]} ({theme['text']})"
                        else:
                            cell_bg, fg = C["s2"], C["txt"]
                            disp = val or "—"
                        cell = tk.Frame(gf3, bg=cell_bg, padx=8, pady=4)
                        cell.grid(row=0, column=ci, padx=3, pady=2, sticky="ew")
                        gf3.grid_columnconfigure(ci, weight=1)
                        tk.Label(cell, text=lbl, font=("Helvetica", self.sf(8)),
                                 bg=cell_bg, fg=C["sub"]).pack(anchor="w")
                        tk.Label(cell, text=disp, font=("Helvetica", self.sf(11), "bold"),
                                 bg=cell_bg, fg=fg).pack(anchor="w")

            def delete_resident(rid_, rname_):
                if self._confirm(
                    "Delete Resident",
                    f"Permanently delete '{rname_}' and ALL their health records?\n\nThis cannot be undone."):
                    with sqlite3.connect(DB) as conn3:
                        conn3.execute("DELETE FROM residents WHERE id=?", (rid_,))
                        conn3.execute("DELETE FROM health_records WHERE name=?", (rname_,))
                    load_residents(search_var.get()); show_placeholder()

            def delete_record(hid_):
                if self._confirm("Delete Record", "Delete this health record entry?"):
                    with sqlite3.connect(DB) as conn4:
                        conn4.execute("DELETE FROM health_records WHERE id=?", (hid_,))
                    load_records()

            def edit_profile(rid_, rname_, rage_, rgender_):
                # Fetch current email and birthdate for this resident
                with sqlite3.connect(DB) as _ec:
                    _ecur = _ec.cursor()
                    _ecur.execute("SELECT email, birthdate FROM residents WHERE id=?", (rid_,))
                    _erow = _ecur.fetchone()
                remail_    = (_erow[0] or "") if _erow else ""
                rbirthdate = (_erow[1] or "") if _erow else ""

                ep = self._popup("Edit Resident Profile", 460, 440)
                tk.Frame(ep, bg=C["gld"], height=self.sc(6)).pack(fill="x")
                eb = tk.Frame(ep, bg=C["bg"]); eb.pack(expand=True, padx=self.sc(36), pady=self.sc(20), fill="both")
                tk.Label(eb, text="Edit Resident Profile", font=("Helvetica", self.sf(15), "bold"),
                         bg=C["bg"], fg=C["hdr"]).pack(anchor="w")
                tk.Frame(eb, bg=C["bdr"], height=1).pack(fill="x", pady=(self.sc(6),self.sc(14)))
                def ef(label, value):
                    tk.Label(eb, text=label, font=("Helvetica", self.sf(10), "bold"),
                             bg=C["bg"], fg=C["sub"]).pack(anchor="w")
                    e = tk.Entry(eb, font=("Helvetica", self.sf(13)), bg=C["s2"],
                                 fg=C["txt"], relief="flat", bd=0)
                    e.insert(0, value or "")
                    e.pack(fill="x", ipady=self.sc(8), ipadx=self.sc(6), pady=(self.sc(3),self.sc(10))); return e
                en_name     = ef("Full Name", rname_)
                en_birthdate= ef("Date of Birth (YYYY-MM-DD)", rbirthdate)
                en_email    = ef("Email Address (optional)", remail_)
                tk.Label(eb, text="Gender", font=("Helvetica", self.sf(10), "bold"),
                         bg=C["bg"], fg=C["sub"]).pack(anchor="w")
                gv2 = tk.StringVar(value=rgender_)
                gf4 = tk.Frame(eb, bg=C["bg"]); gf4.pack(anchor="w", pady=(self.sc(3),self.sc(12)))
                gb2 = {}
                def pick_g(v):
                    gv2.set(v)
                    for vv, bb in gb2.items():
                        bb.configure(bg=C["acc"] if vv==v else C["s2"],
                                     fg="white"  if vv==v else C["sub"])
                for vv, ll in [("Male","Male"),("Female","Female")]:
                    bb = tk.Button(gf4, text=ll, font=("Helvetica", self.sf(12), "bold"),
                                   bg=C["s2"], fg=C["sub"], relief="flat", bd=0,
                                   width=8, height=1, cursor="hand2",
                                   command=lambda v=vv: pick_g(v))
                    bb.pack(side="left", padx=(0,self.sc(8))); gb2[vv] = bb
                pick_g(rgender_)
                def save_profile():
                    nn = en_name.get().strip()
                    nb = en_birthdate.get().strip()
                    ng = gv2.get()
                    ne = en_email.get().strip()
                    if not nn:
                        self._alert("warning", "Name cannot be empty."); return
                    # Recompute age from birthdate if provided
                    na = rage_
                    try:
                        bd = datetime.strptime(nb, "%Y-%m-%d")
                        today = datetime.now()
                        na = str(today.year - bd.year - ((today.month, today.day) < (bd.month, bd.day)))
                    except Exception:
                        pass
                    with sqlite3.connect(DB) as conn5:
                        if nn != rname_:
                            conn5.execute("UPDATE health_records SET name=? WHERE name=?", (nn, rname_))
                        conn5.execute("UPDATE residents SET name=?,age=?,gender=?,email=?,birthdate=? WHERE id=?",
                                      (nn, na, ng, ne, nb, rid_))
                    if nn == self.user or rname_ == self.user:
                        self.email = ne
                    ep.destroy(); load_residents(search_var.get()); show_detail(rid_, nn, ng, na)
                br3 = tk.Frame(eb, bg=C["bg"]); br3.pack(anchor="w")
                self.btn(br3, "\U0001f4be  Save Changes", save_profile,
                         bg=C["grn"], size=12, padx=self.sc(14), pady=self.sc(5)).pack(side="left", padx=(0,self.sc(8)))
                self.btn(br3, "Cancel", ep.destroy,
                         bg=C["surface"], fg=C["sub"], size=11).pack(side="left")

            def edit_record(hid_, mvals, ts_):
                er = self._popup("Edit Health Record", 540, 440)
                tk.Frame(er, bg=C["gld"], height=self.sc(6)).pack(fill="x")
                erb = tk.Frame(er, bg=C["bg"]); erb.pack(expand=True, padx=self.sc(36), pady=self.sc(16), fill="both")
                tk.Label(erb, text=f"Edit Health Record — {ts_}",
                         font=("Helvetica", self.sf(14), "bold"), bg=C["bg"], fg=C["hdr"]).pack(anchor="w")
                tk.Frame(erb, bg=C["bdr"], height=1).pack(fill="x", pady=(self.sc(6),self.sc(12)))
                fnames = ["Body Temperature (°C)", "Blood Pressure (mmHg)",
                          "Blood Glucose (mg/dL)", "Height (cm)", "Weight (kg)", "BMI (auto)"]
                entries2 = []
                gf5 = tk.Frame(erb, bg=C["bg"]); gf5.pack(fill="x")
                for ci, (fn, val) in enumerate(zip(fnames, mvals)):
                    r5, c5 = divmod(ci, 2)
                    cell5 = tk.Frame(gf5, bg=C["bg"])
                    cell5.grid(row=r5, column=c5, padx=self.sc(6), pady=self.sc(4), sticky="ew")
                    gf5.grid_columnconfigure(c5, weight=1)
                    is_bmi = fn.startswith("BMI")
                    tk.Label(cell5, text=fn, font=("Helvetica", self.sf(10), "bold"),
                             bg=C["bg"], fg=C["sub"]).pack(anchor="w")
                    e5 = tk.Entry(cell5, font=("Helvetica", self.sf(12)),
                                  bg=C["gld_lt"] if is_bmi else C["s2"],
                                  fg=C["txt"], relief="flat", bd=0,
                                  state="disabled" if is_bmi else "normal")
                    e5.insert(0, val or ""); e5.pack(fill="x", ipady=self.sc(7), ipadx=self.sc(6))
                    entries2.append((fn, e5, is_bmi))
                tk.Label(erb, text="BMI is recalculated automatically from Height & Weight.",
                         font=("Helvetica", self.sf(9), "italic"), bg=C["bg"], fg=C["mut"]
                         ).pack(anchor="w", pady=(self.sc(6),0))
                tk.Frame(erb, bg=C["bg"]).pack(expand=True)
                def save_rec():
                    nv = [e5.get().strip() if not ib else None for _, e5, ib in entries2]
                    try:
                        h5 = float(nv[3]) / 100; w5 = float(nv[4])
                        nv[5] = f"{w5/(h5*h5):.1f}"
                    except Exception:
                        nv[5] = mvals[5]
                    with sqlite3.connect(DB) as conn6:
                        conn6.execute(
                            "UPDATE health_records SET temp=?,bp=?,glucose=?,height=?,weight=?,bmi=? WHERE id=?",
                            (*nv[:6], hid_))
                    er.destroy(); load_records()
                br4 = tk.Frame(erb, bg=C["bg"]); br4.pack(anchor="w", pady=(self.sc(8),0))
                self.btn(br4, "\U0001f4be  Save Changes", save_rec,
                         bg=C["grn"], size=12, padx=self.sc(14), pady=self.sc(5)).pack(side="left", padx=(0,self.sc(8)))
                self.btn(br4, "Cancel", er.destroy,
                         bg=C["surface"], fg=C["sub"], size=11).pack(side="left")

            load_records()

        load_residents()


if __name__ == "__main__":
    App().mainloop()